package dto

import (
	"entity"
)
//ユーザ情報
type User struct {
	entity.TblUser
	TblUserRole []entity.TblUserRole
}
