package ref

import (
	"dao"
	"dto"
)

func GetUsers() (error, []dto.User) {
	var users []dto.User
	err, conn := dao.GetConnection()
	if (err != nil) {
		return err, nil
	}

	if err := conn.Table("TBL_USER").Find(&users).Error; err != nil {
		return err, users
	}

	if err := conn.Close(); err != nil {
		return err, users
	}

	return nil, users
}

func GetUser(userId string) (error, dto.User) {
	var user dto.User
	err, conn := dao.GetConnection()
	if (err != nil) {
		return err, user
	}

	if err := conn.Table("TBL_USER").First(&user, userId).Error; err != nil {
		return err, user
	}

	if err := conn.Close(); err != nil {
		return err, user
	}

	return nil, user
}
