package mainte

import (
//	"fmt"
	"dao"
	"dto"
	"github.com/jinzhu/gorm"
	_ "github.com/lib/pq"
	_ "github.com/go-sql-driver/mysql"
)

func CreateUser(user dto.User) (error, dto.User) {
	err, conn := dao.GetConnection()
	if (err != nil) {
		return err, dto.User{}
	}

	err, conn = dao.BeginTransaction(conn)
	if (err != nil) {
		return err, dto.User{}
	}

	if err := conn.Table("TBL_USER").Create(&user).Error; err != nil {
		conn.Rollback()
		return err, dto.User{}
	}

	var newUser dto.User
	if err, newUser = getNewUser(user.UserId, conn); err != nil {
		return err, newUser
	}

	conn.Commit();

	if err := conn.Close(); err != nil {
		return err, newUser
	}

	return nil, newUser
}

func UpdateUser(userId string, user *dto.User) (error, dto.User) {
	err, conn := dao.GetConnection()
	if (err != nil) {
		return err, dto.User{}
	}

	err, conn = dao.BeginTransaction(conn)
	if (err != nil) {
		return err, dto.User{}
	}

	tableType := dto.User{}
	attrMap := map[string]interface{}{
		"userName":user.UserName,
		"password":user.Password,
		"privilegeFlg":user.PrivilegeFlg,
		"pwTempFlg":user.PwTempFlg,
		"remarks":user.Remarks,
		"creator":user.Creator,
		"createDay":user.CreateDay,
		"lastUpdator":user.LastUpdator,
		"lastUpdateDay":user.LastUpdateDay,
	}

	if err = conn.Table("TBL_USER").Model(&tableType).Where("userId = ?", userId).Updates(attrMap).Error; err != nil {
		conn.Rollback()
		return err, dto.User{}
	}

	var modUser dto.User
	if err, modUser := getNewUser(userId, conn); err != nil {
		return err, modUser
	}

	conn.Commit();

	if err := conn.Close(); err != nil {
		return err, modUser
	}

	return nil, modUser
}

func DeleteUser(userId string) error {
	err, conn := dao.GetConnection()
	if (err != nil) {
		return err
	}

	err, conn = dao.BeginTransaction(conn)
	if (err != nil) {
		return err
	}

	if err = conn.Table("TBL_USER").Where("userId = ?", userId).Delete(&dto.User{}).Error; err != nil {
		conn.Rollback()
		return err
	}

	conn.Commit();

	if err := conn.Close(); err != nil {
		return err
	}

	return nil
}

func getNewUser(userId string, conn *gorm.DB) (error, dto.User) {
	var user dto.User
	if err := conn.Table("TBL_USER").Where("userId = ?", userId).First(&user).Error; err != nil {
		return err, user
	}

	if err := conn.Close(); err != nil {
		panic(err)
		return err, user
	}

	return nil, user
}
