package ref

import (
	"reflect"
	"github.com/jinzhu/gorm"
	_ "github.com/lib/pq"
	_ "github.com/go-sql-driver/mysql"
)

func GetLastAutoIncrementId(conn *gorm.DB) (error, string) {
	rows, err := conn.Raw("select last_insert_id() as last").Rows()
	if (err != nil) {
		return err, ""
	}

	defer rows.Close()

	var last string
	for rows.Next() {
		rows.Scan(&last)
	}
	return nil, last
}
