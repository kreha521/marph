package dao

import (
	"github.com/jinzhu/gorm"
	_ "github.com/lib/pq"
	_ "github.com/go-sql-driver/mysql"
)

func GetConnection() (error, *gorm.DB) {
	db, err := gorm.Open("mysql", "root:password02@tcp(localhost:3306)/mydatabase")
	return err, db
}

func BeginTransaction(db *gorm.DB) (error, *gorm.DB) {
	tx := db.Begin()
	return tx.Error, tx
}

func Commit(db *gorm.DB) (error, *gorm.DB) {
	tx := db.Commit()
	return tx.Error, tx
}

func Roolback(db *gorm.DB) (error, *gorm.DB) {
	tx := db.Rollback()
	return tx.Error, tx
}
