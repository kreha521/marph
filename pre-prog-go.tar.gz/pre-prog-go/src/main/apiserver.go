package main

import (
	"fmt"
	"net/http"
	"github.com/gin-gonic/gin"
	"dto"
	"service/user/ref"
	"service/user/mainte"
)

func main() {
	router := gin.Default()

	routeUsers(router)

	router.Run(":10000")
	fmt.Println("API server is running!")
}

//func routeUsers(router *gin.Engine) {
//	var req dto.User
//
//	router.GET("/users", func(c *gin.Context) {
//		err, users := ref.GetUsers()
//		if (err != nil) {
//			panic(err)
//			c.JSON(http.StatusBadRequest, gin.H{"status": "BadRequest"})
//			return
//		}
//		c.JSON(http.StatusOK, users)
//	})
//
//	router.GET("/users/:userId", func(c *gin.Context) {
//		var userId = c.Param("userId")
//		err, user := ref.GetUserByPK(userId)
//		if (err != nil) {
//			panic(err)
//			c.JSON(http.StatusBadRequest, gin.H{"status": "BadRequest"})
//			return
//		}
//		c.JSON(http.StatusOK, user)
//	})
//
//	router.GET("/users/:userId/roles", func(c *gin.Context) {
//		var userId = c.Param("userId")
//		err, user := ref.GetUserByPK(userId)
//		if (err != nil) {
//			panic(err)
//			c.JSON(http.StatusBadRequest, gin.H{"status": "BadRequest"})
//			return
//		}
//		c.JSON(http.StatusOK, ref.GetUserRoles(userId))
//	})
//
//	router.POST("/users", func(c *gin.Context) {
//		if err := c.BindJSON(&req); err != nil {
//			panic(err)
//			c.JSON(http.StatusBadRequest, gin.H{"status": "BadRequest:Failed to bind params"})
//			return
//		}
//
//		err, user := mainte.CreateCharacter(req)
//		if (err != nil) {
//			panic(err)
//			c.JSON(http.StatusBadRequest, gin.H{"status": "BadRequest:Failed to create"})
//			return
//		}
//
//		c.JSON(http.StatusOK, user)
//	})
//
//	router.PUT("/users/:userId", func(c *gin.Context) {
//		var userId = c.Param("userId")
//		fmt.Println("/users PUT start")
//		c.JSON(http.StatusOK, mainte.UpdUser(c.Param("userId"), c))
//		fmt.Println("/users PUT end")
//	})
//
//	router.DELETE("/users/:userId", func(c *gin.Context) {
//		fmt.Println("/users PUT start")
//		mainte.DelUser(c.Param("userId"))
//		fmt.Println("/users PUT end")
//	})
//}


func routeUsers(router *gin.Engine) {
	var req dto.User

	router.GET("/users", func(c *gin.Context) {
		err, users := ref.GetUsers()
		if (err != nil) {
			panic(err)
			c.JSON(http.StatusBadRequest, gin.H{"status": "BadRequest"})
			return
		}
		c.JSON(http.StatusOK, users)
	})

	router.GET("/users/:userId", func(c *gin.Context) {
		err, user := ref.GetUser(c.Param("userId"))
		if (err != nil) {
			panic(err)
			c.JSON(http.StatusBadRequest, gin.H{"status": "BadRequest"})
			return
		}
		c.JSON(http.StatusOK, user)
	})

	router.POST("/users", func(c *gin.Context) {
		if err := c.BindJSON(&req); err != nil {
			panic(err)
			c.JSON(http.StatusBadRequest, gin.H{"status": "BadRequest:Failed to bind params"})
			return
		}

		err, user := mainte.CreateUser(req)
		if (err != nil) {
			panic(err)
			c.JSON(http.StatusBadRequest, gin.H{"status": "BadRequest:Failed to create"})
			return
		}

		c.JSON(http.StatusOK, user)
	})

	router.PUT("/users/:userId", func(c *gin.Context) {
		if err := c.BindJSON(&req); err != nil {
			panic(err)
			c.JSON(http.StatusBadRequest, gin.H{"status": "BadRequest:Failed to bind params"})
			return
		}

		err, user := mainte.UpdateUser(c.Param("userId"), &req)
		if (err != nil) {
			panic(err)
			c.JSON(http.StatusBadRequest, gin.H{"status": "BadRequest"})
			return
		}
		c.JSON(http.StatusOK, user)
	})

	router.DELETE("/users/:userId", func(c *gin.Context) {
		err := mainte.DeleteUser(c.Param("userId"))
		if (err != nil) {
			panic(err)
			c.JSON(http.StatusBadRequest, gin.H{"status": "BadRequest"})
			return
		}
		c.Status(http.StatusOK)
	})
}
