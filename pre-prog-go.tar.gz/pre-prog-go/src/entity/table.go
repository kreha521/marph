package entity

//排他情報
type Exclusion struct {
	UpdateCounter		int			`json:"updateCounter" gorm:"column:updateCounter"`
}

//更新情報
type Mod struct {
	Creator				string		`json:"creator" gorm:"column:creator"`
	CreateDay			string		`json:"createDay" gorm:"column:createDay"`
	LastUpdator			string		`json:"lastUpdator" gorm:"column:lastUpdator"`
	LastUpdateDay		string		`json:"lastUpdateDay" gorm:"column:lastUpdateDay"`
}

//ユーザ情報エンティティ
type TblUser struct {
	Exclusion
	UserId				string		`json:"userId" gorm:"column:userId;primary_key"`
	UserName			string		`json:"userName" gorm:"column:userName"`
	Password			string		`json:"password" gorm:"column:password"`
	PrivilegeFlg		string		`json:"privilegeFlg" gorm:"column:privilegeFlg"`
	PwTempFlg			string		`json:"pwTempFlg" gorm:"column:pwTempFlg"`
	Remarks				string		`json:"remarks" gorm:"column:remarks"`
	Mod
}

//権限エンティティ
type TblUserRole struct {
	Exclusion
	UserId				string		`json:"userId" gorm:"column:userId;primary_key"`
	GroupCd				int			`json:"groupCd" gorm:"column:groupCd;primary_key"`
	RoleCd				string		`json:"roleCd" gorm:"column:roleCd"`
	Mod
}

