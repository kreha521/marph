var validator = require('validator');
var commonUtil = require('../common/commonUtil.js');
var commonValidator = require('./common.js');

//ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

// 入力チェック定義
var validators = commonValidator.getValidators();

validators['/opedatemodifies/upd'] = function(req) {
    var msgs = commonValidator.initMsgs();

    if (commonValidator.isEmpty(req.body.envCd.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "環境コード"));
    }
    if (commonValidator.isEmpty(req.body.seriesCd.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "系列コード"));
    }
    if (commonValidator.isEmpty(req.body.opeDate.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "業務日付コード"));
    } else {

    }

    return msgs;
};

module.exports = {
    // バリデータ取得
    getValidators: function() {
        return commonValidator.validators();
    },
    // 入力チェック
    validate: function(url, req) {
        return commonValidator.validate(url, req);
    },
    // 入力チェック結果を返却する
    hasError: function() {
        return commonValidator.hasError();
    }
}
