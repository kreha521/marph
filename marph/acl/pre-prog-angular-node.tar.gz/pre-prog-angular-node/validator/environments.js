var validator = require('validator');
var commonUtil = require('../common/commonUtil.js');
var commonValidator = require('./common.js');

// 入力チェック定義
var validators = commonValidator.getValidators();

validators['/envs/get/_edit'] = function(req) {
    var msgs = commonValidator.initMsgs();

    if (commonValidator.isEmpty(req.body.envCd.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "環境コード"));
    }

    return msgs;
};

validators['/envs/add'] = function(req) {
    var msgs = commonValidator.initMsgs();

    if (commonValidator.isEmpty(req.body.envCd.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "環境コード"));
    }
    if (!validator.isLength(req.body.envCd, {max:2})) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", ["環境コード", "2"]));
    }
    if (!commonValidator.isSingleByteStr(req.body.envCd)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0028", "環境コード"));
    }


    if (commonValidator.isEmpty(req.body.envName.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "環境名称"));
    }
    if (!validator.isLength(req.body.envName, {max:20})) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", ["環境名称", "20"]));
    }

    return msgs;
};

validators['/envs/upd'] = function(req) {
    return validators['/envs/add'](req);
    return msgs;
};

validators['/envs/del'] = function(req) {
    var msgs = commonValidator.initMsgs();
    return msgs;
};

module.exports = {
    // バリデータ取得
    getValidators: function() {
        return commonValidator.validators();
    },
    // 入力チェック
    validate: function(url, req) {
        return commonValidator.validate(url, req);
    },
    // 入力チェック結果を返却する
    hasError: function() {
        return commonValidator.hasError();
    }
}
