var validator = require('validator');
var commonUtil = require('../common/commonUtil.js');
var commonValidator = require('./common.js');

var constant = require('../const/availableseries.js');

//ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

// 入力チェック定義
var validators = commonValidator.getValidators();

/**** ▼URLごとに入力チェックを書いていく ****/

validators['/availableseries/get/_edit'] = function(req) {
    var msgs = commonValidator.initMsgs();

    if (commonValidator.isEmpty(req.body.envCd)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.ENV_CD_LOGICAL_NAME));
    }

    if (commonValidator.isEmpty(req.body.seriesCd)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.SERIES_CD_LOGICAL_NAME));
    }

    return msgs;
};

validators['/availableseries/add'] = function(req) {
    var msgs = commonValidator.initMsgs();

    var availableSeries = req.body.availableSeries;

    // 利用可能系列に関する入力チェック
    if (commonValidator.isEmpty(availableSeries.envCd)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.ENV_CD_LOGICAL_NAME));
    } else {
        if (!commonValidator.isValidCodeVal(req.app, 'envCd', availableSeries.envCd)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0035", constant.ENV_CD_LOGICAL_NAME));
        }
    }

    if (commonValidator.isEmpty(availableSeries.seriesCd)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.SERIES_CD_LOGICAL_NAME));
    } else {
        if (!commonValidator.isSingleByteStr(availableSeries.seriesCd)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0028", constant.SERIES_CD_LOGICAL_NAME));
        }
        if (!validator.isLength(availableSeries.seriesCd, {max:constant.SERIES_CD_LEN})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", [constant.SERIES_CD_LOGICAL_NAME, constant.SERIES_CD_LEN]));
        }
    }

    if (commonValidator.isEmpty(availableSeries.seriesName)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.SERIES_NAME_LOGICAL_NAME));
    } else {
        if (!validator.isLength(availableSeries.seriesName, {max:constant.SERIES_NAME_LEN})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", [constant.SERIES_NAME_LOGICAL_NAME, constant.SERIES_NAME_LEN]));
        }
    }

    // 利用可能コンテナに関する入力チェック
    var ipAddresses = {};
    var isDupulicated = false;
    var availableContainers = req.body.availableContainers;

    if (!availableContainers) {
        return msgs;
    }

	for (var i=0; i<availableContainers.length; i++) {
        var availableContainer = availableContainers[i];

        if (commonValidator.isEmpty(availableContainer.containerTypeCd)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.CONTAINER_TYPE_CD_LOGICAL_NAME));
        } else {
            if (!commonValidator.isValidCodeVal(req.app, 'containerTypeCd', availableContainer.containerTypeCd)) {
                msgs.msgsError.push(commonUtil.getMsg(req, "MSG0035", constant.CONTAINER_TYPE_CD_LOGICAL_NAME));
            }
        }

        if (commonValidator.isEmpty(availableContainer.containerTypeName)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.CONTAINER_TYPE_NAME_LOGICAL_NAME));
        } else {
            if (!validator.isLength(availableContainer.containerTypeName, {max:constant.CONTAINER_TYPE_NAME_LEN})) {
                msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", [constant.CONTAINER_TYPE_NAME_LOGICAL_NAME, constant.CONTAINER_TYPE_NAME_LEN]));
            }
        }

        if (commonValidator.isEmpty(availableContainer.hostname)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.CONTAINER_HOSTNAME_LOGICAL_NAME));
        } else {
            if (!validator.isLength(availableContainer.hostname, {max:constant.CONTAINER_HOSTNAME_LEN})) {
                msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", [constant.CONTAINER_HOSTNAME_LOGICAL_NAME, constant.CONTAINER_HOSTNAME_LEN]));
            }
        }

        if (commonValidator.isEmpty(availableContainer.ipAddress)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.CONTAINER_IP_ADDRESS_LOGICAL_NAME));
        } else {
            if (!validator.isLength(availableContainer.ipAddress, {max:constant.CONTAINER_IP_ADDRESS_LEN})) {
                msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", [constant.CONTAINER_IP_ADDRESS_LOGICAL_NAME, constant.CONTAINER_IP_ADDRESS_LEN]));
            }
            if (!commonValidator.isSingleByteStr(availableContainer.ipAddress)) {
                msgs.msgsError.push(commonUtil.getMsg(req, "MSG0028", constant.CONTAINER_IP_ADDRESS_LOGICAL_NAME));
            }
            if (!validator.isIP(availableContainer.ipAddress)) {
                msgs.msgsError.push(commonUtil.getMsg(req, "MSG0013", constant.CONTAINER_IP_ADDRESS_LOGICAL_NAME));
            }

            // 重複チェック中（コンテナ間）
            if (!isDupulicated && ipAddresses[availableContainer.ipAddress]) {
                isDupulicated = true;
            } else {
                ipAddresses[availableContainer.ipAddress] = true;
            }
        }

        if (!commonValidator.isEmpty(availableContainer.portForwardInfo)) {
            if (!validator.isLength(availableContainer.portForwardInfo, {max:constant.CONTAINER_PORT_FORWARD_INFO_LEN})) {
                msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", [constant.CONTAINER_PORT_FORWARD_INFO_LOGICAL_NAME, constant.CONTAINER_PORT_FORWARD_INFO_LEN]));
            }
        }
    }

    // IPアドレス重複チェック
    if (isDupulicated) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0037", constant.CONTAINER_IP_ADDRESS_LOGICAL_NAME));
    }

    return msgs;
};

validators['/availableseries/upd'] = function(req) {
    return validators['/availableseries/add'](req);
};

validators['/availableseries/delete'] = function(req) {
    var msgs = commonValidator.initMsgs();
    return msgs;
};

module.exports = {
    // バリデータ取得
    getValidators: function() {
        return commonValidator.validators();
    },
    // 入力チェック
    validate: function(url, req) {
        return commonValidator.validate(url, req);
    },
    // 入力チェック結果を返却する
    hasError: function() {
        return commonValidator.hasError();
    }
//TODO チケット#1545の問題にて保留中。コメントアウトしておく。
//    // IPアドレス割り当て可能チェック
//    isAvailableIpAddress: function(availavleContainer, data) {
//        var isAvailable = true;
//        var isRegisterd = false;
//
//        // 同一組織、コンテナ種別のコンテナ基本情報の中にIPアドレスが登録されている否かチェックする
//        for (var i=0; i<data.length; i++) {
//            var gettedContainer = data[i].BCs;
//            if (gettedContainer.orgCd != availavleContainer.orgCd
//                || gettedContainer.containerTypeCd != availavleContainer.containerTypeCd){
//                continue;
//            } else {
//                isRegisterd = true;
//            }
//            if (availavleContainer.ipAddress == gettedContainer.ipAddress) {
//                isAvailable = false;
//                break;
//            }
//        }
//
//        if (!isRegisterd) {
//            return false;
//        }
//        return isAvailable;
//    }
}
