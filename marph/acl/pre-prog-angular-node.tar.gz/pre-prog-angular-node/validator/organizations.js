var validator = require('validator');
var commonUtil = require('../common/commonUtil.js');
var commonValidator = require('./common.js');

// 入力チェック定義
var validators = commonValidator.getValidators();


/**** ▼URLごとに入力チェックを書いていく ****/

validators['/organizations/get/_edit'] = function(req) {
    var msgs = commonValidator.initMsgs();
    if (commonValidator.isEmpty(req.body.orgCd.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "組織コード"));
    }
    return msgs;
};

validators['/organizations/add'] = function(req) {
    var msgs = commonValidator.initMsgs();

    if (commonValidator.isEmpty(req.body.tblOrganization.orgName)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "組織名称"));
    } else {
        if (!validator.isLength(req.body.tblOrganization.orgName, {max:30})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", ["組織名称", "30"]));
        }
    }

    return msgs;
};

validators['/organizations/upd'] = function(req) {
    return validators['/organizations/add'](req);
};

validators['/organizations/del'] = function(req) {
    var msgs = commonValidator.initMsgs();

    if (commonValidator.isEmpty(req.body.orgCd.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "組織コード"));
    }

    return msgs;
};

module.exports = {
    // バリデータ取得
    getValidators: function() {
        return commonValidator.validators();
    },
    // 入力チェック
    validate: function(url, req) {
        return commonValidator.validate(url, req);
    },
    // 入力チェック結果を返却する
    hasError: function() {
        return commonValidator.hasError();
    }
}
