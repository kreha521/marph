var validator = require('validator');
var commonUtil = require('../common/commonUtil.js');
var commonValidator = require('./common.js');

//ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

// 入力チェック定義
var validators = commonValidator.getValidators();

validators['/groups/upd'] = function(req) {
    var msgs = commonValidator.initMsgs();

    if (validator.isEmpty(req.body.orgCd.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "組織コード"));
    }
    if (validator.isEmpty(req.body.groupCd.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "領域コード"));
    } else {
        if (!validator.isLength(req.body.groupCd.toString(), {max:5})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", ["領域コード", "5"]));
        }
        if (!commonValidator.isSingleByteStr(req.body.groupCd)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0028", "領域コード"));
        }
    }
    if (validator.isEmpty(req.body.groupName.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "領域名称"));
    } else {
        if (!validator.isLength(req.body.groupName, {max:30})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", ["領域名称", "30"]));
        }
    }
    if (validator.isEmpty(req.body.groupShortCd.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "略称コード"));
    } else {
        if (!validator.isLength(req.body.groupShortCd, {max:15})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", ["略称コード", "15"]));
        }
        if (!commonValidator.isSingleByteStr(req.body.groupShortCd)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0028", "略称コード"));
        }
    }

    return msgs;
};

validators['/groups/add'] = function(req) {
    var msgs = commonValidator.initMsgs();

    if (commonValidator.isEmpty(req.body.orgCd.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "組織コード"));
    }
    if (commonValidator.isEmpty(req.body.groupName.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "領域名称"));
    } else {
        if (!validator.isLength(req.body.groupName, {max:30})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", ["領域名称", "30"]));
        }
    }
    if (commonValidator.isEmpty(req.body.groupShortCd.toString())) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "略称コード"));
    } else {
        if (!validator.isLength(req.body.groupShortCd, {max:15})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", ["略称コード", "15"]));
        }
        if (!commonValidator.isSingleByteStr(req.body.groupShortCd)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0028", "略称コード"));
        }
    }

        return msgs;
    };

    validators['/groups/get/_edit'] = function(req) {
        var msgs = commonValidator.initMsgs();

        if (commonValidator.isEmpty(req.body.orgCd.toString())) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "組織コード"));
        }
        if (commonValidator.isEmpty(req.body.groupCd.toString())) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "領域コード"));
        }

        return msgs;
    };

    validators['/groups/del'] = function(req) {
        var msgs = commonValidator.initMsgs();

        if (commonValidator.isEmpty(req.body.orgCd.toString())) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "組織コード"));
        }
        if (commonValidator.isEmpty(req.body.groupCd.toString())) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "領域コード"));
        }

        return msgs;
    };

    module.exports = {
        // バリデータ取得
        getValidators: function() {
            return commonValidator.validators();
        },
        // 入力チェック
        validate: function(url, req) {
            return commonValidator.validate(url, req);
        },
        // 入力チェック結果を返却する
        hasError: function() {
            return commonValidator.hasError();
        }
    }
