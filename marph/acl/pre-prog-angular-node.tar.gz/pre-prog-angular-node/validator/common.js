var validator = require('validator');

var commonUtil = require('../common/commonUtil.js');
var checkUtil = require('../common/checkUtil.js');

// 入力チェック定義
var validators = {};
// 入力チェック結果
var hasError = false;

module.exports = {
    // バリデータ取得
    getValidators: function() {
        return validators;
    },
    // 入力チェック
    validate: function(url, req) {
        hasError = false;
        var msgs = validators[url](req);
        if (msgs && msgs.hasOwnProperty('msgsError') && msgs.msgsError.length > 0) {
            hasError = true;
        }
        return msgs;
    },
    // 入力チェック結果を返却する
    hasError: function() {
        return hasError;
    },
    // メッセージ情報初期化
    initMsgs :function() {
        return commonUtil.initMsgs();
    },

    // 半角文字チェック
    isSingleByteStr: function(str) {
        return checkUtil.isSingleByteStr(str);
    },
    // 半角数値チェック
    isSingleByteNumber: function(str) {
        return checkUtil.isSingleByteNumber(str);
    },
    // 半角英数字チェック
    isSingleByteAlphaNumber: function(str) {
        return checkUtil.isSingleByteAlphaNumber(str);
    },
    // ユーザID文字種チェック
    isValidUserId: function(str) {
        return checkUtil.isValidUserId(str);
    },
    // パスワード文字種チェック
    isValidPassword: function(str) {
        return checkUtil.isValidPassword(str);
    },
    // 配列の空チェック
    isEmptyArray: function(ary) {
        return checkUtil.isEmptyArray(ary);
    },
    // 空チェック
    isEmpty: function(val) {
        return checkUtil.isEmpty(val);
    },
    //コード値チェック(true:チェックOK, false:チェックNG)
    isValidCodeVal: function(app, key, code) {
        return checkUtil.isValidCodeVal(app, key, code);
    }
}
