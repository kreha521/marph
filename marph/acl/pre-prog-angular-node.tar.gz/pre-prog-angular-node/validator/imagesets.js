var validator = require('validator');
var commonUtil = require('../common/commonUtil.js');
var commonValidator = require('./common.js');

// 入力チェック定義
var validators = commonValidator.getValidators();

validators['/imagesets/get/_edit'] = function(req) {
    var msgs = commonValidator.initMsgs();
    return msgs;
};

validators['/imagesets/add'] = function(req) {
    var msgs = commonValidator.initMsgs();

    if (commonValidator.isEmpty(req.body.imgSet.imagesetName)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "イメージセット名"));
    } else {
        if (!validator.isLength(req.body.imgSet.imagesetName, {max:255})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", ["イメージセット名称", "255"]));
        }
    }

    return msgs;
};

validators['/imagesets/upd'] = function(req) {
    return validators['/imagesets/add'](req);
};

validators['/imagesets/del'] = function(req) {
    var msgs = commonValidator.initMsgs();
    return msgs;
};

module.exports = {
    // バリデータ取得
    getValidators: function() {
        return commonValidator.validators();
    },
    // 入力チェック
    validate: function(url, req) {
        return commonValidator.validate(url, req);
    },
    // 入力チェック結果を返却する
    hasError: function() {
        return commonValidator.hasError();
    }
}
