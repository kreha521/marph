var validator = require('validator');
var commonUtil = require('../common/commonUtil.js');
var commonValidator = require('./common.js');
var constant = require('../const/server.js');

//ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

// 入力チェック定義
var validators = commonValidator.getValidators();

/**** ▼URLごとに入力チェックを書いていく ****/

validators['/servers/get/_edit'] = function(req) {
    var msgs = commonValidator.initMsgs();

    if (commonValidator.isEmpty(req.body.serverSeqNo)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "サーバ連番"));
    }

    return msgs;
};

validators['/servers/add'] = function(req) {
    var msgs = commonValidator.initMsgs();

    var server = req.body.tblServer;

    if (commonValidator.isEmpty(server.serverName)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.SERVER_NAME_LOGICAL_NAME));
    } else {
        if (!validator.isLength(server.serverName, {max:constant.SERVER_NAME_LEN})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", [constant.SERVER_NAME_LOGICAL_NAME, constant.SERVER_NAME_LEN]));
        }
    }

    if (commonValidator.isEmpty(server.serverTypeCd)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.SERVER_TYPE_CD_LOGICAL_NAME));
    } else {
        if (!commonValidator.isValidCodeVal(req.app, 'serverTypeCd', server.serverTypeCd)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0035", constant.SERVER_TYPE_CD_LOGICAL_NAME));
        }
    }

    if (commonValidator.isEmpty(server.ipAddress)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.IP_ADDRESS_LOGICAL_NAME));
    } else {
        if (!validator.isLength(server.ipAddress, {max:constant.CONTAINER_IP_ADDRESS_LEN})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", [constant.IP_ADDRESS_LOGICAL_NAME, constant.IP_ADDRESS_LEN]));
        }
        if (!validator.isIP(server.ipAddress)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0013", constant.IP_ADDRESS_LOGICAL_NAME));
        }
    }

    if (commonValidator.isEmpty(server.orgCd)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.ORG_LOGICAL_NAME));
    } else {
        if (!validator.isLength(server.orgCd.toString(), {max:constant.ORG_LEN})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", [constant.ORG_LOGICAL_NAME, constant.ORG_LEN]));
        }
        if (!commonValidator.isSingleByteStr(server.orgCd.toString())) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0028", constant.ORG_LOGICAL_NAME));
        }
    }

    var ipAddresses = {};
    var isDupulicated = false;
    var containers = req.body.tblContainers;

    for (var i=0; i<containers.length; i++) {
        var container = containers[i];

        if (!commonValidator.isEmpty(container.containerTypeName)) {
            if (!validator.isLength(container.containerTypeName, {max:constant.CONTAINER_TYPE_NAME_LEN})) {
                msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", [constant.CONTAINER_TYPE_NAME_LOGICAL_NAME, constant.CONTAINER_TYPE_NAME_LEN]));
            }
        }

        if (commonValidator.isEmpty(container.ipAddress)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.CONTAINER_IP_ADDRESS_LOGICAL_NAME));
        } else {
            if (!validator.isLength(container.ipAddress, {max:constant.CONTAINER_IP_ADDRESS_LEN})) {
                msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", [constant.CONTAINER_IP_ADDRESS_LOGICAL_NAME, constant.CONTAINER_IP_ADDRESS_LEN]));
            }
            if (!commonValidator.isSingleByteStr(container.ipAddress)) {
                msgs.msgsError.push(commonUtil.getMsg(req, "MSG0028", constant.CONTAINER_IP_ADDRESS_LOGICAL_NAME));
            }
            if (!validator.isIP(container.ipAddress)) {
                msgs.msgsError.push(commonUtil.getMsg(req, "MSG0013", constant.CONTAINER_IP_ADDRESS_LOGICAL_NAME));
            }

            // 重複チェック中（コンテナ間）
            if (!isDupulicated && ipAddresses[container.ipAddress]) {
                isDupulicated = true;
            } else {
                ipAddresses[container.ipAddress] = true;
            }
        }
    }

    // 重複チェック中（サーバーコンテナ間）
    if (!isDupulicated && ipAddresses[server.ipAddress]) {
        isDupulicated = true;
    }

    // IPアドレス重複チェック
    if (isDupulicated) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0037", constant.CONTAINER_IP_ADDRESS_LOGICAL_NAME));
    }

    return msgs;
};

validators['/servers/upd'] = function(req) {
    return validators['/servers/add'](req);
};

validators['/servers/del'] = function(req) {
    var msgs = commonValidator.initMsgs();
    return msgs;
};

module.exports = {
    // バリデータ取得
    getValidators: function() {
        return commonValidator.validators();
    },
    // 入力チェック
    validate: function(url, req) {
        return commonValidator.validate(url, req);
    },
    // 入力チェック結果を返却する
    hasError: function() {
        return commonValidator.hasError();
    },
    // IPアドレス使用中チェック
    isAvailableIpAddress: function(server, data) {
        var isAvailable = true;
        for (var i=0; i<data.length; i++) {
            var gettedServer = data[i].tblServer;
            //自分自身のデータは同一チェック対象外
            if (gettedServer.orgCd == server.orgCd && gettedServer.serverSeqNo == server.serverSeqNo){
                continue;
            }
            //自分自身以外はIPアドレスの重複チェックを行う
            if (server.ipAddress == gettedServer.ipAddress) {
                isAvailable = false;
                break;
            }
        }
        return isAvailable;
    },
    // サーバ使用中チェック
    isRunningServer: function(containers) {
        var isRunning = false;
        for (var i=0; i<containers.length; i++) {
            //ステータス＝使用中だったらエラー
            if (containers[i].statusCd == "1") {
                isRunning = true;
                break;
            }
        }
        return isRunning;
    }
}
