var validator = require('validator');
var commonUtil = require('../common/commonUtil.js');
var commonValidator = require('./common.js');
var constant = require('../const/images.js');

//ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

// 入力チェック定義
var validators = commonValidator.getValidators();

/**** ▼URLごとに入力チェックを書いていく ****/

validators['/images/get/_edit'] = function(req) {
    var msgs = commonValidator.initMsgs();

    var image = req.body;

    if (commonValidator.isEmpty(image.repositorySeq)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.REPOSITORY_SEQ_LOGICAL_NAME));
    }

    if (commonValidator.isEmpty(image.imageId)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.IMAGE_ID_LOGICAL_NAME));
    }

    return msgs;
};

validators['/images/add'] = function(req) {
    var msgs = commonValidator.initMsgs();

    var image = req.body;

    if (commonValidator.isEmpty(image.repositorySeq)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.REPOSITORY_SEQ_LOGICAL_NAME));
    }

    if (commonValidator.isEmpty(image.imageId)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.IMAGE_ID_LOGICAL_NAME));
    }

    if (commonValidator.isEmpty(image.imageTypeCd)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", constant.IMAGE_TYPE_CD_LOGICAL_NAME));
    } else {
        if (!commonValidator.isValidCodeVal(req.app, 'imageTypeCd', image.imageTypeCd)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0035", constant.IMAGE_TYPE_CD_LOGICAL_NAME));
        }
    }

    return msgs;
};

validators['/images/upd'] = function(req) {
    return validators['/images/add'](req);
};

module.exports = {
    // バリデータ取得
    getValidators: function() {
        return commonValidator.validators();
    },
    // 入力チェック
    validate: function(url, req) {
        return commonValidator.validate(url, req);
    },
    // 入力チェック結果を返却する
    hasError: function() {
        return commonValidator.hasError();
    }
}
