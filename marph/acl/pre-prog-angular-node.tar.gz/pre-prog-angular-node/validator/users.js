var validator = require('validator');
var commonUtil = require('../common/commonUtil.js');
var commonValidator = require('./common.js');

// 入力チェック定義
var validators = commonValidator.getValidators();

// 権限の重複チェック
var rolesDupulicate_validator = function(tblUserRoles) {
    var keys = {};
    for (var i=0; i<tblUserRoles.length; i++) {
        var key = tblUserRoles[i].groupCd + "|" + tblUserRoles[i].roleCd;
        if (keys[key]) {
            return true;
        }
        keys[key] = true;
    }
    return false;
};

/**** ▼URLごとに入力チェックを書いていく ****/

validators['/users/get/_edit'] = function(req) {
    var msgs = commonValidator.initMsgs();
    if (commonValidator.isEmpty(req.body.userId)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "ユーザID"));
    }
    return msgs;
};

validators['/users/add'] = function(req) {
    var msgs = commonValidator.initMsgs();
    if (commonValidator.isEmpty(req.body.tblUser.userId)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "ユーザID"));
    } else {
        if (!commonValidator.isValidUserId(req.body.tblUser.userId)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0033", "ユーザID"));
        }
        if (!validator.isLength(req.body.tblUser.userId, {max:50})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", ["ユーザID", "50"]));
        }
    }

    if (commonValidator.isEmpty(req.body.tblUser.userName)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "ユーザ名"));
    } else {
        if (!validator.isLength(req.body.tblUser.userName, {max:32})) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0005", ["ユーザ名", "32"]));
        }
    }

    if (commonValidator.isEmpty(req.body.tblUser.password)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "パスワード"));
    } else {
        if (!commonValidator.isSingleByteStr(req.body.tblUser.password)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0028", "パスワード"));
        }
        if (!commonValidator.isValidPassword(req.body.tblUser.password)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0030"));
        }
    }

    if (commonValidator.isEmptyArray(req.body.tblUserRoles)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "権限"));
    }

    if (rolesDupulicate_validator(req.body.tblUserRoles)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0016"));
    }

    return msgs;
};

validators['/users/upd'] = function(req) {
    return validators['/users/add'](req);
};

validators['/users/del'] = function(req) {
    var msgs = commonValidator.initMsgs();
    if (commonValidator.isEmpty(req.body.userId)) {
        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "ユーザID"));
    }
    return msgs;
};

validators['/users/password/reset'] = function(req) {
	var msgs = commonValidator.initMsgs();
    for (var i=0; i<req.body.length; i++) {
        if (commonValidator.isEmpty(req.body[i].userId)) {
            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0002", "ユーザID"));
        }
    }
    return msgs;
};

module.exports = {
    // バリデータ取得
    getValidators: function() {
        return commonValidator.validators();
    },
    // 入力チェック
    validate: function(url, req) {
        return commonValidator.validate(url, req);
    },
    // 入力チェック結果を返却する
    hasError: function() {
        return commonValidator.hasError();
    }
}
