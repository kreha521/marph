var router = require('express').Router();
var async = require('async');

// Restクライアント
var Client = require('node-rest-client').Client;
var client = new Client();

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* セッションユーティリティ */
var sessionUtil = require('../common/sessionUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* 共通定数 */
var commonConst = require('../const/common.js');

var constant = require('../const/availableseries.js');
var filter = require('../filter/availableseries.js');
var validator = require('../validator/availableseries.js');

var CryptoJS = require('crypto-js');
// URL生成（利用可能系列情報）
function buildAvailableSeriesEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/availableseries";
}

// URL生成（利用可能コンテナ情報）
function buildAvailableConatinerEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/availablecont";
}

// URL生成（コンテナ基本情報）
function buildContainersEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/containers";
}

// URL生成（環境）
function buildEnvsEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/envs";
}

// 入力チェック
function validate(req, res) {
    var msgs = validator.validate(req.route.path, req)
    if (validator.hasError()) {
        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        logger.debug("Invalid paramaters!");
        logger.trace(msgs);
        res.status(200).send(msgs);
    }
    return msgs;
}

// 利用可能系列情報一覧取得処理
router.post("/availableseries/get/_detail", function(req, res, next) {
    try {
        var transactionNo = sessionUtil.getTransactionNo(req);
        logger.debug(transactionNo);

            var prehash = "ueghoge$1oiashjdfgo;sjdfjhgo;shjdfgljahdlfghjahfdaljghildsjhfgljashdfglijhsgljq929/@p9-au";
            prehash = CryptoJS.enc.Utf8.parse(prehash);

            var sha3 = CryptoJS.algo.SHA3.create();
            sha3.update(prehash);
            var password  = sha3.finalize().toString(CryptoJS.enc.Base64);
            sha3.reset();

            var sha32 = CryptoJS.algo.SHA3.create();
            sha32.update(prehash);
            var password2  = sha32.finalize().toString(CryptoJS.enc.Base64);
            sha32.reset();

            logger.debug('HASHWORD: ' + password);
            logger.debug('HASHWORD2: ' + password2);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        async.waterfall([
            /***
             * 1. 利用可能系列情報のデータを取得する。
             */
            function(callback) {
                //TODO ▼WebSocket調査中（後で消す）
                var psmonitor = require('../websocket/psmonitor');
                psmonitor(req.app, "test1");
                //TODO ▲WebSocket調査中（後で消す）

                var url = buildAvailableSeriesEndPointUrl(req, transactionNo)
                    + "/" + req.body.orgCd + "/" + req.body.groupCd;
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getAvailableSeries", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getAvailableSeries(function (data, response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全利用可能系列情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    // RestAPI(GET)の結果判定はデータなしでもステータス200が返却されるため、取得データとGET種別(1件、N件)により、エラー判定する
                    err = checkUtil.checkGetResponse(req, response, data, false);
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス情報を編集し、編集結果をクライアントへ送信する
            arg0 = filter.resFilter(req.route.path, req, arg0);
            res.send(arg0);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 利用可能系列情報取得処理（新規作成）
router.post("/availableseries/get/_new", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req);

        async.waterfall([
            /***
             * 1. 環境情報のコード値、名称を取得
             */
            function(callback) {
                // 環境一覧の取得
                var url = buildEnvsEndPointUrl(req, transactionNo)
                    + "/" + req.body.orgCd + "/" + req.body.groupCd;
                logger.debug(url);

                client.registerMethod("getEnvs", url, "GET");
                client.methods.getEnvs(function(data, response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全環境取得");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    // RestAPI(GET)の結果判定はデータなしでもステータス200が返却されるため、取得データとGET種別(1件、N件)により、エラー判定する
                    err = checkUtil.checkGetResponse(req, response, data, false);
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }

                    // 取得した環境情報のコード値・名称をレスポンス返却用に編集
                    var envs = filter.resFilterForEnvCdNames(data);
                    callback(null, envs);
                }).on('error', function(err) {
                    next(err);
                })
            },
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            var response = {};
            response.envCds = arg0;

            // レスポンス情報を編集し、編集結果をクライアントへ送信する
            response = filter.resFilter(req.route.path, req, response);
            res.send(response);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 利用可能系列情報取得処理（編集）
router.post("/availableseries/get/_edit", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validate(req, res);
        if (validator.hasError()) {
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        var availableSeries = req.body;

        async.waterfall([
            /***
             * 1. 処理対象の利用可能系列情報を取得する
             */
            function(callback) {
                var url = buildAvailableSeriesEndPointUrl(req, transactionNo)
                    + "/" + availableSeries.orgCd
                    + "/" + availableSeries.groupCd
                    + "/" + availableSeries.envCd
                    + "/" + availableSeries.seriesCd;
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getAvailableSeries", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getAvailableSeries(function (data, response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "利用可能系列情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    // RestAPI(GET)の結果判定はデータなしでもステータス200が返却されるため、取得データとGET種別(1件、N件)により、エラー判定する
                    err = checkUtil.checkGetResponse(req, response, data, true);
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 2. 利用可能コンテナ情報を取得
             */
            function(arg0, callback) {
                var url = buildAvailableConatinerEndPointUrl(req, transactionNo)
                    + "/" + availableSeries.orgCd
                    + "/" + availableSeries.groupCd
                    + "/" + availableSeries.envCd
                    + "/" + availableSeries.seriesCd;
                logger.debug(url);

                //REST APIを登録
                client.registerMethod("getAvailableConatiners", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getAvailableConatiners(function (data,response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "利用可能コンテナ取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, arg0, data);
                }).on('error', function (err) {
                    res.sendStatus(500);
                    console.log('something went wrong on req!!', err.request.options);
                });
            },
            /***
             * 3. 環境情報のコード値、名称を取得
             */
            function(arg0, arg1, callback) {
                // 環境一覧の取得
                var url = buildEnvsEndPointUrl(req, transactionNo)
                    + "/" + availableSeries.orgCd + "/" + availableSeries.groupCd;
                logger.debug(url);

                client.registerMethod("getEnvs", url, "GET");
                client.methods.getEnvs(function(data, response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全環境取得");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    // RestAPI(GET)の結果判定はデータなしでもステータス200が返却されるため、取得データとGET種別(1件、N件)により、エラー判定する
                    err = checkUtil.checkGetResponse(req, response, data, false);
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }

                    // 取得した環境情報のコード値・名称をレスポンス返却用に編集
                    var envs = filter.resFilterForEnvCdNames(data);
                    callback(null, arg0, arg1, envs);
                }).on('error', function(err) {
                    next(err);
                })
            },
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0, arg1, arg2) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス情報を編集し、編集結果をクライアントへ送信する
            var data = {
                "availableSeries": arg0
                , "availableContainers": arg1
                , "envCds": arg2
            };
            data = filter.resFilter(req.route.path, req, data);
            res.send(data);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next) {
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 利用可能系列情報登録処理
router.post("/availableseries/add", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validate(req, res);
        if (validator.hasError()) {
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        var availableSeries = req.body.availableSeries;
        var availableContainers = req.body.availableContainers;

        async.waterfall([
            /***
             * 1. チェック仕様：IPアドレス割り当て可能チェック
            */
            function(callback) {
//TODO チケット#1545の問題にて保留中。コメントアウトしておく。
            var data = "dummy";
            callback(null, data);
//                var url = buildContainersEndPointUrl(req, transactionNo);
//                logger.debug(url);
//
//                // REST APIを登録
//                client.registerMethod("getContainers", url, "GET");
//
//                // 登録したREST APIを実行し、コールバック処理を行う
//                client.methods.getContainers(function (data, response) {
//                    var err = checkUtil.checkStatusCode(req, response.statusCode, "コンテナ基本情報一覧取得");
//                    if (err != null) {
//                        logger.error(data);
//                        next(err);
//                        return;
//                    }
//
//                    for (var i=0; i<availableContainers.length; i++) {
//                        // 取得したデータに対してIPアドレス割り当て可能チェックを実施する
//                        if (!validator.isAvailableIpAddress(availableContainers[i], data)) {
//                            msgs.msgsError.push(commonUtil.getMsg(req, "MSG0042"));
//                            res.status(200).send(msgs);
//                            next();
//                            return;
//                        }
//                    }
//                    callback(null, data);
//                }).on('error', function (err) {
//                    next(err);
//                });
            },
            /***
             * 2. 利用可能系列情報にデータを登録する。
             */
            function(arg0, callback) {
                var url = buildAvailableSeriesEndPointUrl(req, transactionNo);

                // REST APIを登録
                client.registerMethod("addAvailableSeries", url, "POST");

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: availableSeries
                };

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.addAvailableSeries(options, function (data, response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "利用可能系列情報登録");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, arg0, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 3. 利用可能コンテナ情報にデータを登録する。
             */
            function(arg0, arg1, callback) {
                var url = buildAvailableConatinerEndPointUrl(req, transactionNo);

                // REST APIを登録
                client.registerMethod("addAvailableContainers", url, "POST");

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: availableContainers
                };

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.addAvailableContainers(options, function (data, response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "利用可能コンテナ情報登録");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, arg0, arg1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0, arg1, arg2) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス情報を編集し、編集結果をクライアントへ送信する
            arg2 = filter.resFilter(req.route.path, req, arg2);
            res.send(arg2);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//ユーザ情報更新処理
router.post("/availableseries/upd", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validate(req, res);
        if (validator.hasError()) {
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        var availableSeries = req.body.availableSeries;
        var availableContainers = req.body.availableContainers;

        async.waterfall([
            /***
             * 1. チェック仕様：稼働状況チェックをする
             */
            function(callback) {
                var url = buildAvailableSeriesEndPointUrl(req, transactionNo)
                    + "/" + availableSeries.orgCd
                    + "/" + availableSeries.groupCd
                    + "/" + availableSeries.envCd
                    + "/" + availableSeries.seriesCd;
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getAvailableSeries", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getAvailableSeries(function (data, response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "利用可能系列情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    // RestAPI(GET)の結果判定はデータなしでもステータス200が返却されるため、取得データとGET種別(1件、N件)により、エラー判定する
                    err = checkUtil.checkGetResponse(req, response, data, true);
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }

                    // 取得したデータに対して稼働状況チェックを実施する
                    if (data.statusCd == '1') {
                        // 更新対象の系列が稼働中である場合は、更新処理をしない。
                        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0034"));
                        res.status(200).send(msgs);
                        next();
                        return;
                    }
                    callback(null, 1);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 2. 利用可能系列情報のデータを更新する
             */
            function(arg0, callback) {
                var url = buildAvailableSeriesEndPointUrl(req, transactionNo)
                    + "/" + availableSeries.orgCd
                    + "/" + availableSeries.groupCd
                    + "/" + availableSeries.envCd
                    + "/" + availableSeries.seriesCd;
                logger.debug(url);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: availableSeries
                };

                // REST APIを登録
                client.registerMethod("updateAvailableSeries", url, "PUT");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.updateAvailableSeries(options, function (data, response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "利用可能系列情報更新");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, arg0, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 3. 利用可能コンテナ情報のデータを削除する
             */
            function(arg0, arg1, callback) {
                var url = buildAvailableConatinerEndPointUrl(req, transactionNo)
                    + "/" + availableSeries.orgCd
                    + "/" + availableSeries.groupCd
                    + "/" + availableSeries.envCd
                    + "/" + availableSeries.seriesCd
                    + "/all";
                logger.debug(url);

                var options = {
                    headers: {"Content-Type": "application/json"},
                };

                // REST APIを登録
                client.registerMethod("deleteAvailableConatiners", url, "DELETE");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.deleteAvailableConatiners(options, function (data, response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "利用可能コンテナ情報削除");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, arg0, arg1, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 4. 利用可能コンテナ情報のデータを登録する
             */
            function(arg0, arg1, arg2, callback) {
                var url = buildAvailableConatinerEndPointUrl(req, transactionNo);

                // REST APIを登録
                client.registerMethod("addAvailableContainers", url, "POST");

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: availableContainers
                };

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.addAvailableContainers(options, function (data, response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "利用可能コンテナ情報登録");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, arg0, arg1, arg2, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0, arg1, arg2, arg3) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス情報を編集し、編集結果をクライアントへ送信する
            arg1 = filter.resFilter(req.route.path, req, arg1);
            res.send(arg1);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 利用可能系列情報削除処理
router.post("/availableseries/delete", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validate(req, res);
        if (validator.hasError()) {
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        var availableSeries = req.body;

        async.waterfall([
            /***
             * 1. チェック仕様：稼働状況チェックをする
             */
            function(callback) {
                var url = buildAvailableSeriesEndPointUrl(req, transactionNo)
                    + "/" + availableSeries.orgCd
                    + "/" + availableSeries.groupCd
                    + "/" + availableSeries.envCd
                    + "/" + availableSeries.seriesCd;
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getAvailableSeries", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getAvailableSeries(function (data, response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "利用可能系列情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    // RestAPI(GET)の結果判定はデータなしでもステータス200が返却されるため、取得データとGET種別(1件、N件)により、エラー判定する
                    err = checkUtil.checkGetResponse(req, response, data, true);
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }

                    // 取得したデータに対して稼働状況チェックを実施する
                    if (data.statusCd == '1') {
                        // 削除対象の系列が稼働中である場合は、削除処理をしない
                        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0034"));
                        res.status(200).send(msgs);
                        next();
                        return;
                    }
                    callback(null, 1);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 2. 利用可能系列情報、利用可能コンテナ情報のデータを削除する
             */
            function(arg0, callback) {
                var url = buildAvailableSeriesEndPointUrl(req, transactionNo)
                    + "/" + availableSeries.orgCd
                    + "/" + availableSeries.groupCd
                    + "/" + availableSeries.envCd
                    + "/" + availableSeries.seriesCd;
                logger.debug(url);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: availableSeries
                };

                // REST APIを登録
                client.registerMethod("deleteAvailableSeries", url, "DELETE");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.deleteAvailableSeries(options, function (data, response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "利用可能系列情報削除");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス情報を編集し、編集結果をクライアントへ送信する
            arg1 = filter.resFilter(req.route.path, req, arg1);
            res.send(arg1);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

/***
 * 例外エラー発生時
 */
client.on('error', function (err) {
    logger.error(err);
    next(err);
});

module.exports = router;

