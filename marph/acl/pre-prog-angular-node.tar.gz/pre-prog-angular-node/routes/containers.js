var express = require('express');
var router = express.Router();

// Restクライアント
var Client = require('node-rest-client').Client;
var client = new Client();

var async = require('async');

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッションユーティリティ */
var sessionUtil = require('../common/sessionUtil.js');

var filter = require('../filter/containers.js');
//var validator = require('../validator/containers.js');

function buildContainersEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/containers";
}

// コンテナ基本情報一覧取得処理
router.post("/containers/get/_detail", function(req, res, next) {
    try {
        var transactionNo = sessionUtil.getTransactionNo(req);
        logger.debug(transactionNo);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        async.waterfall([
            function(callback) {

                var url = buildContainersEndPointUrl(req, transactionNo);
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getContainers", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getContainers(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "コンテナ基本情報一覧取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
        }], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);
            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});


// コンテナ基本情報削除処理
router.post("/containers/delete", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        var transactionNo = sessionUtil.getTransactionNo(req)

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        async.waterfall([
            function(callback) {
                var url = buildContainersEndPointUrl(req, transactionNo);

                logger.debug(req.body);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // REST APIを登録
                var pkeys = sessionUtil.getOrgCd(req)
                    + "/" + req.body.serverSeqNo
                    + "/" + req.body.containerTypeCd
                    + "/" + req.body.seqNo;

                client.registerMethod("deleteContainers", url + "/" + pkeys, "DELETE");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.deleteContainers(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "TODO:API論理名に変えること");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});


// コンテナ編集情報取得
router.post("/containers/get/_edit", function(req, res, next) {
    try {
        var transactionNo = sessionUtil.getTransactionNo(req);
        logger.debug(transactionNo);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        async.waterfall([
            function(callback) {
                var url = buildContainersEndPointUrl(req, transactionNo);

                var orgCd = req.body.orgCd;
                var serverSeqNo = req.body.serverSeqNo;

                var pkey = orgCd + "/" + serverSeqNo;

                // REST APIを登録
                client.registerMethod("getContainers",  url + "/" + pkey, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getContainers(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "TODO:API論理名に変えること");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
        }], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);
            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('user edit was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// コンテナ新規情報取得
router.post("/containers/get/_new", function(req, res, next) {
    try {
        var transactionNo = sessionUtil.getTransactionNo(req);
        logger.debug(transactionNo);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        async.waterfall([
            function(callback) {

                var url = buildContainersEndPointUrl(req, transactionNo);
                logger.debug(url);

                var orgCd = req.body.orgCd
                var serverSeqNo = req.body.serverSeqNo

                var pkey = orgCd + "/" + serverSeqNo

                // REST APIを登録
                client.registerMethod("getContainers",  url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getContainers(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "TODO:API論理名に変えること");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
        },function(arg0, arg1, callback) {
            // 組織コード一覧取得

                //URLの生成
                var url = commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/organizations";

                // ユーザ権限登録REST APIを登録
                client.registerMethod("getOrgCd", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getOrgCd(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "組織コード一覧取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    logger.debug(data);

                    // 取得した環境情報のコード値・名称をレスポンス返却用に編集
                    var orgs = [];
                    for (i in data) {
                        var orgsData = {"cd": data[i].orgCd, "name": data[i].orgName};
                        orgs.push(orgsData);
                    }


                    callback(null, arg1, orgs);

                }).on('error', function (err) {
                    res.sendStatus(500);
                    console.log('something went wrong on req!!', err.request.options);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }


            logger.debug(arg0);
            logger.debug("orgs:" + arg1);

            // レスポンス編集
            var resData = filter.resFilter(req.route.path, req, arg0);

            resData.orgs = arg1;
            logger.debug(resData);
            res.send(resData);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('user edit was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});



module.exports = router;
