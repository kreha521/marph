var router = require('express').Router();
var async = require('async');

// Restクライアント
var Client = require('node-rest-client').Client;
var client = new Client();

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッションユーティリティ */
var sessionUtil = require('../common/sessionUtil.js');

var filter = require('../filter/groups.js');
var validator = require('../validator/groups.js');

function buildGroupsEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/groups";
}

function buildGroupsOneEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/group";
}

function buildOrganizationsEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/organizations";
}

// 領域一覧 取得処理
router.post("/groups/get/_detail", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req);
        logger.debug(transactionNo);

        async.waterfall([
            function(callback) {
                var url = buildGroupsEndPointUrl(req, transactionNo);
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getGroups", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getGroups(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全領域取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('group list was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 領域一覧情報 削除処理
router.post("/groups/del", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildGroupsEndPointUrl(req, transactionNo);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // REST APIを登録
                client.registerMethod("deleteGroup", url + "/" + req.body.orgCd + "/" + req.body.groupCd, "DELETE");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.deleteGroup(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "領域削除");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 領域情報 初期表示処理
router.post("/groups/get/_new", function(req, res, next) {
    try {
        logger.debug(transactionNo);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req);
        logger.debug(transactionNo);

        async.waterfall([
            function(callback) {
                var selectData = {};
                var url = buildOrganizationsEndPointUrl(req, transactionNo);
                logger.debug(url);

                orgCd = sessionUtil.getOrgCd(req);
                groupCd = sessionUtil.getGroupCd(req);

                // REST APIを登録
                client.registerMethod("getSelects", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getSelects(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全組織情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    var orgResData = [];
                    for (i in data) {
                        var tmpOrgCd = data[i].orgCd;
                        var tmpOrgName = data[i].orgName;
                        var tmp = {cd : tmpOrgCd , name : tmpOrgName};
                        orgResData.push(tmp);
                    }
                    selectData.orgCds = orgResData;
                    callback(null, 1, selectData);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 領域情報取得処理（編集）
router.post("/groups/get/_edit", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        logger.debug(transactionNo);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildGroupsOneEndPointUrl(req, transactionNo);

                // REST APIを登録
                client.registerMethod("getGroupsOne", url + "/" + req.body.orgCd + "/" + req.body.groupCd, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getGroupsOne(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "領域取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            function(arg0,arg1,callback) {
                var url = buildOrganizationsEndPointUrl(req, transactionNo);
                logger.debug(url);

                orgCd = sessionUtil.getOrgCd(req);
                groupCd = sessionUtil.getGroupCd(req);

                // REST APIを登録
                client.registerMethod("getSelects", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getSelects(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全組織情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    var orgResData = [];
                    for (i in data) {
                        var tmpOrgCd = data[i].orgCd;
                        var tmpOrgName = data[i].orgName;
                        var tmp = {cd : tmpOrgCd , name : tmpOrgName};
                        orgResData.push(tmp);
                    }
                    arg1.orgCds = orgResData;
                    callback(null, 2, arg1);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 領域情報 登録処理
router.post("/groups/add", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildGroupsEndPointUrl(req, transactionNo);

                // REST APIを登録
                client.registerMethod("addGroup", url, "POST");

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.addGroup(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "領域登録");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 領域情報 更新処理
router.post("/groups/upd", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildGroupsEndPointUrl(req, transactionNo);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // REST APIを登録
                client.registerMethod("updGroup", url + "/" + req.body.orgCd + "/" + req.body.groupCd, "PUT");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.updGroup(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "領域更新");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

client.on('error', function (err) {
    logger.error(err);
    next(err);
});

module.exports = router;
