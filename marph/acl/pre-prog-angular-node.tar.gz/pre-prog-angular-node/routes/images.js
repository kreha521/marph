var router = require('express').Router();
var async = require('async');

// Restクライアント
var Client = require('node-rest-client').Client;
var client = new Client();

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッションユーティリティ */
var sessionUtil = require('../common/sessionUtil.js');

var filter = require('../filter/images.js');
var validator = require('../validator/images.js');

// URL生成（イメージ情報）
function buildImagesEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/images";
}

// URL生成（イメージID情報）
function buildImagessonCurlEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/imagesoncurl";
}

// URL生成（案件情報）
function buildProjectsEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/projects";
}

// 入力チェック
function validate(req, res) {
    var msgs = validator.validate(req.route.path, req)
    if (validator.hasError()) {
        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        logger.debug("Invalid paramaters!");
        logger.trace(msgs);
        res.status(200).send(msgs);
    }
    return msgs;
}

// イメージ情報一覧取得処理
router.post("/images/get/_detail", function(req, res, next) {
    try {
        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req);

        var image = req.body

        async.waterfall([
            function(callback) {
                /***
                 * 1. イメージID・名称の一覧を取得する。
                 */
                var url = buildImagessonCurlEndPointUrl(req, transactionNo)
                    + "/" + image.orgCd
                    + "/" + image.groupCd
                    + "/" + image.repositorySeq;
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getImageWithRepositoryOnCurl", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getImageWithRepositoryOnCurl(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "リポジトリ指定イメージ取得");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg0 = filter.resFilter(req.route.path, req, arg0);
            res.send(arg0);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// イメージ情報取得処理（編集）
router.post("/images/get/_edit", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validate(req, res);
        if (validator.hasError()) {
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        var image = req.body

        async.waterfall([
            /***
             * 1. 案件情報を取得する。
             */
            function(callback) {
                var url = buildProjectsEndPointUrl(req, transactionNo)
                    + "/" + image.orgCd
                    + "/" + image.groupCd
                    + "/" + image.repositorySeq;
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getProject", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getProject(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "案件取得");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 2. イメージ情報を取得する。
             */
            function(arg0, callback) {
                // 共通イメージの場合は、DBから取得できないので、スキップ
                if (checkUtil.isCommonImageTypeCd(image.imageId)) {
                    callback(null, arg0, {});
                    return;
                }

                // イメージ情報の取得
                var url = buildImagesEndPointUrl(req, transactionNo)
                    + "/" + image.orgCd
                    + "/" + image.groupCd
                    + "/" + image.repositorySeq
                    + "/" + image.imageId;
                logger.debug(url);

                client.registerMethod("getImage", url, "GET");
                client.methods.getImage(function(data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "イメージ取得");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, arg0, data);
                }).on('error', function(err) {
                    next(err);
                })
            },
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }

            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            var resData = {
                "tblRepositoryInfo": arg0
                , "tblImages": arg1
            };
            resData = filter.resFilter(req.route.path, req, resData);
            res.send(resData);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// イメージ情報登録処理
router.post("/images/add", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validate(req, res);
        if (validator.hasError()) {
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        var image = req.body;

        async.waterfall([
            /***
             * 1. イメージ情報を追加する。
             */
            function(callback) {
                var url = buildImagesEndPointUrl(req, transactionNo);

                // REST APIを登録
                client.registerMethod("addImage", url, "POST");

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: image
                };

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.addImage(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "イメージ登録");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0) {
            if (err) {
                throw err;
            }

            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg0 = filter.resFilter(req.route.path, req, arg0);
            res.send(arg0);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//TODO 更新の仕様策定中
// イメージ情報更新処理
router.post("/images/upd", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validate(req, res);
        if (validator.hasError()) {
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        var image = req.body;

        async.waterfall([
            function(callback) {
                var url = buildImagesEndPointUrl(req, transactionNo)
                    + "/" + image.orgCd
                    + "/" + image.groupCd
                    + "/" + image.envCd
                    + "/" + image.seriesCd;
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getAvailableSeries", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getAvailableSeries(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "TODO:API論理名に変えること");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    if (data.statusCd == '1') {
                        // 削除対象の系列が稼働中である場合は、削除処理をしない
                        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0034"));
                        res.status(200).send(msgs);
                        next();
                        return;
                    }
                    callback(null, 1);
                }).on('error', function (err) {
                    next(err);
                });
            },
            function(arg0, callback) {
                var url = buildImagesEndPointUrl(req, transactionNo)
                    + "/" + req.body.orgCd
                    + "/" + req.body.groupCd
                    + "/" + req.body.envCd
                    + "/" + req.body.seriesCd;
                logger.debug(url);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // REST APIを登録
                client.registerMethod("updateAvailableSeries", url, "PUT");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.updateAvailableSeries(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "TODO:API論理名に変えること");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

/***
 * 例外エラー発生時
 */
client.on('error', function (err) {
    logger.error(err);
    next(err);
});

module.exports = router;

