var router = require('express').Router();
var async = require('async');

// Restクライアント
var Client = require('node-rest-client').Client;
var client = new Client();

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッションユーティリティ */
var sessionUtil = require('../common/sessionUtil.js');

var filter = require('../filter/organizations.js');
var validator = require('../validator/organizations.js');

function buildOrganizationsEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/organizations";
}

// 組織情報取得処理
router.post("/organizations/get/_detail", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req);

        async.waterfall([
            function(callback) {
                var url = buildOrganizationsEndPointUrl(req, transactionNo);
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getOrganizations", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getOrganizations(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "TODO:API論理名に変えること");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            logger.debug(arg1);
            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 組織情報取得処理（編集）
router.post("/organizations/get/_edit", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req);
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req);

        async.waterfall([
            function(callback) {
                var url = buildOrganizationsEndPointUrl(req, transactionNo);

                // REST APIを登録
                client.registerMethod("getOrganization", url + "/" + req.body.orgCd, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getOrganization(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "TODO:API論理名に変えること");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            arg1 = filter.resFilter(req.route.path, req, arg1);
            res.send(arg1);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//組織情報登録処理
router.post("/organizations/add", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req);

        async.waterfall([
            function(callback) {
                var url = buildOrganizationsEndPointUrl(req, transactionNo);

                // REST APIを登録
                client.registerMethod("addOrganization", url, "POST");

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body.tblOrganization
                };

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.addOrganization(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "TODO:API論理名に変えること");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);
            logger.debug(arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        })
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res,next) {
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//組織情報更新処理
router.post("/organizations/upd", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req);

        async.waterfall([
            function(callback) {
                var url = buildOrganizationsEndPointUrl(req, transactionNo);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body.tblOrganization
                };

                // REST APIを登録
                client.registerMethod("updateOrganization", url + "/" + req.body.tblOrganization.orgCd, "PUT");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.updateOrganization(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "TODO:API論理名に変えること");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);
            logger.debug(arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//組織情報削除処理
router.post("/organizations/del", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildOrganizationsEndPointUrl(req, transactionNo);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // REST APIを登録
                client.registerMethod("deleteOrganization", url + "/" + req.body.orgCd, "DELETE");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.deleteOrganization(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "TODO:API論理名に変えること");
                    if (err != null) {
                        logger.error(data);
                        next(err); 
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);
            logger.debug(arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

client.on('error', function (err) {
    logger.error(err);
    next(err);
});

module.exports = router;

