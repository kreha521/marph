var router = require('express').Router();
var async = require('async');

// Restクライアント
var Client = require('node-rest-client').Client;
var client = new Client();

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッションユーティリティ */
var sessionUtil = require('../common/sessionUtil.js');

var filter = require('../filter/imagesets.js');
var validator = require('../validator/imagesets.js');

//イメージセットAPI
function buildImagesetsEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/imagesets";
}

//案件（リポジトリ）API
function buildProjectsEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/projects";
}

// イメージセット情報 取得処理
router.post("/imagesets/get/_detail", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req);
        logger.debug(transactionNo);

        async.waterfall([
            function(callback) {
                var url = buildImagesetsEndPointUrl(req, transactionNo);
                logger.debug(url);

                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);

                // REST APIを登録
                client.registerMethod("getImagesets", url + "/" + orgCd + "/" + groupCd, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getImagesets(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全イメージセット取得");
                    if (err != null) {
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// イメージセット情報 削除処理
router.post("/imagesets/del", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildImagesetsEndPointUrl(req, transactionNo);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);

                // REST APIを登録
                client.registerMethod("deleteImagesets", url + "/" + orgCd + "/" + groupCd + "/" + req.body.repositorySeq + "/" + req.body.imagesetSeq, "DELETE");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.deleteImagesets(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "イメージセット削除");
                    if (err != null) {
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// イメージセット情報 初期表示処理
router.post("/imagesets/get/_new", function(req, res, next) {
    try {
        logger.debug(req.route.path);
        // リクエスト編集
        filter.reqFilter(req.route.path, req);
        //トランザクションNo取得
        var transactionNo = sessionUtil.getTransactionNo(req);
        logger.debug(transactionNo);

        async.waterfall([
            function(callback) {
                var url = buildProjectsEndPointUrl(req, transactionNo);
                logger.debug(url);

                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);

                // REST APIを登録
                client.registerMethod("getSelects", url + "/" + orgCd + "/" + groupCd, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getSelects(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全案件取得");
                    if (err != null) {
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            var resData = {};
            //案件セレクトボックスデータ
            resData.prdTypeCds = arg1;

            // レスポンス編集
            resData = filter.resFilter(req.route.path, req, resData);

            res.send(resData);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// ユーザ情報取得処理（編集）
router.post("/imagesets/get/_edit", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildImagesetsEndPointUrl(req, transactionNo);

                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);

                // REST APIを登録
                client.registerMethod("getImagesetsDetail", url + "/" + orgCd + "/" + groupCd + "/" + req.body.repositorySeq + "/" + req.body.imagesetSeq, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getImagesetsDetail(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "イメージセット取得");
                    if (err != null) {
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            function(arg0, arg1, callback) {
                var url = buildProjectsEndPointUrl(req, transactionNo);
                logger.debug(url);

                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);

                // REST APIを登録
                client.registerMethod("getSelects", url + "/" + orgCd + "/" + groupCd, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getSelects(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全案件取得");
                    if (err != null) {
                        next(err);
                        return;
                    }
                    var resData = {};
                    //イメージセットデータ
                    resData.imageSet = arg1;
                    //案件セレクトボックスデータ
                    resData.prdTypeCds = data;

                    callback(null, 1, resData);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//イメージセット情報 登録処理
router.post("/imagesets/add", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)
        logger.debug(transactionNo);

        async.waterfall([
            function(callback) {
                var url = buildImagesetsEndPointUrl(req, transactionNo);

                // REST APIを登録
                client.registerMethod("addImageset", url, "POST");

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.addImageset(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "イメージセット登録");
                    if (err != null) {
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// イメージセット情報 更新処理
router.post("/imagesets/upd", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        filter.reqFilter(req.route.path, req);
        logger.debug(req.body);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildImagesetsEndPointUrl(req, transactionNo);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);

                // REST APIを登録
                client.registerMethod("updImageset", url + "/" + orgCd + "/" + groupCd + "/" + req.body.imgSet.repositorySeq + "/" + req.body.imgSet.imagesetSeq, "PUT");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.updImageset(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "イメージセット更新");
                    if (err != null) {
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

client.on('error', function (err) {
    logger.error(err);
    next(err);
});

module.exports = router;
