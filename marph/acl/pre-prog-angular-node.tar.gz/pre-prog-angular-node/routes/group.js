var express = require('express');
var router = express.Router();

var Client = require('node-rest-client').Client;
var client = new Client();

var async = require('async');

var filter = require('../filter/group.js');
/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッション共通部品 */
var sessionUtil = require('../common/sessionUtil.js');
//ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

//領域情報全取得URL
function buildEndPointGetAllGroupsUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/groups";
};

//ユーザ情報取得URL
function buildEndPointGetUserUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/users/" + sessionUtil.getUserId(req);
}


//領域選択_一覧取得
router.post("/group/get/_list", function(req, res, next) {
    try {
        filter.reqFilter(req.route.path, req);
        var transactionNo = sessionUtil.getTransactionNo(req);
        async.waterfall([
        function(callback) {
            //ユーザ情報取得
            var url = buildEndPointGetUserUrl(req, transactionNo);
            client.registerMethod("getUser", url, "GET");
            client.methods.getUser(function(data, response) {
                var err = checkUtil.checkStatusCode(req, response.statusCode, "領域選択処理");
                if (err != null) {
                    logger.error(data);
                    next(err);
                    return;
                }
                callback(null, data);
            });

        }, function(arg0, callback) {//arg0:ユーザ情報
            //全領域情報を取得する
            var url = buildEndPointGetAllGroupsUrl(req, transactionNo);
            client.registerMethod("getGroup", url, "GET");

            // 登録したREST APIを実行し、コールバック処理を行う
            client.methods.getGroup(function (data, response) {
                var err = checkUtil.checkStatusCode(req, response.statusCode, "領域選択処理");
                if (err != null) {
                    logger.error(data);
                    next(err);
                    return;
                }
                callback(null, arg0, data);
            }).on('error', function (err) {
                next(err);
            });
        }, function(arg0, arg1, callback) {//arg0:ユーザ情報, arg1:全領域情報
            //権限リストを取得
            var userRoles = arg0.tblUserRoles;
            var resData = [];
            //権限リスト数繰り返す
            async.mapSeries(userRoles, function(data, next) {
                //領域コード
                var groupCd = data.groupCd;
                //領域情報と領域コードを突き合わせて、レスポンスを返却する
                for (i in arg1) {
                    if (groupCd == arg1[i].grps.groupCd) {
                        resData.push(arg1[i]);
                        break;
                    }
                }
                next(null,data);
            }, function(err, results) {
                callback(null, resData);
            })
        }],function(err, arg0) {
            if (err) {
                next(err);
            }
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            res.send(filter.resFilter(req.route.path, req, arg0));
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});


//領域選択_選択
router.post("/group/select", function(req, res) {
    filter.reqFilter(req.route.path, req);
    //とってきた領域情報をセッションに格納
    var group = req.body;
    logger.debug('領域コード：' + group.grps.groupCd);
    logger.debug('組織コード：' + group.orgs.orgCd);
    logger.debug('領域名：' + group.grps.groupName);
    logger.debug('組織名：' + group.orgs.orgName);
    logger.debug('領域略称：' + group.grps.groupShortCd);
    //セッションに必要な情報をセットする
    sessionUtil.setGroupCd(req,group.grps.groupCd); //領域コード
    sessionUtil.setOrgCd(req,group.orgs.orgCd); //組織コード
    sessionUtil.setGroupName(req,group.grps.groupName); //領域名称
    sessionUtil.setOrgName(req,group.orgs.orgName); //組織名称
    sessionUtil.setGroupShortCd(req,group.grps.groupShortCd);   //領域略称コード

    commonUtil.commitTransaction(req, sessionUtil.getTransactionNo(req));

    res.send(filter.resFilter(req.route.path, req, 'check OK'));

},function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

module.exports = router;
