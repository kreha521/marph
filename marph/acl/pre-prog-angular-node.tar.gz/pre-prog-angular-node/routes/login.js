var express = require('express');
var router = express.Router();
var sessionUtil = require('../common/sessionUtil.js');
var db = require('../common/db.js');
var async = require('async');
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();
var filter = require('../filter/login.js');

router.post('/login', function(req,res,next) {

    filter.reqFilter(req.route.path, req);
    //チェック
    /* リクエストパラメータからユーザID及びパスワードを取得 */
    var userid = req.body.userid;
    var password = req.body.password;

    /* MySQLへのコネクションの取得 */
    var connection = db.getConnection();

    async.waterfall([
        function(callback) {
            /* ユーザ情報の取得 */
            connection.query('select * from TBL_USER where userId = ? and password = ?',[userid, password],function(error, rows, fields) {
                var resData ={};
                if (error) {
                    throw error;
                    return;
                } else {
                    if (rows.length != 0) {
                        /* セッションにユーザ情報を詰める */
                        sessionUtil.setUserId(req, rows[0].userId);
                        sessionUtil.setUserName(req, rows[0].userName);
                        sessionUtil.setPrivilegeFlg(req, rows[0].privilegeFlg);
                        sessionUtil.setPwTempFlg(req, rows[0].pwTempFlg);
                        //レスポンスとして、ユーザID、特権フラグ、仮パスワードフラグ
                        resData = {userId: rows[0].userId, priviledgeFlg: rows[0].privilegeFlg, pwTempFlg: rows[0].pwTempFlg};
                        callback(null, resData);
                    } else {
                        /* Unauthorized */
                        res.sendStatus(401);
                        next();
                    }
                }
            })},
        function(arg0, callback) {
            /* mysqlへの接続を切ります */
            db.closeConnection(connection);
            callback(null, arg0);
        }
    ], function(err, result) {
        if (err) throw err;
        /* status ok */
        res.send(filter.resFilter(req.route.path, req, result));
        logger.info('async done');
        next();
    });
}, function(req,res, next) {
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});


module.exports = router;
