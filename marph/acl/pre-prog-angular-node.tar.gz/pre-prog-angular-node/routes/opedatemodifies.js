var router = require('express').Router();
var async = require('async');

// Restクライアント
var Client = require('node-rest-client').Client;
var client = new Client();

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッションユーティリティ */
var sessionUtil = require('../common/sessionUtil.js');

var filter = require('../filter/opedatemodifies.js');
var validator = require('../validator/opedatemodifies.js');

function buildOpeDateEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/opedatemodifies";
}

// 業務日付変更処理
// 環境情報 更新処理
router.post("/opedatemodifies/upd", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildOpeDateEndPointUrl(req, transactionNo);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // REST APIを登録
                client.registerMethod("updOpeDate", url + "/" + req.body.envCd + "/" + req.body.seriesCd + "/" + req.body.opeDate, "PUT");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.updOpeDate(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "業務日付更新");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('opedatemodifies edit was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

/***
 * 例外エラー発生時
 */
client.on('error', function (err) {
    logger.error(err);
    next(err);
});

module.exports = router;
