var app = require('express');

var router = require('express').Router();
var async = require('async');
var multer = require('multer');
var bodyParser = require('body-parser');
var multipart = require('connect-multiparty');

// Restクライアント
var Client = require('node-rest-client').Client;
var client = new Client();

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();


/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* セッションユーティリティ */
var sessionUtil = require('../common/sessionUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* 共通定数 */
var commonConst = require('../const/common.js');

var filter = require('../filter/tableimport.js');
//var validator = require('../validator/tableimport.js');

// URL生成（インポート先コンテナ情報）
function buildContainerEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/dataimport";
}

// 入力チェック
function validate(req, res) {
    var msgs = validator.validate(req.route.path, req)
    if (validator.hasError()) {
        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        logger.debug("Invalid paramaters!");
        logger.trace(msgs);
        res.status(200).send(msgs);
    }
    return msgs;
}

// データインポート先コンテナ情報取得処理
router.post("/tableimport/get", function(req, res, next) {
    try {
        var transactionNo = sessionUtil.getTransactionNo(req);
        logger.debug(transactionNo);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        async.waterfall([
            function(callback) {
                var pkeys = sessionUtil.getOrgCd(req)
                    + "/" + sessionUtil.getGroupCd(req)
                    + "/" + req.body.envCd
                    + "/" + req.body.seriesCd;

                 var url = buildContainerEndPointUrl(req, transactionNo) + "/" + pkeys;
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getContainerInfo", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getContainerInfo(function (data, response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "// データインポート先コンテナ情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    // RestAPI(GET)の結果判定はデータなしでもステータス200が返却されるため、取得データとGET種別(1件、N件)により、エラー判定する
                    err = checkUtil.checkGetResponse(req, response, data, true);
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
        ], function(err, arg0) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス情報を編集し、編集結果をクライアントへ送信する
            arg0 = filter.resFilter(req.route.path, req, arg0);
            res.send(arg0);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});



//fileupload用に追記
//var storage = multer.diskStorage({
//    destination: function (req, file, cb) {
//        cb(null, 'import_dataaaaaaaaaaaaaaaaa/')
//    },
//    filename: function (req, file, cb) {
//        cb(null, file.fileName)
//    }
//})
//var upload = multer(
//    {
//        storage: storage
//    });

var upload = multer({ dest: 'import_data/' });


var multipartMiddleware = multipart();

 router.post('/tableimport/add', [multipartMiddleware, upload.any(), function(req, res) {
     logger.debug(req.headers['content-type'])
     var file = req.body.file;
      logger.debug(req.body.file);
      logger.debug(req.files);

   res.end();
 }]);

// catch 404 and forward to error handler
router.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

module.exports = router;
