var express = require('express');
var router = express.Router();


var Client = require('node-rest-client').Client;
var client = new Client();

var async = require('async');

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッション共通部品 */
var sessionUtil = require('../common/sessionUtil.js');

var filter = require('../filter/availablecontainer.js');

const URL_TRANSACTION = "http://localhost:10000/v1/transaction";

function buildContainersEndPointUrl(req, transactionNo) {
    return URL_TRANSACTION + "/" + sessionUtil.getTransactionNo(req, transactionNo) + "/availablecont";
}

//利用可能コンテナ一覧_一覧取得
router.post("/availablecont/get/_detail", function(req, res, next) {
    try {
        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
        function(callback) {
            var pkeys = sessionUtil.getOrgCd(req)
                    + "/" + sessionUtil.getGroupCd(req);

            //REST APIを登録
            var url = buildContainersEndPointUrl(req, transactionNo) + "/" + pkeys;
            client.registerMethod("getAvailablecont", url, "GET");

            // 登録したREST APIを実行し、コールバック処理を行う
            client.methods.getAvailablecont(function (data,response) {
                var err = checkUtil.checkStatusCode(req, response.statusCode, "利用可能コンテナ情報取得");
                if (err != null) {
                    logger.error(data);
                    next(err);
                    return;
                }
                callback(null, 1, data);
            }).on('error', function (err) {
                    next(err);
            });
        }], function(err, arg0, arg1) {
                if (err) {
                    throw err;
                }
                /* トランザクションのcommit */
                try {
                    commonUtil.commitTransaction(req, transactionNo);
                } catch(e) {
                    next(e);
                }
                // レスポンス編集
                arg1 = filter.resFilter(req.route.path, req, arg1);

                res.send(arg1);
                logger.debug('all done.');
                next();
            });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//利用可能コンテナ一覧_詳細
router.post("/availablecont/get/_edit", function(req, res, next) {
    try {
        var transactionNo = sessionUtil.getTransactionNo(req)

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        async.waterfall([
        function(callback) {

       // 環境コード、系列コードを取得→URL反映
        var pkeys = sessionUtil.getOrgCd(req)
                + "/" + sessionUtil.getGroupCd(req)
                + "/" + req.body.envCd
                + "/" + req.body.seriesCd;

        var url = buildContainersEndPointUrl(req, transactionNo) + "/" + pkeys;
        client.registerMethod("getEditcont", url, "GET");

        // 登録したREST APIを実行し、コールバック処理を行う
        client.methods.getEditcont(function (data,response) {
            var err = checkUtil.checkStatusCode(req, response.statusCode, "TODO:API論理名に変えること");
            if (err != null) {
                logger.error(data);
                next(err);
                return;
            }
            callback(null, 1, data);
        }).on('error', function (err) {
            res.sendStatus(500);
            console.log('something went wrong on req!!', err.request.options);
        });
        },function(arg0, arg1, callback) {
            // 系列コード一覧取得

                //URLの生成
                var pkeys = sessionUtil.getOrgCd(req)
                    + "/" + sessionUtil.getGroupCd(req)

                var url = URL_TRANSACTION + "/" + sessionUtil.getTransactionNo(req) + "/availableseries" + "/" + pkeys;

                // ユーザ権限登録REST APIを登録
                client.registerMethod("getSeriesCd", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getSeriesCd(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "系列コード一覧取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    logger.debug(data);

                    // 取得した環境情報のコード値・名称をレスポンス返却用に編集
                    var series = [];
                    for (i in data) {
                        var seriesData = {"cd": data[i].series.seriesCd, "name": data[i].series.seriesName};
                        series.push(seriesData);
                    }


                    callback(null, arg1, series);

                }).on('error', function (err) {
                    res.sendStatus(500);
                    console.log('something went wrong on req!!', err.request.options);
                });
            }
        ], function(err, arg0, arg1) {
                if (err) {
                    throw err;
                }
                /* トランザクションのcommit */
                try {
                    commonUtil.commitTransaction(req, transactionNo);
                } catch(e) {
                    next(e);
                }
                // レスポンス編集

                arg0.series = arg1
                logger.debug(arg0);

                var resData = filter.resFilter(req.route.path, req, arg0);
                res.send(resData);
                logger.debug('all done.');
                next();
            });
        } catch (e) {
            logger.error(e);
            throw e;
        }
    }, function(req,res, next){
        logger.debug('All process was done! trx no session scope will be closed!');
        sessionUtil.closeReqScope(req);
});


//利用可能コンテナ一覧_新規
router.post("/availablecont/get/_new", function(req, res, next) {
    try {
        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req);

        async.waterfall([
            function(callback) {
                var pkeys = sessionUtil.getOrgCd(req)
                + "/" + sessionUtil.getGroupCd(req)
                + "/" + req.body.envCd;
    
                var url = buildContainersEndPointUrl(req, transactionNo) + "/" + pkeys;
    
                client.registerMethod("getContainerCds", url, "GET");
    
                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getContainerCds(function (data,response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "TODO:API論理名に変えること");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    res.sendStatus(500);
                    console.log('something went wrong on req!!', err.request.options);
                });
            }], function(err, arg0, arg1) {
                if (err) {
                    throw err;
                }
                /* トランザクションのcommit */
                try {
                    commonUtil.commitTransaction(req, transactionNo);
                } catch(e) {
                    next(e);
                }
                // レスポンス編集
                arg1 = filter.resFilter(req.route.path, req, arg1);
                res.send(arg1);
                logger.debug('all done.');
                next();
            });
        } catch (e) {
            logger.error(e);
            throw e;
        }
    });
}, function(req, res, next) {
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

module.exports = router;
