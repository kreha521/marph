var express = require('express');
var router = express.Router();

var Client = require('node-rest-client').Client;
var client = new Client();

var async = require('async');


/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッション共通部品 */
var sessionUtil = require('../common/sessionUtil.js');
/* 共通定数 */
var commonConst = require('../const/common.js');

var filter = require('../filter/matter.js');
var validator = require('../validator/matter.js');

// URL生成
function buildAvailableSeriesEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/projects";
}


// 入力チェック
function validate(req, res) {
    var msgs = validator.validate(req.route.path, req)
    if (validator.hasError()) {
        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        logger.debug("Invalid paramaters!");
        logger.trace(msgs);
        res.status(200).send(msgs);
    }
    return msgs;
}


//案件一覧_一覧取得
router.post("/projects/get/_detail", function(req, res, next) {
    try {
     var transactionNo = sessionUtil.getTransactionNo(req)

    async.waterfall([
        function(callback) {

//REST APIを登録
    var orgCd = sessionUtil.getOrgCd(req);
    var groupCd = sessionUtil.getGroupCd(req);

// セッション情報から領域名を取得
    var groupName = sessionUtil.getGroupName(req);

    var url = buildAvailableSeriesEndPointUrl(req, transactionNo) + "/" + orgCd + "/" + groupCd;
    client.registerMethod("getProject", url, "GET");
    client.methods.getProject(function (data,response) {

        // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
        var err = checkUtil.checkStatusCode(req, response.statusCode, "全案件取得");
        if (err != null) {
            logger.error(data);
            next(err);
            return;
        }
        // RestAPI(GET)の結果判定はデータなしでもステータス200が返却されるため、取得データとGET種別(1件、N件)により、エラー判定する
        err = checkUtil.checkGetResponse(req, response, data, false);
        if (err != null) {
            logger.error(data);
            next(err);
            return;
        }

        callback(null, data);
    }).on('error', function (err) {
        next(err);
    });
 },
    ], function(err, arg0) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス情報を編集し、編集結果をクライアントへ送信する
            arg0 = filter.resFilter(req.route.path, req, arg0);
            res.send(arg0);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});


//案件一覧_案件完了
router.post("/projects/exit", function(req, res, next) {
    // 当該案件に完了日（今日）を付与して、再度一覧を取得
 try {
   var transactionNo = sessionUtil.getTransactionNo(req)

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

    async.waterfall([
        function(callback) {

            // 当該案件の組織コード、領域コード、リポジトリ連番を取得→URL反映
            var orgCd = req.body.orgCd;
            var groupCd = req.body.groupCd;
            var repositorySeq = req.body.repositorySeq;

            var url = buildAvailableSeriesEndPointUrl(req, transactionNo) + "/" + orgCd + "/" + groupCd + "/" + repositorySeq;

            client.registerMethod("setExitDay", url, "POST");

             var options = {
                 headers: {"Content-Type": "application/json"},
                 data: req.body
            };

            // 登録したREST APIを実行し、コールバック処理を行う
            client.methods.setExitDay(options, function (data,response) {
                // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                var err = checkUtil.checkStatusCode(req, response.statusCode, "案件完了");
                if (err != null) {
                    logger.error(data);
                    next(err);
                    return;
                }

            callback(null,data);
            }).on('error', function (err) {
                next(err);
            });
        },
        // 完了後処理：再度一覧を取得する。
        function(arg0, callback) {
                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);

            // セッション情報から領域名を取得
                var groupName = sessionUtil.getGroupName(req);

                var url = buildAvailableSeriesEndPointUrl(req, transactionNo) + "/" + orgCd + "/" + groupCd;
                client.registerMethod("getProject", url, "GET");
                client.methods.getProject(function (data,response) {
                    // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全案件取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    // RestAPI(GET)の結果判定はデータなしでもステータス200が返却されるため、取得データとGET種別(1件、N件)により、エラー判定する
                    err = checkUtil.checkGetResponse(req, response, data, false);
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                callback(null, 1, data);
                }).on('error', function (err) {
                    res.sendStatus(500);
                    console.log('something went wrong on req!!', err.request.options);
                });
        }],function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス情報を編集し、編集結果をクライアントへ送信する
            arg1 = filter.resFilter(req.route.path, req, arg1);
            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});


//案件詳細_案件追加
router.post("/projects/add", function(req, res, next) {
try {
     var transactionNo = sessionUtil.getTransactionNo(req)

     // リクエスト編集
        filter.reqFilter(req.route.path, req);

     // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validate(req, res);
        if (validator.hasError()) {
            next();
            return;
        }


    async.waterfall([
        function(callback) {
      //REST APIを登録
        var url = buildAvailableSeriesEndPointUrl(req, transactionNo)
        client.registerMethod("resigterProject", url, "POST");

            var options = {
                headers: {"Content-Type": "application/json"},
                data: req.body
            };

    // 登録したREST APIを実行し、コールバック処理を行う
    client.methods.resigterProject(options, function (data,response) {

        // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
        var err = checkUtil.checkStatusCode(req, response.statusCode, "案件追加");
        if (err != null) {
            logger.error(data);
            next(err);
            return;
        }

        callback(null, data);
        }).on('error', function (err) {
            next(err);
        });
     }],function(err, arg0) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
        // レスポンス情報を編集し、編集結果をクライアントへ送信する
            arg0 = filter.resFilter(req.route.path, req, arg0);
            res.send(arg0);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//案件詳細_案件更新
router.post("/projects/upd", function(req, res, next) {
try {
     var transactionNo = sessionUtil.getTransactionNo(req)

      // リクエスト編集
       filter.reqFilter(req.route.path, req);

     // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validate(req, res);
        if (validator.hasError()) {
            next();
            return;
        }

    async.waterfall([
        function(callback) {
      //REST APIを登録
        // 当該案件の組織コード、領域コード、リポジトリ連番を取得→URL反映
            var orgCd = req.body.orgCd;
            var groupCd = req.body.groupCd;
            var repositorySeq = req.body.repositorySeq;

            var url = buildAvailableSeriesEndPointUrl(req, transactionNo) + "/" + orgCd + "/" + groupCd + "/" + repositorySeq;
        client.registerMethod("resigterProject", url, "PUT");

            var options = {
                headers: {"Content-Type": "application/json"},
                data: req.body
            };
    // 登録したREST APIを実行し、コールバック処理を行う
    client.methods.resigterProject(options, function (data,response) {
            // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
            var err = checkUtil.checkStatusCode(req, response.statusCode, "案件更新");
            if (err != null) {
                logger.error(data);
                next(err);
                return;
            }

        callback(null, data);
        }).on('error', function (err) {
            next(err);
        });
     }],function(err, arg0) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス情報を編集し、編集結果をクライアントへ送信する
            arg0 = filter.resFilter(req.route.path, req, arg0);
            res.send(arg0);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});


//案件詳細_案件新規登録
router.post("/projects/get/_new", function(req, res) {


     var transactionNo = sessionUtil.getTransactionNo(req)
      // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // トランザクションのcommit
        try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

        // レスポンス情報を編集し、編集結果をクライアントへ送信する
        var data;
        data = filter.resFilter(req.route.path, req, data);
        res.send(data);
        logger.debug('all done.');
});



//案件詳細_案件削除
router.post("/projects/delete", function(req, res, next) {
try {
     var transactionNo = sessionUtil.getTransactionNo(req)
     // リクエスト編集
        filter.reqFilter(req.route.path, req);

     // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validate(req, res);
        if (validator.hasError()) {
            next();
            return;
        }

    async.waterfall([
        function(callback) {
//REST APIを登録
// 当該案件の組織コード、領域コード、リポジトリ連番を取得→URL反映
            var orgCd = req.body.orgCd;
            var groupCd = req.body.groupCd;
            var repositorySeq = req.body.repositorySeq;

            var url = buildAvailableSeriesEndPointUrl(req, transactionNo) + "/" + orgCd + "/" + groupCd + "/" + repositorySeq;
    client.registerMethod("deleteProject", url, "DELETE");

             var options = {
                headers: {"Content-Type": "application/json"},
                data: req.body
            };

    // 登録したREST APIを実行し、コールバック処理を行う
    client.methods.deleteProject(options, function (data,response) {
            // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
            var err = checkUtil.checkStatusCode(req, response.statusCode, "案件削除");
            if (err != null) {
                logger.error(data);
                next(err);
                return;
            }

         callback(null, data);
        }).on('error', function (err) {
            next(err);
        });
     }],function(err, arg0) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス情報を編集し、編集結果をクライアントへ送信する
            arg0 = filter.resFilter(req.route.path, req, arg0);
            res.send(arg0);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});


//案件詳細_案件一件取得
router.post("/projects/get/_edit", function(req, res, next) {
try {
     var transactionNo = sessionUtil.getTransactionNo(req)
     // リクエスト編集
        filter.reqFilter(req.route.path, req);

    async.waterfall([
        function(callback) {
            //REST APIを登録
            // 当該案件の組織コード、領域コード、リポジトリ連番を取得→URL反映
            var orgCd = req.body.orgCd;
            var groupCd = req.body.groupCd;
            var repositorySeq = req.body.repositorySeq;

            var url = buildAvailableSeriesEndPointUrl(req, transactionNo) + "/" + orgCd + "/" + groupCd + "/" + repositorySeq;

            client.registerMethod("getProject", url, "GET");


    // 登録したREST APIを実行し、コールバック処理を行う
    client.methods.getProject(function (data,response) {
            // HTTPステータス4XX台のエラーはon.errorで補足できないため、独自にステータスコードによるエラー判定する
            var err = checkUtil.checkStatusCode(req, response.statusCode, "案件一件取得");
            if (err != null) {
                logger.error(data);
                next(err);
                return;
            }
            // RestAPI(GET)の結果判定はデータなしでもステータス200が返却されるため、取得データとGET種別(1件、N件)により、エラー判定する
            err = checkUtil.checkGetResponse(req, response, data, true);
            if (err != null) {
                logger.error(data);
                next(err);
                return;
            }

         callback(null, data);
        }).on('error', function (err) {
            next(err);
        });
     }],function(err, arg0) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス情報を編集し、編集結果をクライアントへ送信する
            arg0 = filter.resFilter(req.route.path, req, arg0);
            res.send(arg0);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req, res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});



module.exports = router;
