var router = require('express').Router();
var async = require('async');

// Restクライアント
var Client = require('node-rest-client').Client;
var client = new Client();

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッションユーティリティ */
var sessionUtil = require('../common/sessionUtil.js');

var filter = require('../filter/envlist.js');

// 行（系列）情報取得
function buildSeriesEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/availableseries";
}

// コンテナ情報取得(Dockerコマンド)
function buildEnvstatEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/envstat";
}

//環境稼働状況一覧・ヘッダー取得
router.post("/envstats/get/_header", function(req,res,next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req);
        logger.debug(transactionNo);

        //レスポンスデータ
        var resData = {};

        //環境コード
        var envCds = commonUtil.getCodeKeyName(req.app, 'envCd');
        var envCdArray = [];
        for (key in envCds) {
            var temp = {cd : key, name : envCds[key]};
            envCdArray.push(temp);
        }
        resData['envCds'] = envCdArray;

        //サーバ種別
        var serverTypeNames = commonUtil.getCodeKeyName(req.app, 'serverTypeCd');
        var serverTypeNameArray = [];
        for (key in serverTypeNames) {
            var temp = {cd : key, name : serverTypeNames[key]};
            serverTypeNameArray.push(temp);
        }
        resData['serverTypeName'] = serverTypeNameArray;
        //領域名称
        resData['groupName'] = sessionUtil.getGroupShortCd(req) + ':' + sessionUtil.getGroupName(req);
        //トランザクションのコミット
        commonUtil.commitTransaction(req, transactionNo);

        // レスポンス編集
        resData = filter.resFilter(req.route.path, req, resData);

        res.send(resData);
        next();
    } catch(e) {
        logger.error(e);
        next(e);
    }
}, function(req,res,next) {
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//環境稼働状況一覧・明細取得
router.post("/envstats/get/_detail", function(req,res,next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req);
        logger.debug(transactionNo);

        async.waterfall([
            function(callback) {
                var url = buildSeriesEndPointUrl(req, transactionNo);
                logger.debug(url);

                // セッションより組織コード、領域コードの取得
                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);

                // 系列(行データ）取得REST APIを登録
                client.registerMethod("getSeries", url + "/" + orgCd + "/" + groupCd + "/" + req.body.envCd, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getSeries(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "組織/領域/環境指定利用可能系列取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            function(arg0, callback) {//arg0:行（系列情報）
                var url = buildEnvstatEndPointUrl(req, transactionNo);
                logger.debug(url);

                // セッションより組織コード、領域コードの取得
                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);

                var dataSeries = arg0;
                var resData = [];

                //データ件数分繰り返す
                async.mapSeries(dataSeries, function(target, callback) {

                    // 系列取得REST APIを登録
                    client.registerMethod("getEnvstat", url + "/" + orgCd + "/" + groupCd + "/" + req.body.envCd + "/" + target.seriesCd, "GET");

                    // 登録したREST APIを実行し、コールバック処理を行う
                    client.methods.getEnvstat(function (data, response) {
                        var err = checkUtil.checkStatusCode(req, response.statusCode, "組織/領域/環境/系列指定Dockerコンテナ情報取得");
                        if (err != null) {
                            logger.error(data);
                            next(err);
                            return;
                        }
                        //API実行した結果をappend
                        resData.push(data);
                        callback(null, data);
                    }).on('error', function (err) {
                        next(err);
                    });

                },function(err, results) {
                    if (err) throw err;
                    callback(null, resData);
                });
            },
            function(arg0, callback) {
                //サーバ種別
                var serverTypeCds = commonUtil.getCdNames(req.app, 'serverTypeCd');

                //編集初期化
                var imageSetData= [];

                //系列の数だけ処理を繰り返す
                for (i in arg0) {
                    var containerArray = [];
                    //コードマスタのサーバ種別の数だけ繰り返す
                    for (j in serverTypeCds) {
                        var machFlg = false;
                        var wkIpAddress = "";
                        var wkExeOrder = null;
                        //APIより取得したコンテナ情報とマッチング
                        for (k in arg0[i].detail) {
                            if (serverTypeCds[j].cd == arg0[i].detail[k].container.containerTypeCd){
                                machFlg = true;
                                wkIpAddress =  arg0[i].detail[k].container.ipAddress;
                                wkExeOrder =  arg0[i].detail[k].order.exeOrder;
                                break;
                            }
                        }
                        // TODO実行順を仮設定
                        var temp = {
                            "serverTypeCd" : serverTypeCds[j].cd,
                            "avilableFlg": machFlg,
                            "ipAddress": wkIpAddress,
                            "exeOrder": wkExeOrder
                        }
                        containerArray.push(temp);
                    }
                    var seriesData = {
                        "seriesCd": arg0[i].series.seriesCd,
                        "seriesName": arg0[i].series.seriesName,
                        "imagesetName":arg0[i].imgSet.imagesetName,
                        "state":arg0[i].series.statusCd=="0" ? "未使用":"稼働中",
                        "repositorySeq":arg0[i].imgSet.repositorySeq,
                        "imagesetSeq":arg0[i].imgSet.imagesetSeq,
                        "containerData":containerArray
                    };
                    imageSetData.push(seriesData);
                }
                callback(null, 1, imageSetData);
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch(e) {
        logger.error(e);
        next(e);
    }
}, function(req,res,next) {
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

module.exports = router;
