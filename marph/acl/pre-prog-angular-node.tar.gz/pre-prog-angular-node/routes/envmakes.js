var router = require('express').Router();
var async = require('async');

// Restクライアント
var Client = require('node-rest-client').Client;
var client = new Client();

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッションユーティリティ */
var sessionUtil = require('../common/sessionUtil.js');

var filter = require('../filter/envmakes.js');
var validator = require('../validator/envmakes.js');

//環境作成API
function buildEnvMakesEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/envmake";
}

//利用可能系列API
function buildAvailableSeriesEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/availableseries";
}

//案件（リポジトリ）API
function buildProjectsEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/projects";
}

// 環境作成 取得処理
router.post("/envmakes/get/_detail", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req);
        logger.debug(transactionNo);

        async.waterfall([
            function(callback) {
                var url = buildEnvMakesEndPointUrl(req, transactionNo);
                logger.debug(url);

                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);

                // リポジトリ連番とイメージセット取得のREST APIを登録
                client.registerMethod("getEnvMakes", url + "/" + orgCd + "/" + groupCd + "/" + req.body.repositorySeq + "/" + req.body.imagesetSeq, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getEnvMakes(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "環境作成情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            function(arg0, callback) {
                var url = buildAvailableSeriesEndPointUrl(req, transactionNo);
                logger.debug(url);

                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);

                // REST APIを登録
                client.registerMethod("getAvailableSeries", url + "/" + orgCd + "/" + groupCd + "/" + req.body.envCd + "/" + req.body.seriesCd, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getAvailableSeries(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "利用可能系列情報取得");
                    if (err != null) {
                        next(err);
                        return;
                    }
                    callback(null, arg0, data);
                }).on('error', function (err) {
                    next(err);
                });

            },
            function(arg0, arg1, callback) {
                var url = buildProjectsEndPointUrl(req, transactionNo);
                logger.debug(url);

                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);

                // REST APIを登録
                client.registerMethod("getSelects", url + "/" + orgCd + "/" + groupCd, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getSelects(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全案件取得");
                    if (err != null) {
                        next(err);
                        return;
                    }
                    var resData = {};

                    // リポジトリ情報・イメージセット情報設定
                    resData = arg1;
                    // 利用可能系列情報設定
                    resData.availableSeries = arg0;
                    // 案件情報設定
                    resData.prdTypeCds= data;
                    // セッション情報設定
                    resData.orgCd = sessionUtil.getOrgCd(req);
                    resData.groupShortCd = sessionUtil.getGroupShortCd(req);
                    resData.groupName = sessionUtil.getGroupName(req);

                    callback(null, 1, resData);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('envmakes list was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 環境作成 登録処理
router.post("/envmakes/create", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildEnvMakesEndPointUrl(req, transactionNo);

//                // REST APIを登録
//                client.registerMethod("makeEnv", url + "/" + req.body.envCd + "/" + req.body.seriesCd + "/" + req.body.repositorySeq + "/" + req.body.imagesetSeq, "POST");


                // 登録したREST APIを実行し、コールバック処理を行う
//                client.methods.makeEnv(options, function (data, response) {
//                    var err = checkUtil.checkStatusCode(req, response.statusCode, "環境作成");
//                    if (err != null) {
//                        logger.error(data);
//                        next(err);
//                        return;
//                    }
//                    callback(null, 1, data);
//                }).on('error', function (err) {
//                    next(err);
//                });
                  var data = {
                      "data":'aaa'
                  }
                  callback(null, 1, data);
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('envmakes insert was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});



/***
 * 例外エラー発生時
 */
client.on('error', function (err) {
    logger.error(err);
    next(err);
});

module.exports = router;
