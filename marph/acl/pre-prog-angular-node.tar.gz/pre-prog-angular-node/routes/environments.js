var router = require('express').Router();
var async = require('async');

// Restクライアント
var Client = require('node-rest-client').Client;
var client = new Client();

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッションユーティリティ */
var sessionUtil = require('../common/sessionUtil.js');

var filter = require('../filter/environments.js');
var validator = require('../validator/environments.js');

function buildEnvsEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/envs";
}

// 環境一覧 取得処理
router.post("/envs/get/_detail", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req);

        logger.debug(transactionNo);

        async.waterfall([
            function(callback) {
                var url = buildEnvsEndPointUrl(req, transactionNo);
                logger.debug(url);

                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);

                // REST APIを登録
                client.registerMethod("getEnvs", url + "/" + orgCd + "/" + groupCd, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getEnvs(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全環境取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('environments list was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 環境情報 削除処理
router.post("/envs/del", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildEnvsEndPointUrl(req, transactionNo);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // REST APIを登録
                client.registerMethod("deleteEnv", url + "/" + req.body.orgCd + "/" + req.body.groupCd + "/" + req.body.envCd, "DELETE");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.deleteEnv(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "環境削除");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('environments del was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 環境情報 初期表示処理
router.post("/envs/get/_new", function(req, res, next) {
    try {
        logger.debug(req.route.path);
        // リクエスト編集
        filter.reqFilter(req.route.path, req);
        //トランザクションNo取得
        var transactionNo = sessionUtil.getTransactionNo(req);
        logger.debug(transactionNo);

        async.waterfall([
            function(callback) {
                var url = buildEnvsEndPointUrl(req, transactionNo);
                logger.debug(url);

                //選択領域表示
                var orgCd = sessionUtil.getOrgCd(req);
                var groupCd = sessionUtil.getGroupCd(req);
                var groupShortCd = sessionUtil.getGroupShortCd(req);
                var groupName = sessionUtil.getGroupName(req);

                data = {"orgCd":orgCd, "groupCd":groupCd, "groupShortCd":groupShortCd, "groupName":groupName};

                //環境コードのコンボボックス設定
                var envCds = commonUtil.getCodeKeyName(req.app, 'envCd');
                var setenvCds = [];
                for (key in envCds) {
                    var temp = {cd:key, name:envCds[key]};
                    setenvCds.push(temp);
                }
                data.envCds = setenvCds;

                callback(null, 1, data);
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('environments Projects was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 領域情報取得処理（編集）
router.post("/envs/get/_edit", function(req, res, next) {
    try {
        logger.debug(req.route.path);
        // リクエスト編集
        filter.reqFilter(req.route.path, req);
        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildEnvsEndPointUrl(req, transactionNo);

                // REST APIを登録
                client.registerMethod("getEnvsOne", url + "/" + req.body.orgCd + "/" + req.body.groupCd + "/" + req.body.envCd, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getEnvsOne(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "環境取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            function(arg0, arg1, callback) {
                //環境コードのコンボボックス設定
                var envCds = commonUtil.getCodeKeyName(req.app, 'envCd');

                var setenvCds = [];
                for (key in envCds) {
                    var temp = {cd:key, name:envCds[key]};
                    setenvCds.push(temp);
                }
                arg1.envCds = setenvCds;

                callback(null, 2, arg1);
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('environments edit was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 環境情報 登録処理
router.post("/envs/add", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildEnvsEndPointUrl(req, transactionNo);

                // REST APIを登録
                client.registerMethod("addEnv", url, "POST");

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.addEnv(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "環境登録");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('environments insert was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// 環境情報 更新処理
router.post("/envs/upd", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildEnvsEndPointUrl(req, transactionNo);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // REST APIを登録
                client.registerMethod("updEnv", url + "/" + req.body.orgCd + "/" + req.body.groupCd + "/" + req.body.envCd, "PUT");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.updEnv(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "環境更新");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('environments edit was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

client.on('error', function (err) {
    logger.error(err);
    next(err);
});

module.exports = router;
