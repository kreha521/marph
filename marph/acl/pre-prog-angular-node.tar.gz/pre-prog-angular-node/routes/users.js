var router = require('express').Router();
var async = require('async');

// Restクライアント
var Client = require('node-rest-client').Client;
var client = new Client();

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッションユーティリティ */
var sessionUtil = require('../common/sessionUtil.js');

var filter = require('../filter/users.js');
var validator = require('../validator/users.js');

function buildUsersEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/users";
}

function buildRolesEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/roles";
}

function buildGroupsEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/groups";
}

// ユーザ情報取得処理
router.post("/users/get/_list", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req);

        async.waterfall([
            function(callback) {
                var url = buildUsersEndPointUrl(req, transactionNo);
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getUsers", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getUsers(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "ユーザ情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// ユーザ情報取得処理（新規作成）
router.post("/users/get/_new", function(req, res, next) {
    try {
        logger.debug(req.route.path);
        // リクエスト編集
        filter.reqFilter(req.route.path, req);
        //トランザクションNo取得
        var transactionNo = sessionUtil.getTransactionNo(req);

        var resJson = {};
        async.waterfall([
            function(callback) {
                //領域一覧の取得
                var url = buildGroupsEndPointUrl(req, transactionNo);
                client.registerMethod("getGroups", url, "GET");
                client.methods.getGroups(function(data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全領域取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    var grpResData = [];
                    for (i in data) {
                        var tmpGroupCd = data[i].grps.groupCd;
                        var tmpGroupName = data[i].grps.groupName;
                        var tmp = {cd : tmpGroupCd, name : tmpGroupName};
                        grpResData.push(tmp);
                    }
                    resJson.groupCds = grpResData;
                    callback(null,1,resJson);
                }).on('error', function(err) {
                    next(err);
                })
            },
            function(arg0, arg1, callback) {
                //権限リストの値設定
                var roleCds = commonUtil.getCodeKeyName(req.app,'groupCd');
                var setRoleCds = [];
                for (key in roleCds) {
                    var temp = {cd:key, name:roleCds[key]};
                    setRoleCds.push(temp);
                }
                arg1.roleCds = setRoleCds;
                callback(null,2,arg1);
            }
        ], function(err, arg0,arg1) {
            if (err) throw err;
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }
            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);
            res.send(arg1);
            logger.debug('all done.');
            next();
        })
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res,next) {
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// ユーザ情報取得処理（編集）
router.post("/users/get/_edit", function(req, res, next) {
    try {
        logger.debug(req.route.path);
        // リクエスト編集
        filter.reqFilter(req.route.path, req);
        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            logger.trace(msgs);
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildUsersEndPointUrl(req, transactionNo);
                // REST APIを登録
                client.registerMethod("getUser", url + "/" + req.body.userId, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getUser(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "ユーザ情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            function(arg0,arg1,callback) {
                //権限リストの値設定
                var roleCds = commonUtil.getCodeKeyName(req.app,'groupCd');
                var setRoleCds = [];
                for (key in roleCds) {
                    var temp = {cd:key, name:roleCds[key]};
                    setRoleCds.push(temp);
                }
                arg1.roleCds = setRoleCds;
                //領域一覧の取得
                var url = buildGroupsEndPointUrl(req, transactionNo);
                client.registerMethod("getGroups", url, "GET");
                client.methods.getGroups(function(data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全領域取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    var grpResData = [];
                    for (i in data) {
                        var tmpGroupCd = data[i].grps.groupCd;
                        var tmpGroupName = data[i].grps.groupName;
                        var tmp = {cd : tmpGroupCd, name : tmpGroupName};
                        grpResData.push(tmp);
                    }
                    arg1.groupCds = grpResData;
                    callback(null,2,arg1,grpResData);
                }).on('error', function(err) {
                    next(err);
                })
            },
            function(arg0,arg1,arg2,callback) {
                //権限テーブルに紐づくデータの編集
                var roles = arg1.tblUserRoles;
                var masterRoles = arg1.roleCds;
                for (i in roles) {
                    var tmpGrpCd = roles[i].groupCd;
                    var tmpGrpName;
                    for (j in arg2) {
                        if (arg2[j].cd == tmpGrpCd) {
                            tmpGrpName = arg2[j].name;
                            break;
                        }
                    }
                    roles[i].groupName = tmpGrpName;
                    var tmpRoleCd = roles[i].roleCd;
                    var tmpRoleName;
                    for (k in masterRoles) {
                        if (tmpRoleCd == masterRoles[k].cd) {
                            tmpRoleName = masterRoles[k].name;
                            break;
                        }
                    }
                    roles[i].roleName = tmpRoleName;
                }
                callback(null, 3,arg1,arg2);
            }
        ], function(err, arg0, arg1, arg2) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);
            logger.debug(arg1);
            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//ユーザ情報登録処理
router.post("/users/add", function(req, res, next) {
    try {
        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            logger.trace(msgs);
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildUsersEndPointUrl(req, transactionNo);

                // REST APIを登録
                client.registerMethod("addUser", url, "POST");

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.addUser(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "ユーザ情報登録");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//ユーザ情報更新処理
router.post("/users/upd", function(req, res, next) {
    try {
        logger.debug(req.route.path);
        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            logger.trace(msgs);
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                //ユーザ情報更新
                var url = buildUsersEndPointUrl(req, transactionNo);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body.tblUser
                };

                // REST APIを登録
                client.registerMethod("updateUser", url + "/" + req.body.tblUser.userId, "PUT");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.updateUser(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "ユーザ情報更新");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            function(arg0, arg1, callback) {

                var url = buildRolesEndPointUrl(req, transactionNo);
                logger.debug("3=" + url);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body.tblUserRoles
                };
                client.registerMethod("deleteRole", url + '/' + req.body.tblUser.userId, "DELETE");
                client.methods.deleteRole(options, function(data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "ユーザ権限削除");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 2, arg1);
                }).on('error', function (err) {
                    next(err);
                });
            },
            function(arg0, arg1, callback) {
                //URLの生成
                var url = buildRolesEndPointUrl(req, transactionNo);
                // ユーザ権限登録REST APIを登録
                client.registerMethod("addRole", url, "POST");
                //header, requestbody
                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body.tblUserRoles
                };
                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.addRole(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "ユーザ権限登録");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 3, arg1);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//ユーザ情報削除処理
router.post("/users/del", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            logger.trace(msgs);
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildUsersEndPointUrl(req, transactionNo);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // REST APIを登録
                client.registerMethod("deleteUser", url + "/" + req.body.userId, "DELETE");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.deleteUser(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "ユーザ情報削除");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// パスワードリセット処理
router.post("/users/password/reset", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            logger.trace(msgs);
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            function(callback) {
                var url = buildUsersEndPointUrl(req, transactionNo);
                var targetBody = req.body;
                //データ件数分繰り返す
                async.mapSeries(targetBody, function(target, callback) {
                    var options = {
                        headers: {"Content-Type": "application/json"},
                        data: target
                    };
                    // REST APIを登録
                    client.registerMethod("updateUser", url + "/" +target.userId, "PUT");
                    // 登録したREST APIを実行し、コールバック処理を行う
                    client.methods.updateUser(options, function (data, response) {
                        var err = checkUtil.checkStatusCode(req, response.statusCode, "ユーザ情報更新");
                        if (err != null) {
                            logger.error(data);
                            next(err);
                            return;
                        }
                        callback(null, data);
                    }).on('error', function (err) {
                        next(err);
                    });

                },function(err, results) {
                    if (err) throw err;
                    callback(null, 1, results);
                });
            }
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }
            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);

            res.send(arg1);
            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

client.on('error', function (err) {
    logger.error(err);
    next(err);
});

module.exports = router;

