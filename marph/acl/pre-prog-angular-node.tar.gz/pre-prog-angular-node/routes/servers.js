var router = require('express').Router();
var async = require('async');

// Restクライアント
var Client = require('node-rest-client').Client;
var client = new Client();

// ロガー
var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

/* 共通ユーティリティ */
var commonUtil = require('../common/commonUtil.js');
/* 共通チェックユーティリティ */
var checkUtil = require('../common/checkUtil.js');
/* セッションユーティリティ */
var sessionUtil = require('../common/sessionUtil.js');

var filter = require('../filter/servers.js');
var validator = require('../validator/servers.js');

// URL生成（サーバ基本情報）
function buildServersEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/servers";
}

// URL生成（組織）
function buildOrganizationsEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/organizations";
}

// URL生成（コンテナ基本情報）
function buildContainersEndPointUrl(req, transactionNo) {
    return commonUtil.buildTransactionResourceUrl(req, transactionNo) + "/containers";
}

// サーバ情報取得処理
router.post("/servers/get/_detail", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req);

        async.waterfall([
            /***
             * 1. サーバ基本情報のデータを取得する。
             */
            function(callback) {
                var url = buildServersEndPointUrl(req, transactionNo);
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getServers", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getServers(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全サーバ基本情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0) {
            if (err) {
                throw err;
            }

            /* トランザクションのcommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg0 = filter.resFilter(req.route.path, req, arg0);
            res.send(arg0);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//サーバ情報取得処理（編集）
router.post("/servers/get/_new", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            /***
             * 1. サーバ種別、コンテナ種別、組織のコード値、名称を取得
             */
            function(callback) {
                var ret = {};

                ret.serverTypeCds = filter.resFilterForServerTypeCdNames(req.app);
                ret.containerTypeCds = filter.resFilterForContainerTypeCdNames(req.app);

                //組織の取得
                var url = buildOrganizationsEndPointUrl(req, transactionNo);
                logger.debug(url);

                client.registerMethod("getOrganizations", url, "GET");
                client.methods.getOrganizations(function(data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全組織情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    // 組織コード情報の編集
                    ret.orgCds = filter.resFilterForOrgCdNames(data);
                    callback(null, ret);
                }).on('error', function(err) {
                    next(err);
                })
            }
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0) {
            if (err) {
                throw err;
            }

            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg0 = filter.resFilter(req.route.path, req, arg0);
            res.send(arg0);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

// サーバ情報取得処理（編集）
router.post("/servers/get/_edit", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            /***
             * 1. 処理対象のサーバ基本情報を取得する
             */
            function(callback) {
                var url = buildServersEndPointUrl(req, transactionNo)
                    + "/" + req.body.orgCd
                    + "/" + req.body.serverSeqNo;
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getServer", url , "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getServer(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "サーバ基本情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 2. サーバ種別、コンテナ種別、組織のコード値、名称を取得
             */
            function(arg0, callback) {
                var ret = {};

                ret.serverTypeCds = filter.resFilterForServerTypeCdNames(req.app);
                ret.containerTypeCds = filter.resFilterForContainerTypeCdNames(req.app);

                //組織の取得
                var url = buildOrganizationsEndPointUrl(req, transactionNo);
                logger.debug(url);
                client.registerMethod("getOrganizations", url, "GET");
                client.methods.getOrganizations(function(data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全組織情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    // 組織コード情報の編集
                    ret.orgCds = filter.resFilterForOrgCdNames(data);
                    callback(null, arg0, ret);
                }).on('error', function(err) {
                    next(err);
                })
            },
            /***
             * 3. 処理対象のコンテナ基本情報を取得する
             */
            function(arg0, arg1, callback) {
                var url = buildContainersEndPointUrl(req, transactionNo)
                    + "/" + req.body.orgCd
                    + "/" + req.body.serverSeqNo;
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getContainers",  url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getContainers(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "コンテナ基本情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, arg0, arg1, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0, arg1, arg2) {
            if (err) {
                throw err;
            }

            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // 選択リストの情報を設定
            for (var code in arg1) {
                arg0[code] = arg1[code];
            }

            // コンテナ情報設定
            arg0.containers = arg2;

            // レスポンス編集
            arg0 = filter.resFilter(req.route.path, req, arg0);
            res.send(arg0);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//サーバ情報登録処理
router.post("/servers/add", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        // 入力データ
        var server = req.body.tblServer;
        var containers = req.body.tblContainers;

        async.waterfall([
            /***
             * 1. チェック仕様：IPアドレス登録済みチェックをする
             */
            function(callback) {
                //IPアドレス登録済みチェック
                var url = buildServersEndPointUrl(req, transactionNo);
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getServers", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getServers(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全サーバ基本情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    //IPアドレス登録済みの場合エラーを戻す
                    if (!validator.isAvailableIpAddress(server, data)){
                        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0037"));
                        res.status(200).send(msgs);
                        logger.error(msgs);
                        next();
                        return;
                    }
                    callback(null, 2);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 2. サーバ基本情報のデータを登録する
             */
            function(arg0, callback) {
                var url = buildServersEndPointUrl(req, transactionNo);
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("addServer", url, "POST");

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: server
                };

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.addServer(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "サーバ基本情報登録");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, arg0, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 3. コンテナ基本情報のデータを登録する
             */
            function(arg0, arg1, callback) {
                var url = buildContainersEndPointUrl(req, transactionNo);
                logger.debug(url);

                // 登録前のデータ編集
                filter.reqFilterForRegisterContainers(req, arg1);

                // REST APIを登録
                client.registerMethod("addContainer", url, "POST");

                //データ件数分繰り返す
                async.mapSeries(containers, function(container, callback) {
                    var options = {
                        headers: {"Content-Type": "application/json"},
                        data: container
                    };

                    // 登録したREST APIを実行し、コールバック処理を行う
                    client.methods.addContainer(options, function (data, response) {
                        var err = checkUtil.checkStatusCode(req, response.statusCode, "コンテナ基本情報登録");
                        if (err != null) {
                            logger.error(data);
                            next(err);
                            return;
                        }
                        callback(null, arg0, arg1, data);
                    }).on('error', function (err) {
                        next(err);
                    });
                },
                function(err, results) {
                    if (err) {
                        throw err;
                    }
                    callback(null, arg0, arg1, results);
                });
            }
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0, arg1, arg2) {
            if (err) {
                throw err;
            }

            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);
            res.send(arg1);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//サーバ情報更新処理
router.post("/servers/upd", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        // 入力データ
        var server = req.body.tblServer;
        var containers = req.body.tblContainers;

        async.waterfall([
            /***
             * 1. チェック仕様：IPアドレス登録済みチェックをする
             */
            function(callback) {
                //IPアドレス登録済みチェック
                var url = buildServersEndPointUrl(req, transactionNo);
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("getServers", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getServers(function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "全サーバ基本情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    //IPアドレス登録済みの場合エラーを戻す
                    if (!validator.isAvailableIpAddress(server, data)){
                        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0037"));
                        res.status(200).send(msgs);
                        logger.error(msgs);
                        next();
                        return;
                    }
                    callback(null, 1);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 2. チェック仕様：サーバ使用中チェックをする
             */
            function(arg0, callback) {
                var url = buildContainersEndPointUrl(req, transactionNo)
                    + "/" + server.orgCd + "/" + server.serverSeqNo;
                logger.debug(url);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // REST APIを登録
                client.registerMethod("getContainer", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getContainer(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "コンテナ基本情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    // サーバ使用中チェック
                    if (validator.isRunningServer(data)){
                        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0036", "更新"));
                        res.status(200).send(msgs);
                        logger.error(msgs);
                        next();
                        return;
                    }
                    callback(null, 2);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 3. サーバ基本情報のデータを更新する
             */
            function(arg0, callback) {
                var url = buildServersEndPointUrl(req, transactionNo)
                     + "/" + server.orgCd + "/" + server.serverSeqNo;
                logger.debug(url);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: server
                };

                // REST APIを登録
                client.registerMethod("updateServer", url, "PUT");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.updateServer(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "サーバ基本情報更新");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 3, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 4. コンテナ基本情報のデータを削除する
             */
            function(arg0, arg1, callback) {
                var url = buildContainersEndPointUrl(req, transactionNo)
                    + "/" + server.orgCd + "/" + server.serverSeqNo;
                logger.debug(url);

                // REST APIを登録
                client.registerMethod("delContainers", url, "DELETE");

                var options = {
                    headers: {"Content-Type": "application/json"},
                };

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.delContainers(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "コンテナ基本情報削除");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, arg0, arg1, data);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 5. コンテナ基本情報のデータを登録する
             */
            function(arg0, arg1, arg2, callback) {
                var url = buildContainersEndPointUrl(req, transactionNo);
                logger.debug(url);

                // 登録前のデータ編集
                filter.reqFilterForRegisterContainers(req, arg1);

                // REST APIを登録
                client.registerMethod("addContainer", url, "POST");

                //データ件数分繰り返す
                async.mapSeries(containers, function(container, callback) {
                    var options = {
                        headers: {"Content-Type": "application/json"},
                        data: container
                    };

                    // 登録したREST APIを実行し、コールバック処理を行う
                    client.methods.addContainer(options, function (data, response) {
                        var err = checkUtil.checkStatusCode(req, response.statusCode, "コンテナ基本情報登録");
                        if (err != null) {
                            logger.error(data);
                            next(err);
                            return;
                        }
                        callback(null, arg0, arg1, data);
                    }).on('error', function (err) {
                        next(err);
                    });
                },
                function(err, results) {
                    if (err) {
                        throw err;
                    }
                    callback(null, arg0, arg1, results);
                });
            }
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0, arg1, arg2, arg3) {
            if (err) {
                throw err;
            }

            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);
            res.send(arg1);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next){
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

//サーバ情報削除処理
router.post("/servers/del", function(req, res, next) {
    try {
        logger.debug(req.route.path);

        // リクエスト編集
        filter.reqFilter(req.route.path, req);

        // 入力チェックを行い、エラーがある場合はメッセージを返却し、処理を中断する
        var msgs = validator.validate(req.route.path, req)
        if (validator.hasError()) {
            logger.debug("Invalid paramaters!");
            res.status(200).send(msgs);
            next();
            return;
        }

        var transactionNo = sessionUtil.getTransactionNo(req)

        async.waterfall([
            /***
             * 1. チェック仕様：サーバ使用中チェックをする
             */
            function(callback) {
                var url = buildContainersEndPointUrl(req, transactionNo)
                    + "/" + req.body.orgCd + "/" + req.body.serverSeqNo;
                logger.debug(url);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // REST APIを登録
                client.registerMethod("getContainer", url, "GET");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.getContainer(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "コンテナ基本情報取得");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    // サーバ使用中チェック
                    if (validator.isRunningServer(data)){
                        msgs.msgsError.push(commonUtil.getMsg(req, "MSG0036","削除"));
                        res.status(200).send(msgs);
                        logger.error(msgs);
                        next();
                        return;
                    }
                    callback(null, 1);
                }).on('error', function (err) {
                    next(err);
                });
            },
            /***
             * 2. サーバ基本情報、コンテナ基本情報のデータを削除する
             */
            function(arg0, callback) {
                var url = buildServersEndPointUrl(req, transactionNo)
                    + "/" + req.body.orgCd + "/" + req.body.serverSeqNo;
                logger.debug(url);

                var options = {
                    headers: {"Content-Type": "application/json"},
                    data: req.body
                };

                // REST APIを登録
                client.registerMethod("deleteServer", url, "DELETE");

                // 登録したREST APIを実行し、コールバック処理を行う
                client.methods.deleteServer(options, function (data, response) {
                    var err = checkUtil.checkStatusCode(req, response.statusCode, "サーバ基本情報削除");
                    if (err != null) {
                        logger.error(data);
                        next(err);
                        return;
                    }
                    callback(null, 3, data);
                }).on('error', function (err) {
                    next(err);
                });
            }
        /***
         * 非同期後処理. 一連の非同期処理の後処理を行う。
         */
        ], function(err, arg0, arg1) {
            if (err) {
                throw err;
            }

            /* トランザクションのCommit */
            try {
                commonUtil.commitTransaction(req, transactionNo);
            } catch(e) {
                next(e);
            }

            // レスポンス編集
            arg1 = filter.resFilter(req.route.path, req, arg1);
            res.send(arg1);

            logger.debug('all done.');
            next();
        });
    } catch (e) {
        logger.error(e);
        throw e;
    }
}, function(req,res, next) {
    /* Nodeへのリクエスト処理が全て正常終了した場合の、後処理を行う */
    logger.debug('All process was done! trx no session scope will be closed!');
    sessionUtil.closeReqScope(req);
});

/***
 * 例外エラー発生時
 */
client.on('error', function (err) {
    logger.error(err);
    next(err);
});

module.exports = router;

