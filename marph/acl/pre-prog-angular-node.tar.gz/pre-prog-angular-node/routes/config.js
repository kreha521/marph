var express = require('express');
var router = express.Router();

var logUtil = require('../common/logUtil.js');
var logger = logUtil.getLogger();

var commonUtil = require('../common/commonUtil.js');

var app = express();

// アプリケーション共通定義情報取得
router.post("/config/appconfigs/get", function(req, res, next) {
    res.send(commonUtil.loadAppAngularConfig(req.app));
    next();
});

// アプリケーションメッセージ情報取得
router.post("/config/messages/get", function(req, res, next) {
    res.send(commonUtil.loadMsg(req.app));
    next();
});

module.exports = router;

