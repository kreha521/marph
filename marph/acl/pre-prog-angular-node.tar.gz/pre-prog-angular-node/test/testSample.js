//テスト対象モジュール
var target = require('../common/checkUtil.js');
//assertionライブラリ
var chai = require('chai')
, assert = chai.assert;

describe('checkUtil#isEmpty', function() {
    before(function(done) {
//        checkUtil = require('../common/checkUtil.js');
        done();
    });
    it('regular case 1', function(done) {
        var result = target.isEmpty(undefined);
        assert.equal(result, true);
        done();
    });
    it('regular case 2', function(done) {
        var result = target.isEmpty('');
        assert.equal(result, true);
        done();
    });
    it('regular case 3', function(done) {
        var result = target.isEmpty(null);
        assert.equal(result, true);
        done();
    });
    it('regular case 4', function(done) {
        var result = target.isEmpty('hoge');
        assert.equal(result, false);
        done();
    });

    after(function(done) {
        done();
    });
});

describe('checkUtil#isEmptyArray', function() {
    before(function(done) {
        done();
    });
    it ('regular case 1', function(done) {
        assert.equal(target.isEmptyArray(undefined), true);
        done();
    });
    after(function(done) {
        done();
    });
})

//describe('mochaのテスト', function() {
//    it('1秒待つこと', function(done) {
//        setTimeout(function() {
//            assert.ok(true);
//            done();
//        }, 1000);
//    });
//    it('1 + 1は2になること', function() {
//        assert.equal(1 + 1, 2,'正しくなったよ');
//    });
//});


//describe('Number', function() {
//    describe('calc', function() {
//        it('add', function() {
//            assert(4+8 == 12);
//        });
//        it('sub', function() {
//            assert(4-8 == -4);
//        });
//        it('mul', function() {
//            assert(16*2 == 32);
//        });
//        it('div', function() {
//            assert(8/2 == 4);
//        });
//    });
//});
