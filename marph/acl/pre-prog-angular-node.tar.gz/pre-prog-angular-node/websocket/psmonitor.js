var db = require('../common/db.js');
var logger = require('../common/logUtil.js').getLogger();
var mysql = require('mysql');

var commonUtil = require('../common/commonUtil.js');

function isFinished(status) {
    if (!status) {
        return false;
    }
    return (status == "0" || status == "2");
}

function isAbend(status) {
    if (!status) {
        return false;
    }
    return (status == "2");
}

module.exports = function (app, transactionId) {
    var socketIO = commonUtil.getSocketIO(app);
    var psmonitorIO = commonUtil.getPsMonitorSocketIO(app);
    const sql = 'SELECT * FROM TBL_DELAYED_STATUS WHERE id = ?;';

    setInterval(function () {
        var socketId = app.get('socketid');
        logger.trace("socket monitoring" + "[" + socketId + "]" + "...");

        // DB接続
        var connection = db.getConnection();

        try {
            // 処理状況の監視実行
            var query = connection.query(sql, [transactionId]);
            query
                .on('error', function(err) {
                    db.closeConnection(connection);
                    throw err;
                })
                .on('result', function(record) {
                    if (!record) {
                        logger.trace("Nothing process");
                        return;
                    }
                    if (isFinished(record.status)) {
                        psmonitorIO.to(socketId).emit('send:status', {
                            "id": record.id
                            , "status": record.status
                            , "pname": record.pname
                        });
                    } else {
                        logger.trace("socket monitoring report...[" + record.status + "]");
                    }
                    if (isAbend(record.status)) {
                        // delete
                    }
                })
               .on('end', function() {
                   db.closeConnection(connection);
                })
            ;
        } catch (err) {
            db.closeConnection(connection);
            logger.error(err);
        }
    }, 5000);
};
