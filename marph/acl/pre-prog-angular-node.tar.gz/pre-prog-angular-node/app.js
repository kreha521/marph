var express = require('express');
var app = express();

var path = require('path');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var session = require('express-session');

//socket.io http
var http = require('http').Server(app);
var io = require('socket.io')(http);

var Client = require('node-rest-client').Client;
var client = new Client();

var async = require('async');

var logUtil = require('./common/logUtil.js');
var logger = logUtil.getLogger();

/* トランザクション連番生成 */
var trxUtil = require('./common/transaction.js');
/* セッション共通部品 */
var sessionUtil = require('./common/sessionUtil.js');
/* 共通部品 */
var commonUtil = require('./common/commonUtil.js');
/* 共通チェック */
var checkUtil = require('./common/checkUtil.js');

/* 各routingの読み込み */
var config = require('./routes/config.js');
var login = require('./routes/login.js');
var users = require('./routes/users.js');
var organizations = require('./routes/organizations.js');
var selectgroup = require('./routes/group.js');
var groups = require('./routes/groups.js');
var servers = require('./routes/servers.js');
var matter = require('./routes/matter.js');
var environments = require('./routes/environments.js');
//var availablecont = require('./routes/availablecontainer.js');
var availableseries = require('./routes/availableseries.js');
var repositories = require('./routes/repositories.js');
var images = require('./routes/images.js');
var imagesets = require('./routes/imagesets.js');
var imageselects = require('./routes/imageselects.js');
var containers = require('./routes/containers.js');
var envlist = require('./routes/envlist.js');
var envmakes = require('./routes/envmakes.js');
var opedatemodifies = require('./routes/opedatemodifies');
var dataimport = require('./routes/tableimport');

/* アプリケーションの各種設定 */
app.use('/', express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(cookieParser());
/* セッションの設定 */
app.use(session({
    secret: 'gantry20170331',
    resave: false,
    saveUninitialized: false,
    cookie: {
        maxAge: 60 * 60 * 1000
    }
}));

/* コードマスタ読み込み */
commonUtil.loadCodeValue(app);
/* 共通アプリケーション設定情報読み込み */
commonUtil.loadAppCommonConfig(app);
/* アプリケーション設定情報読み込み */
commonUtil.loadAppConfig(app);
/* 業務アプリケーションメッセージ定義情報読み込み */
commonUtil.loadMsg(app);

/* 全てのroutingで呼ばれる。ここで前処理を行う */
app.all('/*', function(req,res,next) {
    if (!(req.url.match(/socket.io/) == null)) {    //urlが/socket.ioにマッチングする場合
        //nop
        return;
    }

    /* リクエスト単位のリクエストスコープオープン */
    sessionUtil.openReqScope(req);
    /* トランザクション連番を発行する */
    var trxNo = trxUtil.getTrxNo();
    /* セッションにトランザクション連番を設定 */
    sessionUtil.setTransactionNo(req, trxNo);

    logger.info("Pre routing[" + "URL=" + req.url + ", " + "TransactionNo=" + trxNo + "]");

    if (req.url == '/login') {   //urlが/loginの場合
        sessionUtil.openUserInfo(req);
        sessionUtil.setTransactionNo(req, trxNo);
        next();
    } else if (!(req.url.match(/config/) == null)) {    //urlが/configにマッチングする場合
        sessionUtil.setTransactionNo(req, trxNo);
        next();
    } else if(checkUtil.isSessionExpired(req.session)) {  //login,configでもなく未認証の場合
        // 未認証もしくはセッションタイムアウト時はエラーを返す
        var err = checkUtil.checkStatusCode(req, 401, "未認証チェック");
        if (err != null) {
            next(err);
        }
    } else {
        //認証済かつAPIサーバへのアクセスがある場合、トランザクションのBegin
        var url = commonUtil.buildTransactionResourceUrl(req, trxNo) + '/begin';
        client.registerMethod("beginTran", url, "GET");
        logger.debug('url is : ' + req.url + ' Transaction begin... Transaction No is : ' + trxNo);
        async.waterfall([
            function(callback) {
                client.methods.beginTran(function(data, response) {
                    logger.debug(data);
                    logger.debug(response.statusCode);
                    callback(null,1);
                });
            }
        ], function(err, result) {
            if (err) {
                throw err;
            }
            next();
        })
    }
});

/** ▼▼▼▼▼▼▼▼ ここからが各routing ▼▼▼▼▼▼▼▼ */
// 定義情報
app.use('/', config);
// ログイン画面
app.use('/', login);
// ユーザ一覧、登録
app.use('/', users);
// 組織一覧・登録
app.use('/', organizations);
// 領域一覧・登録
app.use('/', groups);
// サーバ基本情報一覧・登録
app.use('/', servers);
// 領域選択・登録
app.use('/', selectgroup);
// 案件一覧・登録
app.use('/', matter);
// 環境一覧・登録
app.use('/', environments);
// 利用可能コンテナ情報一覧・登録
// app.use('/', availablecont);
//利用可能系列情報一覧・登録
app.use('/', availableseries);
// リポリトリ一覧
app.use('/', repositories);
//イメージ一覧・登録
app.use('/', images);
// イメージセット一覧・登録
app.use('/', imagesets);
// イメージ選択
app.use('/', imageselects);
// コンテナ基本情報一覧・登録
app.use('/', containers);
//環境稼働状況一覧
app.use('/', envlist);
// 環境作成
app.use('/', envmakes);
// 業務日付変更
app.use('/', opedatemodifies);
// データインポート
app.use('/', dataimport);
/** ▲▲▲▲▲▲▲▲ ここまでが各routing ▲▲▲▲▲▲▲▲ */

/* エラーハンドラ */
app.use(function(err, req, res, next) {
    try {
        logger.error("***Exception***");
        logger.error(err);
        logger.trace(req.session);

        var isExpired = checkUtil.isSessionExpired(req.session);
        if (!isExpired && req.url != '/login') {
            commonUtil.rollbackTransaction(req, sessionUtil.getTransactionNo(req));
        }
    } catch (err) {
        logger.error(err);
    } finally {
        if (req.url != '/login') {
            sessionUtil.closeReqScope(req);
        }

        if (checkUtil.isAppError(err)) {
            res.status(err.statusCode).send(err.message);
        } else {
            res.status(500).send(commonUtil.buildSysErrorMsg(req));
        }
    }
});

module.exports = app;
