// ストレージ用キー値：メッセージ情報
const STORGE_KEY_MSG = "STORGE_KEY_MSG";
// ストレージ用キー値：機能別アプリケーション定義情報
const STORGE_KEY_APP_CONFIG = "STORGE_KEY_APP_CONFIG";
// NodeサーバURL
const BASE_URL_NODE_SERVER = "http://localhost:3000";
//URL:アプリケーション定義情報取得
const URL_GET_APP_CONFIG = BASE_URL_NODE_SERVER + '/config/appconfigs/get';
//URL:メッセージ定義情報取得
const URL_GET_MSG_CONFIG = BASE_URL_NODE_SERVER + '/config/messages/get';
//URL:WebSocket処理状況監視
const URL_PSMONITOR_WEBSOCKET = BASE_URL_NODE_SERVER + '/psmonitor';
