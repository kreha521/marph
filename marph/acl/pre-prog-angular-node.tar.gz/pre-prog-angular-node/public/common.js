var app = angular.module('angularprjApp');

//メッセージ定義情報を取得して保管
function loadAppConfig($http, $state) {
}

// メッセージ定義情報を取得して保管
function loadMsgConfig($http, $state) {
}

// 共通アプリケーション設定情報を取得する
var getAppCommonConf = function getAppCommonConf() {
    return JSON.parse(sessionStorage.getItem(STORGE_KEY_APP_CONFIG)).common;
}

// 機能別アプリケーション設定情報を取得する
var getAppConf = function getAppConf() {
    return JSON.parse(sessionStorage.getItem(STORGE_KEY_APP_CONFIG)).app;
}

// メッセージ文字列を取得する
var getMsg = function getMsg(msgId, replacements) {
    return replacePlaceHolder(JSON.parse(sessionStorage.getItem(STORGE_KEY_MSG))[msgId], replacements);
}

// 共通アプリケーション設定情報取得functionを返却
function getAppCommonConfFunc() {
    return getAppCommonConf;
}

// 機能別アプリケーション設定情報取得functionを返却
function getAppConfFunc() {
    return getAppConf;
}

// メッセージ文字列取得functionを返却
function getMsgFunc() {
    return getMsg;
}

// メッセージ内のプレースホルダの箇所を指定パラメータで置換した結果を返却する
function replacePlaceHolder(str, replacements) {
    return str.replace(/\{(\d+)\}/g, function() {
        return Array.isArray(replacements) ? replacements[arguments[1]] : replacements;
    });
}

// サーバ側処理結果メッセージ初期化
function initServerMsgs($rootScope) {
    $rootScope.serverInfoMsgs = [];
    $rootScope.serverWarnMsgs = [];
    $rootScope.serverErrorMsgs = [];
}

// サーバ側業務エラーの有無を判定
function hasServerAppError($rootScope) {
    if (!Array.isArray($rootScope.serverErrorMsgs)) {
        return false;
    }
    return $rootScope.serverErrorMsgs.length > 0;
}

// サーバ側処理結果メッセージを設定
function setServerMsgs($rootScope, data) {
    $rootScope.serverErrorMsgs = data.msgsError;
    $rootScope.serverWarnMsgs = data.msgsWarn;
    $rootScope.serverInfoMsgs = data.msgsInfo;
}

// サーバ処理エラー発生時の処理を行う
function onServerError($state, data) {
    $state.go('error', {
        "serverErrorMsgs": data.msgsError
    });
}

// ポートフォワード情報を文字列化
function toStringPortForwardInfo(portForwards) {
    var portForwardInfo = "";
    if (portForwards.length > 0) {
        for (var i=0; i < portForwards.length; i++) {
            portForwardInfo += portForwards[i].portName + ":";
            portForwardInfo += portForwards[i].portFrom + ":";
            portForwardInfo += portForwards[i].portTo + "/";
        }
    }
    return portForwardInfo;
}

// 文字列化されたポートフォワード情報を復元
function toPortForwardsFromString(stringPortForwardInfo) {
    if (!stringPortForwardInfo) {
        return [];
    }

    if (stringPortForwardInfo.slice(-1) == "/") {
        stringPortForwardInfo = stringPortForwardInfo.slice(0, -1);
    }

    var portForwards = [];
    var rows = stringPortForwardInfo.split("/");
    for (var i=0; i<rows.length; i++) {
        var cols = rows[i].split(":");
        var portForward = {
            "portName": cols[0], "portFrom": cols[1], "portTo": cols[2]
        };
        portForwards.push(portForward);
    }
    return portForwards;
}

// 共通イメージ種別であるか否かを判定
function isCommonImageTypeCd(imageId) {
    return (imageId.slice(0, 1) == "_");
}

;
