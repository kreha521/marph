angular.module('angularprjApp')

// 半角文字チェック
.directive('singlebyte',function(){
    return{
        restrict: "A",
        require: "ngModel",
        link: function(scope, element, attrs, ngModel){
            ngModel.$validators.singlebyte = function(modelValue, viewValue){
                var value = modelValue || viewValue;
                if (!value) {
                    return true;
                }
                return /^[\x20-\x7E]*$/.test(value);
            }
        }
    }
})

// 半角数値チェック
.directive('singlebyteNumber',function(){
    return{
        restrict: "A",
        require: "ngModel",
        link: function(scope, element, attrs, ngModel){
            ngModel.$validators.singlebyteNumber = function(modelValue, viewValue){
                var value = modelValue || viewValue;
                if (!value) {
                    return true;
                }
                return /^[0-9]*$/.test(value);
            }
        }
    }
})

// 半角英数字チェック
.directive('singlebyteAlphaNumber',function(){
    return{
        restrict: "A",
        require: "ngModel",
        link: function(scope, element, attrs, ngModel){
            ngModel.$validators.singlebyteAlphaNumber = function(modelValue, viewValue){
                var value = modelValue || viewValue;
                if  (!value) {
                    return true;
                }
                return /^[0-9a-zA-Z]*$/.test(value);
            }
        }
    }
})

// 半角英数字アンダーバーチェック
.directive('singlebyteAlphaNumberUnderbar',function(){
    return{
        restrict: "A",
        require: "ngModel",
        link: function(scope, element, attrs, ngModel){
            ngModel.$validators.singlebyteAlphaNumberUnderbar = function(modelValue, viewValue){
                var value = modelValue || viewValue;
                if  (!value) {
                    return true;
                }
                return /^[0-9a-zA-Z_]*$/.test(value);
            }
        }
    }
})

// パスワード文字種チェック
.directive('password',function(){
    return{
        restrict: "A",
        require: "ngModel",
        link: function(scope, element, attrs, ngModel){
            ngModel.$validators.chartype = function(modelValue, viewValue){
                var value = modelValue || viewValue;
                if  (!value) {
                    return true;
                }

                // 桁数チェック
                if (!(6 <= value.length && value.length <= 20)) {
                    return false;
                }

                // 文字種チェック
                var numOfCharType = 0;
                if (/[0-9]/.test(value)) {
                    numOfCharType++;
                }
                if (/[a-zA-Z]/.test(value)) {
                    numOfCharType++;
                }
                if (/[!-/@_]/.test(value)) {
                    numOfCharType++;
                }
                return (numOfCharType >= 2);
            }
        }
    }
})

// IPアドレス形式チェック
.directive('ipaddress',function(){
    return{
        restrict: "A",
        require: "ngModel",
        link: function(scope, element, attrs, ngModel){
            ngModel.$validators.ipaddress = function(modelValue, viewValue){
                var value = modelValue || viewValue;
                if (!value) {
                    return true;
                }
                return /^(([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/.test(value);
            }
        }
    }
})

;
