const NEW_SEQ = "(新規)";

angular.module('angularprjApp')

// ヘッダ部 領域情報フィルター
.filter('headerGroup', function() {
    return function(groupCd, groupName){
        return groupCd + ":" + groupName;
    };
})

// ヘッダ部 案件情報フィルター
.filter('headerProject', function() {
    return function(projectNo, projectName){
        return projectNo + " " + projectName;
    };
})

//組織コードフィルター
.filter('orgCd', function() {
    return function(orgCd){
        return !orgCd ? NEW_SEQ : orgCd;
    };
})

//サーバ連番フィルター
.filter('serverSeqNo', function() {
    return function(serverSeqNo){
        return !serverSeqNo ? NEW_SEQ : serverSeqNo;
    };
})

//領域コードフィルター
.filter('groupCd', function() {
    return function(groupCd){
        return !groupCd ? NEW_SEQ : groupCd;
    };
})

//イメージセット連番フィルター
.filter('imagesetSeq', function() {
    return function(imagesetSeq){
        return !imagesetSeq? NEW_SEQ : imagesetSeq;
    };
})

// 仮パスワード
.filter('pwTempFlg', function() {
    return function(pwTempFlg){
        if (pwTempFlg == "0") {
            return "";
        } else if (pwTempFlg == "1") {
            return "仮";
        }
    };
})

//コンテナ種別フィルター
.filter('containerTypeCd', function() {
    return function(containerTypeCd){
        if (containerTypeCd == '1') {
            return 'AP';
        } else if (containerTypeCd == '2') {
            return 'DB';
        } else if (containerTypeCd == '3') {
            return 'BAT';
        }
    };
})

// イメージ種別フィルター
.filter('imageTypeCd', function() {
    return function(imageId, imageTypeCd){
        if (isCommonImageTypeCd(imageId)) {
            return '共通';
        }
        if (imageTypeCd == '1') {
            return 'AP';
        } else if (imageTypeCd == '2') {
            return 'DB';
        } else if (imageTypeCd == '3') {
            return 'BAT';
        }
    };
})

;
