socket.io client js copied from http://socket.io/download/
