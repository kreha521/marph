define( function() {
	return ( /^\s+/ );
} );
