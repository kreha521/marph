var app = angular.module('angularprjApp', ['ngTextTruncate', 'ngRoute', 'ngResource','ui.bootstrap','ui.router','ngMessages','cgBusy','btford.socket-io','ngFileUpload']);
//URLとviewの紐づけ
//Controllerはindex.htmlの<script>タグで読み込み
app.config(function($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise('/login');
    $stateProvider.state('root', {
        //Login画面
        url:'/login',
        views: {
            main: {
                templateUrl:'views/login.html'
            },
        },
    }).state('selectgroup', {
        //領域選択画面
        url:'/selectgroup',
        views: {
            main: {
                templateUrl: 'views/selectgroup.html'
            }
        }
    }).state('init', {
        //ログイン後初期表示画面
        url:'/init',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/init.html',
            },
        },
    }).state('user', {
        //ユーザー管理
        url:'/user?repoId?repoName',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl:'views/user.html',
            },
        },
    }).state('userregister', {
        //ユーザー登録
        url: '/userregister?userId',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/userregister.html'
            },
        },
    }).state('repositories', {
        //リポジトリ一覧
        url:'/repositories',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl:'views/repositories.html',
            },
        },
    }).state('imagelist', {
        //イメージリスト
        url:'/imagelist?repositorySeq',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/imagelist.html',
            },
        },
    }).state('imageinfo', {
        //イメージ登録
        url:'/imageinfo?repositorySeq?imageId',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/imageinfo.html',
            },
        }
    }).state('imageset', {
        //イメージセット管理
        url:'/imageset?envCd?seriesCd?repositorySeq?imagesetSeq',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl:'views/imageset.html',
            },
        },
    }).state('imageselect', {
        //イメージ選択
        url:'/imageselect',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl:'views/imageselect.html',
            },
        },
    }).state('imagesetregister', {
        //イメージセット登録
        url:'/imagesetregister?orgCd?groupCd?repositorySeq?imagesetSeq?imegesetName?projectNo?projectName',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl:'views/imagesetregister.html',
            },
        },
    }).state('server', {
        //サーバ管理
        url: '/server',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/server.html'
            },
        },
    }).state('serverregister', {
        //サーバ基本情報登録
        url: '/serverregister?orgCd?serverSeqNo',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/serverregister.html'
            },
        },
    }).state('group', {
        //領域管理
        url: '/group',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/group.html',
            },
        },
    }).state('organizationList', {
        //組織一覧
        url: '/organizationList',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/organizationList.html',
            },
        },
    }).state('organizationRegister', {
        //組織登録
        url: '/organizationRegister?orgCd',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/organizationRegister.html',
            },
        },
    }).state('groupregister', {
        //領域登録
        url: '/groupregister?orgCd?groupCd',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/groupregister.html'
            },
        },
    }).state('series', {
      //系列管理
      url: '/series',
      views: {
        menu: {
          templateUrl:'views/menus.html'
        },
        main: {
          templateUrl: 'views/series.html',
        },
      },
    }).state('opedateupdate', {
        //業務日付更新
        url: '/opedateupdate',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/opedateupdate.html',
            },
        },
    }).state('matter', {
        //案件管理
        url: '/matter',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/matter.html',
            },
        },
    }).state('seriesregister', {
      //系列登録
      url:'/seriesregister',
      views: {
        menu: {
          templateUrl:'views/menus.html'
        },
        main: {
          templateUrl: 'views/seriesregister.html',
        },
      }
    }).state('availableseries', {
        //利用可能系列情報一覧
        url:'/availableseries',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/availableserieslist.html',
            },
        }
    }).state('availableseriesregister', {
        //利用可能系列情報登録
        url:'/availableseriesregister?envCd?seriesCd',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/availableseriesregister.html',
            },
        }
    }).state('tableImport', {
        //テーブルインポーt
        url:'/tableImport?envCd?seriesCd',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/tableImport.html',
            },
        }
    }).state('matterregister', {
        //案件登録
        url:'/matterregister?repositorySeq?orgCd?groupCd',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/matterregister.html',
            },
        }
    }).state('availablecontainer', {
        //利用可能コンテナ管理
        url: '/availablecontainer',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/availablecontainer.html',
            },
        },
    }).state('containerinfoselect', {
        //利用可能コンテナ管理
        url: '/containerinfoselect',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/containerinfoselect.html',
            },
        },
    }).state('container', {
        //コンテナ管理
        url: '/container',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/container.html',
            },
        },
    }).state('environmentlist', {
        //環境一覧
        url:'/environmentlist',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/environmentlist.html',
            },
        }
    }).state('envregister', {
        //環境登録
        url:'/envregister?orgCd?groupCd?envCd',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/envregister.html',
            },
        }
    }).state('envsave', {
        //保存名指定
        url:'/envsave?processCategory?envCd?seriesCd?repositorySeq',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/envsave.html',
            },
        }
    }).state('envlist', {
        //保存名指定
        url:'/envlist?envCd',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/envlist.html',
            },
        }
    }).state('envmake', {
        //環境作成
        url:'/envmake?envCd?seriesCd?repositorySeq?imagesetSeq',
        views: {
            menu: {
                templateUrl:'views/menus.html'
            },
            main: {
                templateUrl: 'views/envmake.html',
            },
        }
    }).state('error', {
        //エラー画面
        url:'/error',
        views: {
            main: {
                templateUrl: 'views/error.html',
            },
        },
        params:{"serverErrorMsgs":null}
    })

});

//menuのコントローラー
app.controller('menuCtl',function($scope, $http){

    var flg = JSON.parse(sessionStorage.getItem('USERINFO')).priviledgeFlg;

    //flgが0の場合、管理者権限でない
    this.admins = flg == '0';
    //メニュー選択モデル
    this.menu = {
        user: 1,
        repositories: 2,
        imageset: 3,
        server: 4,
        group: 5,
        organizationList: 6,
        organizationRegister: 7,
        matter: 8,
        series: 9,
        availableseries: 10,
        availableseriesregister: 11,
        container: 12,
        environmentlist: 13,
        envregister: 14,
        envmake: 15,
        tableImport: 16,
        gdateupdate: 17,
        tblimport: 18,
        imageinfo:19,
        availablecontainer: 20
    };
    this.currentMenu = null;

    this.changeMenu = function(selectMenu) {
        this.currentMenu = selectMenu;
    };
});

//sharedObjectのサービス登録
app.service('sharedObject', function() {
    var service = {
        error : null
    };
    return service;
});

//入力チェックエラーとなった先頭項目にフォーカス設定する
app.directive('accesibleForm', function() {
    return {
        restrict: 'A',
        link: function(scope, elem) {
            elem.on('submit', function() {
                var firstInvalid = elem[0].querySelector('.ng-invalid');
                if (firstInvalid) {
                    firstInvalid.focus();
                }
            });
        }
    };
});

// 入力チェックの汎用定義
app.directive('appValidators', function () {
    return {
        require: 'ngModel',
        scope: {
            appValidators: '=',
        },
        link: function (scope, elem, attrs, ctrl) {
            var validators = scope.appValidators || {};
            angular.forEach(validators, function (val, key) {
                ctrl.$validators[key] = val;
            });
        }
    };
});

//非同期入力チェックの汎用定義
app.directive('appAsyncValidators', function () {
    return {
        require: 'ngModel',
        scope: {
            appAsyncValidators: '='
        },
        link: function (scope, elem, attrs, ctrl) {
            var asyncValidators = scope.appAsyncValidators || {};
            angular.forEach(asyncValidators, function (val, key) {
                ctrl.$asyncValidators[key] = val;
            });
        }
    };
});

//共通アプリケーション定義情報
app.factory('AppCommonConf', function() {
    return getAppCommonConfFunc();
});

// 機能別アプリケーション定義情報
app.factory('AppConf', function() {
    return getAppConfFunc();
});

// メッセージ定義情報
app.factory('Msg', function() {
    return getMsgFunc();
});

// エラーハンドラ
app.factory('$exceptionHandler', function ($window, $log) {
    return function (exception, cause) {
        $log.debug(exception);
    };
});
