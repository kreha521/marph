angular.module('angularprjApp')

/* 組織一覧のコントローラー */
    .controller('orgMainCtrl', function($scope, $rootScope, $http, $location, $uibModal, $state, AppCommonConf, AppConf, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_DETAIL = AppCommonConf().nodeBaseUrl + '/organizations/get/_detail';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/organizations/del';


    // フォーム初期化
    $scope.initForm = function() {
        $scope.orgList = [];

        //ページング処理
        $scope.limit = 10;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;

        $scope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // サーバ覧情報表示設定
    $scope.setDispItem = function(organizations) {
        // JSONのデータを画面表示仕様に合わせて設定する
        $scope.orgList = organizations;
    };

    // 画面初期表示
    $scope.initDisp = function(funcOnSuccess) {
        // 初期表示データ取得
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_DETAIL,
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }

            $scope.setDispItem(data);
            if (funcOnSuccess) {
                // 正常終了時に実行する関数の指定がある場合は実行する
                funcOnSuccess();
            }
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };

    // ページ数取得
    $scope.range = function() {
        $scope.maxPage = Math.ceil($scope.orgList.length / $scope.itemsPerPage);
        var ret = [];
        for (var i=1; i<=$scope.maxPage; i++) {
            ret.push(i);
        }
        return ret;
    };

    // 対象ページのデータ取得設定
    $scope.page = function(page){
        $scope.begin = (page - 1) * $scope.limit;
    }

    // 更新完了メッセージ表示
    $scope.showMsgUpdateSuccess = function() {
        alert(Msg('MSG0019'));
    };

    // 追加ボタン押下時処理
    $scope.add = function() {
        // 組織登録画面
        $state.go('organizationRegister');
    };

    // メイン処理
    $scope.initForm();
    $scope.initDisp();
})


/* 組織一覧 明細部用のコントローラー */
    .controller('orgListCtrl', function($scope, $rootScope, $http, $location, $uibModal,$state, AppCommonConf, AppConf, Msg) {

    // 詳細ボタン押下処理
    $scope.show = function() {
        // 組織登録画面
        $state.go('organizationRegister', {orgCd: $scope.org.orgCd});
    };

    // 削除データ編集
    $scope.editDeleteData = function() {
        var org = {
            "updateCounter": $scope.org.updateCounter
            , "orgCd":$scope.org.orgCd
        };
        return org;
    };

    // 削除ボタン押下時処理
    $scope.delete = function() {
        $scope.isShowableMsgArea = false;

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'組織削除確認',
                        message: "組織[" +
                        $scope.org.orgCd + ":" +
                        $scope.org.orgName + "]の削除を実行します。よろしいですか？"
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_DEL,
                    headers: {'Content-Type': 'application/json'},
                    data: $scope.editDeleteData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    // 組織一覧画面を再表示
                    $scope.initDisp($scope.showMsgDeleteSuccess);
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },
            //キャンセル押下
            function(){
            }
        );
    };

    // 削除完了メッセージ表示
    $scope.showMsgDeleteSuccess = function() {
        alert(Msg('MSG0011'));
    };
});
