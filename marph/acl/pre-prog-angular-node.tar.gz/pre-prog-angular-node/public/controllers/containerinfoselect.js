angular.module('angularprjApp')

/* コンテナ情報選択のコントローラー */
.controller('containerinfoCtrl', function($scope, $rootScope, $http, AppCommonConf, AppConf, Msg) {
    // メッセージ定義情報
    $scope.Msg = Msg;

    // 画面遷移パラメータ設定
    $scope.setParams = function() {
        $scope.containerTypeCd = $scope.$resolve.params.containerTypeCd;
        $scope.containerTypeName = $scope.$resolve.params.containerTypeName;
        $scope.hostname = $scope.$resolve.params.hostname;
        $scope.ipAddress = $scope.$resolve.params.ipAddress;
        $scope.portForwardInfo = $scope.$resolve.params.portForwardInfo;
    };

    // フォーム初期化
    $scope.initForm = function() {
        $rootScope.isShowableMsgArea = false;

        //ページング処理
        $scope.limit = 5;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;

        // ポートフォワード一覧
        $scope.portForwards = toPortForwardsFromString($scope.portForwardInfo);

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // 入力チェック結果を取得
    $scope.isInvalidForm = function() {
        // 入力欄のエラーは一覧に反映されてないので考慮しない。重複チェックのみ行う
        return $scope.portDupulicateValidator();
    };

    // 完了ボタン押下時
    $scope.finish = function(){
        if ($scope.isInvalidForm()) {
            // 入力チェックエラーの場合、処理しない
            return;
        }
        $scope.$close(toStringPortForwardInfo($scope.portForwards));
    };

    // ページ数取得
    $scope.range = function() {
        $scope.maxPage = Math.ceil($scope.portForwards.length / $scope.itemsPerPage);
        var ret = [];
        for (var i=1; i<=$scope.maxPage; i++) {
            ret.push(i);
        }
        return ret;
    };

    // 対象ページのデータ取得設定
    $scope.page = function(page){
        $scope.begin = (page - 1) * $scope.limit;
    };

    // 戻るボタン押下時
    $scope.back = function(){
        $scope.$dismiss('cancel');
    };

    // ポート番号の重複チェック（エラー時にtrueを返却）
    $scope.portDupulicateValidator = function() {
        var portsFrom = {};
        var portsTo = {};
        for (var i=0; i<$scope.portForwards.length; i++) {
            var from = $scope.portForwards[i].portFrom;
            if (portsFrom[from]) {
                return true;
            } else {
                portsFrom[from] = true;
            }

            var to = $scope.portForwards[i].portTo;
            if (portsTo[to]) {
                return true;
            } else {
                portsTo[to] = true;
            }
        }
        return false;
    };

    // onload処理
    $scope.setParams();
    $scope.initForm();
})

/* ポートフォワード明細部用のコントローラー */
.controller('portForwardListCtrl', function($scope) {
    // 追加ボタン押下時
    $scope.addPortForward = function() {
        if ($scope.containerinfoForm.$invalid) {
            return;
        }

        var portForward = {
            "portName": $scope.portName
            , "portFrom": $scope.portFrom
            , "portTo": $scope.portTo
        };
        $scope.portForwards.push(portForward);
        $scope.clearInputItem();
    };

    // フォーム入力項目クリア
    $scope.clearInputItem = function(){
        $scope.portName = null;
        $scope.portFrom = null;
        $scope.portTo = null;
    };

    // 削除ボタン押下時
    $scope.delPortForward = function(i) {
        $scope.portForwards.splice(i, 1);
    };
})
