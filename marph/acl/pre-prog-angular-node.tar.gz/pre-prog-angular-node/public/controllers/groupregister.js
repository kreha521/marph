angular.module('angularprjApp')

/* 領域登録のコントローラー */
    .controller('groupRegisterCtrl', function($scope, $state, $stateParams, $rootScope, $http, $uibModal, AppCommonConf, AppConf, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_NEW = AppCommonConf().nodeBaseUrl + '/groups/get/_new';
    // URL:初期表示（編集）
    $scope.URL_GET_EDIT = AppCommonConf().nodeBaseUrl + '/groups/get/_edit';
    // URL:登録
    $scope.URL_ADD = AppCommonConf().nodeBaseUrl + '/groups/add';
    // URL:更新
    $scope.URL_UPD = AppCommonConf().nodeBaseUrl + '/groups/upd';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/groups/del';

    /* 画面遷移パラメータ設定 */
    $scope.setParam = function() {
        $scope.groupCd = $stateParams.groupCd;
        $scope.orgCd = $stateParams.orgCd;
    };

    /* フォーム初期化 */
    $scope.initForm = function() {

        $scope.orgCds = [];

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    //組織を配列に詰める
    $scope.setOrgCds = function(orgCds) {
        for (i in orgCds) {
            var orgCd = {cd: orgCds[i].cd, name: orgCds[i].name};
            $scope.orgCds.push(orgCd);
        }
    }

    // ユーザ情報表示設定
    $scope.setGroupDispItem = function(data) {
        $scope.updateCounter = data.updateCounter;
        $scope.orgCd = data.orgCd;
        $scope.groupCd = data.groupCd;
        $scope.groupName = data.groupName;
        $scope.groupShortCd = data.groupShortCd;
        $scope.logicalDelFlg = data.logicalDelFlg == "1" ? true : false;
    };

    // 画面初期表示
    $scope.initDisp = function() {
        // 新規作成
        if ($scope.isNewEdit()) {
            $rootScope.myPromise = $http({
                method: 'POST',
                url : $scope.URL_GET_NEW,
            }).success(function(data, status, headers, config) {
                setServerMsgs($rootScope, data);
                if (hasServerAppError($rootScope)) {
                    // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                    $rootScope.isShowableMsgArea = true;
                    return;
                }

                // 選択リスト設定
                $scope.setOrgCds(data.orgCds);
                $scope.orgCd = $scope.orgCds[0].cd;

            }).error(function(data, status, headers, config) {
                onServerError($state, data);
                return;
            });
        // 更新
        } else {
            $rootScope.myPromise = $http({
                method: 'POST',
                url : $scope.URL_GET_EDIT,
                headers: {'Content-Type': 'application/json'},
                data: {"groupCd": $scope.groupCd, "orgCd": $scope.orgCd}
            }).success(function(data, status, headers, config) {
                setServerMsgs($rootScope, data);
                if (hasServerAppError($rootScope)) {
                    // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                    $rootScope.isShowableMsgArea = true;
                    return;
                }
                // 選択リスト設定
                $scope.setOrgCds(data.orgCds);
                $scope.setGroupDispItem(data);
            }).error(function(data, status, headers, config) {
                onServerError($state, data);
                return;
            });
        }
    };

    /* 新規登録であるか判定 */
    $scope.isNewEdit = function() {
        return !$stateParams.orgCd || !$stateParams.groupCd;
    };

    $scope.editRegisterData = function() {
        var data = {
            "updateCounter":$scope.updateCounter
            ,"orgCd":$scope.orgCd
            , "groupCd":$scope.groupCd
            , "groupName":$scope.groupName
            , "groupShortCd":$scope.groupShortCd
            , "logicalDelFlg":$scope.logicalDelFlg ? "1" : "0"
        }
        return data;
    };

    $scope.updateData = function() {
        return $scope.editRegisterData();
    };

    // 領域登録
    $scope.register = function() {

        $rootScope.isShowableMsgArea = true;

        if ($scope.isInvalidForm()) {
            // 入力チェックエラーの場合、処理しない
            return;
        }

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'領域登録確認',
                        message: $scope.isNewEdit() ? Msg('MSG0015', '領域の登録') : Msg('MSG0015', '領域の更新')
                    };
                }
            }
        });

        // 新規なら追加、編集なら更新
        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.isNewEdit() ? $scope.URL_ADD : $scope.URL_UPD,
                    headers: { 'Content-Type': 'application/json' },
                    data: $scope.isNewEdit() ? $scope.editRegisterData() : $scope.updateData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }
                    if ($scope.isNewEdit()) {
                        alert(Msg('MSG0010'));
                    } else {
                        alert(Msg('MSG0019'));
                    }
                    $state.go('group');
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                    return;
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // 領域削除
    $scope.delete = function() {

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'領域削除確認',
                        message: Msg('MSG0015', '領域の削除')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_DEL,
                    headers: {'Content-Type': 'application/json'},
                    data: {"orgCd":$scope.orgCd, "groupCd":$scope.groupCd}
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }
                    // 領域一覧画面
                    alert(Msg('MSG0011'));
                    $state.go('group');
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                    return;
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // 入力チェック結果を取得
    $scope.isInvalidForm = function() {
        var isInvalid = $scope.grpForm.$invalid;
        return isInvalid;
    };

    // 画面遷移パラメータ設定
    $scope.setParam();

    // フォーム初期化
    $scope.initForm();

    // 編集時データ取得
    $scope.initDisp();

});
