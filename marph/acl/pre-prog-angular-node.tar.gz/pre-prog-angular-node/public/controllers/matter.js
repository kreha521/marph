angular.module('angularprjApp')

    .controller('matter1Ctl', function( $scope, $rootScope, $http, $location, $uibModal, $state, sharedObject, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

     // 初期表示データ取得
	$rootScope.myPromise = $http({
		method: 'POST',
		url : '/projects/get/_detail',
	}).success(function(data, status, headers, config) {
        $scope.setProjects(data)
    }).error(function(data, status, headers, config) {
		console.log("err");
		return;
	});


    //初期表示
    $scope.setProjects = function(data) {

        $scope.matterData = data.mattersList;

        // セッションから取得した領域情報を持ってくる
        $scope.code = data.groupName;

        //ページング処理
        $scope.limit = 10;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;
        $scope.range = function() {
            $scope.maxPage = Math.ceil($scope.matterData.length/$scope.itemsPerPage);
            var ret = [];
            for (var i=1; i<=$scope.maxPage; i++) {
                ret.push(i);
            }
            return ret;
        };
        $scope.page = function(page){
            $scope.begin = (page - 1) * $scope.limit;
        }
    }



    // 戻るボタン押下時処理
    $scope.return = function() {
        // リポジトリー覧画面表示要求
        $location.path('/init')
    };

    // 追加ボタン押下処理
    $scope.ins = function() {
        // イメージ詳細登録画面表示要求
        $state.go('matterregister', {
            repositorySeq: ""
        });

    };

    // 案件完了ボタン押下時処理
    $scope.exit = function(data) {
        // 案件完了日を登録

        // 案件完了済チェック
        if(data.completeFlg == '1'){
            //エラーメッセージ(MSG0040)を表示
            alert(Msg('MSG0040'));
            return;
        }

            // 実行確認
            var modalInstance = $uibModal.open({
                templateUrl: 'views/confirm.html',
                controller: 'ConfirmController',
                backdrop: true,
                scope: $scope,
                resolve: {
                    params:function(){
                        return {
                            title:'案件完了確認',
                            message: Msg('MSG0015', '案件[' + data.projectName + ']の案件完了')
                        };
                    }
                }
            });

			modalInstance.result.then(
				// OK押下
				function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : '/projects/exit',
                    data : data
                    }).success(function(data, status, headers, config) {
                        //案件完了メッセージ(MSG0022)を表示
                        alert(Msg('MSG0022'));

                        $scope.setProjects(data)
                    }).error(function(data, status, headers, config) {
                        console.log("err");
                        //エラーメッセージ(MSG0001)を表示
                        alert(Msg('MSG0001'));
                        return;
                    });

				},
				//キャンセル押下
				function(){
				}
			);
        };



})

//明細用のコントローラー
    .controller('matter2Ctl', function($scope, $rootScope,　$http, $location, $state) {

    // 詳細ボタン押下処理
    $scope.show = function(data) {
        // イメージ詳細登録画面表示要求
        $state.go('matterregister', {
            repositorySeq: data.repositorySeq,
            orgCd: data.orgCd,
            groupCd: data.groupCd
        });
    };
});
