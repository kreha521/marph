angular.module('angularprjApp')

/* エラー画面のコントローラー */
.controller('errorCtrl', function($scope, $state, $stateParams) {
    // 画面遷移パラメータ設定
    $scope.setParams = function() {
        $scope.serverErrorMsgs = $stateParams.serverErrorMsgs;
    };
    $scope.goTop = function() {
        $state.go('root');
    };
    // onload処理
    $scope.setParams();
})

;
