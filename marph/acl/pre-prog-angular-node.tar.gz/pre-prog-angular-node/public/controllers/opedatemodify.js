angular.module('angularprjApp')
    .controller('opedateCtl', function($scope, $rootScope, $http, $uibModalInstance, params, $uibModal, AppCommonConf, AppConf, Msg){

        // メッセージ定義情報
        $scope.Msg = Msg;

        // URL:更新
        $scope.URL_UPD = AppCommonConf().nodeBaseUrl + '/opedatemodifies/upd';

        $scope.setParam = function(){
            $scope.title = params.title;
            //TODO datepicker
            $scope.opedate = new Date(params.opedate);
            $scope.datePickerOpen = false;

            // 一時対応
            $scope.opedate = new Date();
            $scope.envCd = "01";
            $scope.seriesCd = "A";
        }

        // 日付の妥当性チェック
        $scope.isValidDate = function(){
            var matches = /^(\d+)\/(\d+)\/(\d+)$/.exec($scope.toLocaleStringSec($scope.opedate));
            if(!matches) {
                return true;
            }
            var y = parseInt(matches[1]);
            var m = parseInt(matches[2]);
            var d = parseInt(matches[3]);
            if(m < 1 || m > 12 || d < 1 || d > 31) {
                return true;
            }
            var dt = new Date(y, m - 1, d, 0, 0, 0, 0);
            if(dt.getFullYear() != y
               || dt.getMonth() != m - 1
               || dt.getDate() != d)
            {
                return true;
            }
            return false;
        }

        // 日付を文字列に変換
        $scope.toLocaleString = function(date) {
            return [
                date.getFullYear(),
                date.getMonth() + 1,
                date.getDate()
            ].join( '' );
        }

        // 日付を文字列に変換
        $scope.toLocaleStringSec = function(date) {
            try {
                return [
                    date.getFullYear(),
                    date.getMonth() + 1,
                    date.getDate()
                ].join( '/' );
            } catch(e) {
            }
        }

        $scope.initForm = function(){
            $scope.toggleDatePicker = function($event) {
                // これが重要！！！
                $event.stopPropagation();
                $scope.datePickerOpen = !$scope.datePickerOpen;
            };

            $rootScope.isShowableMsgArea = false;

            // サーバ側処理結果メッセージ初期化
            initServerMsgs($rootScope);
        }

        $scope.update = function(){
            if($scope.isValidDate()){
                return;
            }
            // 実行確認
            var modalInstance = $uibModal.open({
                templateUrl: 'views/confirm.html',
                controller: 'ConfirmController',
                backdrop: true,
                scope: $scope,
                resolve: {
                    params:function(){
                        return {
                            title:'業務日付変更確認',
                            message: "業務日付の変更を実行します。よろしいですか？"
                        };
                    }
                }
            });

            //レスポンスをモデルに設定
            modalInstance.result.then(
                //OK押下
                function(result){
                    $rootScope.myPromise = $http({
                        method: 'POST',
                        url : $scope.URL_UPD,
                        headers: { 'Content-Type': 'application/json' },
                        data: {"envCd": $scope.envCd, "seriesCd": $scope.seriesCd, "opeDate": $scope.toLocaleString($scope.opedate)}
                    }).success(function(data, status, headers, config) {
                        setServerMsgs($rootScope, data);
                        if (hasServerAppError($rootScope)) {
                            // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                            $rootScope.isShowableMsgArea = true;
                            return;
                        }
                        alert(Msg('MSG0010'));
                        $uibModalInstance.dismiss('done');
                    }).error(function(data, status, headers, config) {
                        onServerError($state, data);
                    });
                },

                //キャンセル押下
                function(){
                }
            );
        };

        $scope.return = function(){
            $uibModalInstance.dismiss('done');
        };

        // onload処理
        $scope.setParam();
        $scope.initForm();
    });
