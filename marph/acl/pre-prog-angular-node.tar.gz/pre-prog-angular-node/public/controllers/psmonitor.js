angular.module('angularprjApp')

// 処理状況監視のWebSocket
.factory('psmonitorSocket', function (socketFactory) {
    var socketIO = io.connect(URL_PSMONITOR_WEBSOCKET);

    socketIO = socketFactory({
        ioSocket: socketIO
    });

    return socketIO;
})

// 処理状況監視のWebSockeコントローラ
.controller('psmonitorCtrl', function ($scope, Msg, psmonitorSocket) {
    // メッセージ定義情報
    $scope.Msg = Msg;

    psmonitorSocket.emit('connected', {
        data: ""
    });

    psmonitorSocket.on('connection', function (data) {
        console.log("ソケット接続開始");
    });

    psmonitorSocket.on('send:status', function (data) {
        if (!data || !data.status) {
            return;
        }
        var status = data.status == '0' ? "正常終了" : "異常終了";
//        alert(msg);
        var msg = (data.pname ? data.pname : "処理") + "[" + data.id + "]" + "(" + status + ")";
        console.log(msg);
    });

    psmonitorSocket.on('disconnect', function (data) {
        console.log("ソケット接続切断");
    });
})

;