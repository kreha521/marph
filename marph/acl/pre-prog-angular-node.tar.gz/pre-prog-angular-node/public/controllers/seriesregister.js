angular.module('angularprjApp')

/* 系列情報登録画面のコントローラー */
  .controller('SeriesRegisterCtrl', function($scope, $rootScope, $http, $location, $uibModal, sharedObject) {
  /*▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ ダミーデータ設定 ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ */
  $scope.groupName = "S01：ニッセイ販売支援";
  /*▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲ ダミーデータ設定 ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲ */

  // 系列登録
  $scope.register = function() {
    var fd = new FormData();

    // 実行確認
    var modalInstance = $uibModal.open({
      templateUrl: 'views/confirm.html',
      controller: 'ConfirmController',
      backdrop: true,
      scope: $scope,
      resolve: {
        params:function(){
          return {
            title:'系列登録確認',
            message: " 系列の登録を実行します。よろしいですか？"
          };
        }
      }
    });

    //レスポンスをモデルに設定
    modalInstance.result.then(
      //OK押下
      function(result){
        //                $http.OKpost(
        //                    '/seriesregister',
        //                    fd,
        //                    {
        //                        transformRequest: null,
        //                        headers: {'Content-type':undefined}
        //                    }
        //                )
        //                .success(function (response) {
        // 系列一覧画面
        $location.path('/series')
        //                });
      },

      //キャンセル押下
      function(){
      }
    );
  };

  // 系列削除
  $scope.delete = function() {
    var fd = new FormData();

    // 実行確認
    var modalInstance = $uibModal.open({
      templateUrl: 'views/confirm.html',
      controller: 'ConfirmController',
      backdrop: true,
      scope: $scope,
      resolve: {
        params:function(){
          return {
            title:'系列削除確認',
            message: " 系列の削除を実行します。よろしいですか？"
          };
        }
      }
    });

    //レスポンスをモデルに設定
    modalInstance.result.then(
      //OK押下
      function(result){
        //                $http.OKpost(
        //                    '/deleteseries',
        //                    fd,
        //                    {
        //                        transformRequest: null,
        //                        headers: {'Content-type':undefined}
        //                    }
        //                )
        //                .success(function (response) {
        // 系列一覧画面
        $location.path('/series')
        //                });
      },

      //キャンセル押下
      function(){
      }
    );
  };

  // 戻るボタン押下時処理
  $scope.return = function() {
    // 系列一覧画面
    $location.path('/series')
  };
});
