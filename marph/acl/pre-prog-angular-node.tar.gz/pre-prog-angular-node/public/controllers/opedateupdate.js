angular.module('angularprjApp')
    .controller('opedateUpdateCtl', function( $scope, $rootScope, $http, $location, $uibModal, sharedObject) {

    //        $http.get('/getdata').success(function (response) {
    //            $scope.imageData = response;
    //        });

    $scope.repoid = sharedObject.repoid
    $scope.reponame = sharedObject.reponame

    //ページング処理
    $scope.limit = 10;   // 1ページ当たりの件数
    $scope.begin = 0;    // 現在のページの最初のindex
    $scope.itemsPerPage = $scope.limit;
    $scope.range = function() {
        $scope.maxPage = Math.ceil($scope.imageData.length/$scope.itemsPerPage);
        var ret = [];
        for (var i=1; i<=$scope.maxPage; i++) {
            ret.push(i);
        }
        return ret;
    };
    $scope.page = function(page){
        $scope.begin = (page - 1) * $scope.limit;
    }

    //TODO datepicker
    $scope.opedate = new Date();
    $scope.datePickerOpen = false;
    $scope.toggleDatePicker = function($event) {
        // これが重要！！！
        $event.stopPropagation();

        $scope.datePickerOpen = !$scope.datePickerOpen;
    };

    /********************************
  画面制御のため、post処理はコメントアウトしておく
 ********************************
        // イメージ画面表示データ要求処理
        var fd = new FormData();
        fd.append('imagesetid',sharedObject.imagesetid)

        $http.post(
            '/updopedate',
            fd,
            {
                transformRequest: null,
                headers: {'Content-type':undefined}
            }
        )
        .success(function(response) {
            // レスポンスの結果を画面表示用の領域に渡す
            $scope.imageData = response
        })
 ********************************/


    // 戻るボタン押下時処理
    $scope.return = function() {
        // リポジトリー覧画面表示要求
        $location.path('/');
    };

    // 更新ボタン押下時処理
    $scope.update = function() {
        // 業務日付更新要求
        //明細数、チェック状態をPOST引数に設定
        var fd = new FormData();
        var toDoubleDigits = function(num) {
            num+= "";
            if (num.length = 1) {
                num = '0' + num;
            }
            return num;
        };
        var opeymd = "";
        //        var yy = $scope.opedate.getFullYear();
        //        var mm = toDoubleDigits($scope.opedate.getMonth() + 1);
        //        var dd = toDoubleDigits($scope.opedate.getDate());
        var yy = $scope.opedate.getFullYear();
        var mm = ('0' + ($scope.opedate.getMonth() + 1)).slice(-2);
        var dd = ('0' + $scope.opedate.getDate()).slice(-2);
        opeymd = yy + '/' + mm + '/' + dd;
        fd.append('opedate', opeymd );
        var selCnt = 0;
        for (var i = 0;i<$scope.imageData.length;i++) {
            if ($scope.imageData[i].selflg == true) {
                fd.append('value_selid'+selCnt.toString(),$scope.imageData[i].imagesetid);
                selCnt = selCnt + 1;
            }
        }
        fd.append('value_cnt',selCnt.toString());

        if (selCnt > 0) {
            // 実行確認
            var modalInstance = $uibModal.open({
                templateUrl: 'views/confirm.html',
                controller: 'ConfirmController',
                backdrop: true,
                scope: $scope,
                resolve: {
                    params:function(){
                        return {
                            title:'更新確認',
                            message: " 業務日付更新[" + opeymd + "]を実行します。よろしいですか？"
                        };
                    }
                }
            });

            //チェックが１つでもあれば、POSTする。
            //レスポンスをモデルに設定
            modalInstance.result.then(
                //登録押下
                function(result){
                    $rootScope.myPromise = $http.post(
                        '/updateopedate',
                        fd,
                        {
                            transformRequest: null,
                            headers: {'Content-type':undefined}
                        }
                    )
                        .success(function (response) {
                        $scope.imageData = response;
                    });
                },
                //キャンセル押下
                function(){
                }
            );
        };
    }

    /***********************************************************/
    /* ダミーデータ表示用 *****************************************/
    /***********************************************************/
    $scope.groupcd = 'S01';
    $scope.groupname = 'AAAAAAAAAAAAAAAAAAAAAAAA';
    $scope.imageData = [
        {selflg:false, imagesetid:'S01A000001ITIT-A001', projectname:'テストＡ０００１対応', comment:'TEST A0001'},
        {selflg:false, imagesetid:'S01A000001ITIT-A002', projectname:'テストＡ０００２対応', comment:'TEST A0002'},
        {selflg:false, imagesetid:'S01A000001ITIT-A003', projectname:'テストＡ０００３対応', comment:'TEST A0003'},
        {selflg:false, imagesetid:'S01A000001ITIT-A004', projectname:'テストＡ０００４対応', comment:'TEST A0004'},
        {selflg:false, imagesetid:'S01A000001ITIT-A005', projectname:'テストＡ０００５対応', comment:'TEST A0005'},
        {selflg:false, imagesetid:'S01A000001ITIT-A006', projectname:'テストＡ０００６対応', comment:'TEST A0006'},
        {selflg:false, imagesetid:'S01A000001STST-B001', projectname:'テストＢ０００１対応', comment:'TEST B0001'},
        {selflg:false, imagesetid:'S01A000001STST-B002', projectname:'テストＢ０００２対応', comment:'TEST B0002'},
        {selflg:false, imagesetid:'S01A000001STST-B003', projectname:'テストＢ０００３対応', comment:'TEST B0003'},
        {selflg:false, imagesetid:'S01A000001STST-B004', projectname:'テストＢ０００４対応', comment:'TEST B0004'},
        {selflg:false, imagesetid:'S01A000001STST-B005', projectname:'テストＢ０００５対応', comment:'TEST B0005'},
    ];
})

//明細用のコントローラー
    .controller('opedateUpdateCtl2Ctl', function($scope,  $http, $location, sharedObject) {

    //チェックボタン押下処理
    $scope.check = function() {
        $scope.data.selflg = !$scope.data.selflg;
    }

});
