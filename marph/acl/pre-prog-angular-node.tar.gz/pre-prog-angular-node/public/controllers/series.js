angular.module('angularprjApp')

/* 系列一覧のコントローラー */
  .controller('SeriesCtrl', function( $scope, $rootScope, $http, $location,$uibModal, sharedObject) {
  $scope.repoid = sharedObject.repoid
  $scope.reponame = sharedObject.reponame

  //ページング処理
  $scope.limit = 10;   // 1ページ当たりの件数
  $scope.begin = 0;    // 現在のページの最初のindex
  $scope.itemsPerPage = $scope.limit;

  $scope.range = function() {
    $scope.maxPage = Math.ceil($scope.serieses.length/$scope.itemsPerPage);
    var ret = [];
    for (var i=1; i<=$scope.maxPage; i++) {
      ret.push(i);
    }
    return ret;
  };

  $scope.page = function(page){
    $scope.begin = (page - 1) * $scope.limit;
  }

  // 系列削除
  $scope.delete = function() {
    // 系列一覧削除要求
    var fd = new FormData();
    var selectCnt = 0;
    for (var i = 0;i<$scope.serieses.length;i++) {
      if ($scope.serieses[i].selectflg == true) {
        fd.append('value_selectflg'+selectCnt.toString(), $scope.serieses[i].seriesType)
        selectCnt = selectCnt + 1;
      }
    }
    fd.append('value_cnt',　selectCnt.toString())

    if (selectCnt > 0) {
      var modalInstance = $uibModal.open({
        templateUrl: 'views/confirm.html',
        controller: 'ConfirmController',
        backdrop: true,
        scope: $scope,
        resolve: {
          params:function(){
            return {
              title:'系列削除確認',
              message: " 系列の削除[" + selectCnt.toString() + "件]を実行します。よろしいですか？"
            };
          }
        }
      });

      //レスポンスをモデルに設定
      modalInstance.result.then(
        //OK押下
        function(result){
          $http.OKpost(
            '/deleteseries',
            fd,
            {
              transformRequest: null,
              headers: {'Content-type':undefined}
            }
          )
            .success(function (response) {
          });
        },

        //キャンセル押下
        function(){
        }
      );
    }
  }

  // 戻るボタン押下時処理
  $scope.return = function() {
    // メニュー画面表示要求
    $location.path('/menus')
  };

  // 追加ボタン押下時処理
  $scope.add = function() {
    // 系列詳細登録画面表示要求
    $location.path('/seriesregister')
  };

  /***********************************************************/
  /* ダミーデータ表示用 *****************************************/
  /***********************************************************/
  $scope.groupName = "S01：ニッセイ販売支援";
  $scope.serieses = [
    {selectflg:false,　containerType:'IT',　seriesType:'A',　seriesName:'IT-A環境',},
    {selectflg:false,　containerType:'IT',　seriesType:'B',　seriesName:'IT-B環境',},
    {selectflg:false,　containerType:'IT',　seriesType:'C',　seriesName:'IT-C環境',},
    {selectflg:false,　containerType:'ST',　seriesType:'A',　seriesName:'ST-A環境',},
    {selectflg:false,　containerType:'ST',　seriesType:'B',　seriesName:'ST-B環境',},
    {selectflg:false,　containerType:'ST',　seriesType:'C',　seriesName:'ST-C環境',},
  ];
})

/* 系列一覧 明細部用のコントローラー */
  .controller('Series2Ctrl', function($scope, $rootScope,  $http, $location, sharedObject) {
  //チェックボタン押下処理
  $scope.check = function() {
    $scope.series.selectflg = !$scope.series.selectflg;
  }

  // 詳細ボタン押下処理
  $scope.show = function() {
    // 系列詳細登録画面表示要求
    $location.path('/seriesregister')
  };
});
