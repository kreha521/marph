angular.module('angularprjApp')

/* ユーザ登録のコントローラー */
.controller('userRegisterCtrl', function($scope, $rootScope, $http, $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg) {
    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示（新規）
    $scope.URL_GET_NEW_EDIT = AppCommonConf().nodeBaseUrl + '/users/get/_new';
    // URL:初期表示（編集）
    $scope.URL_GET_EDIT = AppCommonConf().nodeBaseUrl + '/users/get/_edit';
    // URL:登録
    $scope.URL_ADD = AppCommonConf().nodeBaseUrl + '/users/add';
    // URL:更新
    $scope.URL_UPD = AppCommonConf().nodeBaseUrl + '/users/upd';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/users/del';

    // 初期値は空リスト
    $scope.groupCds = [];

    // 初期値は空リスト
    $scope.roleCds = [];

    $scope.roles = [];

    // 行削除した権限リスト
    $scope.deletedRoles = [];

    // 画面遷移パラメータ設定
    $scope.setParams = function() {
        $scope.userId = $stateParams.userId;
    };

    // フォーム初期化
    $scope.initForm = function() {
        //ページング処理
        $scope.limit = 5;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;

        // 選択リスト設定
        $scope.groupCd = $scope.groupCds[0];
        $scope.roleCd = $scope.roleCds[0];

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // 画面初期表示
    $scope.initDisp = function(isNewEdit, userId) {
        if (!isNewEdit) {
            $scope.dispUserItem(userId);
        } else {
            $scope.dispUserNew();
        }
    };

    // ユーザ情報表示設定
    $scope.setUserDispItem = function(user) {
        $scope.updateCounter = user.updateCounter;
        $scope.userId = user.userId;
        $scope.userName = user.userName;
        $scope.password = user.password;
        $scope.passwordConf = user.passwordConf;
        $scope.privilegeFlg = user.privilegeFlg;
        $scope.pwTempFlg = user.pwTempFlg;
        $scope.remarks = user.remarks;
    };

    //ユーザ情報登録初期表示
    $scope.dispUserNew = function() {
        $rootScope.myPromise = $http({
            method: 'POST',
            url: $scope.URL_GET_NEW_EDIT
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.password = data.password;
            $scope.passwordConf = data.passwordConf;
            $scope.setGroupCds(data.groupCds);
            $scope.setRoleCds(data.roleCds);
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    }

    // ユーザ情報表示情報取得
    $scope.dispUserItem = function(userId) {
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_EDIT,
            headers: {'Content-Type': 'application/json'},
            data: {"userId": userId}
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }

            $scope.setUserDispItem(data.tblUser);
            $scope.setRolesDispItem(data.tblUserRoles);
            $scope.setGroupCds(data.groupCds);
            $scope.setRoleCds(data.roleCds);
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };

    // ユーザ権限表示設定
    $scope.setRolesDispItem = function(userRoles) {
        for (var i=0; i<userRoles.length; i++) {
            var role = {
                "updateCounter": userRoles[i].updateCounter
                , "groupCd": userRoles[i].groupCd
                , "groupName": userRoles[i].groupName
                , "roleCd": userRoles[i].roleCd
                , "roleName": userRoles[i].roleName
            };
            $scope.roles.push(role);
        }
    };
    //領域リストを詰める
    $scope.setGroupCds = function(groupCds) {
        for (i in groupCds) {
            var groupCd = {"cd": groupCds[i].cd, "name": groupCds[i].name};
            $scope.groupCds.push(groupCd);
        }
    }
    //権限リストを詰める
    $scope.setRoleCds = function(roleCds) {
        for (i in roleCds) {
            var roleCd = {"cd": roleCds[i].cd, "name": roleCds[i].name};
            $scope.roleCds.push(roleCd);
        }
    }

    // 初期表示モード判定
    $scope.isNewEdit = function() {
        return !$stateParams.userId
    };

//    // ページ数取得
//    $scope.range = function() {
//        $scope.maxPage = Math.ceil($scope.authData.length / $scope.itemsPerPage);
//        var ret = [];
//        for (var i=1; i<=$scope.maxPage; i++) {
//            ret.push(i);
//        }
//        return ret;
//    };
//
//    // 対象ページのデータ取得設定
//    $scope.page = function(page){
//        $scope.begin = (page - 1) * $scope.limit;
//    };

//    //チェックボタン押下処理
//    $scope.checkPwtempFlg = function() {
//        $scope.pwtempFlg = !$scope.pwtempFlg;
//    };

    // 登録
    $scope.register = function() {
        $rootScope.isShowableMsgArea = true;

        if ($scope.isInvalidForm()) {
            // 入力チェックエラーの場合、処理しない
            return;
        }

        var isNewEdit = $scope.isNewEdit();

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'ユーザ情報登録確認',
                        message: isNewEdit ? Msg('MSG0015', 'ユーザ情報の登録') : Msg('MSG0015', 'ユーザ情報の更新')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : isNewEdit ? $scope.URL_ADD : $scope.URL_UPD,
                    headers: { 'Content-Type': 'application/json' },
                    data: isNewEdit ? $scope.editRegisterData() : $scope.editUpdateData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    if (isNewEdit) {
                        alert(Msg('MSG0010'));
                    } else {
                        alert(Msg('MSG0019'));
                    }
                    // ユーザ一覧画面
                    $state.go('user');
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },
            //キャンセル押下
            function(){
            }
        );
    };

    // 登録データ編集
    $scope.editRegisterData = function() {
        var user = {
            "tblUser":{
                "updateCounter": $scope.updateCounter
                , "userId":$scope.userId
                , "userName":$scope.userName
                , "password":$scope.password
                , "passwordConf":$scope.passwordConf
                , "privilegeFlg":$scope.privilegeFlg
                , "pwTempFlg":$scope.pwTempFlg
                , "remarks":$scope.remarks
            }
        };

        var userRoles = [];
        for (var i=0; i<$scope.roles.length; i++) {
            var role = {
                "updateCounter": $scope.roles[i].updateCounter
                , "userId": $scope.userId
                , "groupCd": $scope.roles[i].groupCd
                , "roleCd": $scope.roles[i].roleCd
            };
            userRoles.push(role);
        }
        user.tblUserRoles = userRoles;
        return user;
    };

    // 更新データ編集
    $scope.editUpdateData = function() {
        return $scope.editRegisterData();
    };

    // 削除データ編集
    $scope.editDeleteData = function() {
        var user = {
            "updateCounter": $scope.updateCounter
            , "userId":$scope.userId
        };
        return user;
    };

    // 削除
    $scope.delete = function() {
        $rootScope.isShowableMsgArea = false;

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'ユーザ情報削除確認',
                        message: Msg('MSG0015', 'ユーザ情報の削除')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_DEL,
                    headers: {'Content-Type': 'application/json'},
                    data: $scope.editDeleteData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    alert(Msg('MSG0011'));
                    // ユーザ一覧画面
                    $state.go('user');
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // 追加ボタン押下時
    $scope.addRole = function() {
        if (!$scope.groupCd.cd || !$scope.roleCd.cd) {
            return;
        }
        var role = {
            updateCounter: '0'
            , userId: $scope.userId
            , groupCd: $scope.groupCd.cd
            , groupName: $scope.groupCd.name
            , roleCd: $scope.roleCd.cd
            , roleName: $scope.roleCd.name
        };
        $scope.roles.push(role);
    };

    // パスワード（確認）入力チェック（エラー時にtrueを返却）
    $scope.passwordConf_validator = {
        sameValue: function (modelValue, viewValue) {
            var val = modelValue || viewValue;
            // パスワードと不一致であればエラー
            return (val == $scope.password);
        }
    };

    // 入力チェック結果を取得
    $scope.isInvalidForm = function() {
        var isInvalid = $scope.user.$invalid;

        // バリデーターじゃなく、普通のfunctionでチェックしてる箇所の処理結果を考慮
        isInvalid = isInvalid || $scope.rolesCnt_validator();
        isInvalid = isInvalid || $scope.rolesDupulicate_validator();

        return isInvalid;
    };

    // 権限明細の０件チェック（エラー時にtrueを返却）
    $scope.rolesCnt_validator = function() {
        return ($scope.roles.length <= 0);
    };

    // 権限明細の重複チェック（エラー時にtrueを返却）
    $scope.rolesDupulicate_validator = function() {
        var keys = {};
        for (var i=0; i<$scope.roles.length; i++) {
            var key = $scope.roles[i].groupCd + "|" + $scope.roles[i].roleCd;
            if (keys[key]) {
                return true;
            }
            keys[key] = true;
        }
        return false;
    };

    // onload処理
    $scope.setParams();
    $scope.initForm();
    var isNewEdit = $scope.isNewEdit();
    $scope.initDisp(isNewEdit, $scope.userId);
})

/* ユーザ登録（権限）のコントローラー */
.controller('userRolesCtrl', function($scope, $http, $uibModal, $state) {
    // 削除ボタン押下時
    $scope.deleteRole = function(index) {
        $scope.deletedRoles.push($scope.roles[index]);
        $scope.roles.splice(index, 1);
    };
})

