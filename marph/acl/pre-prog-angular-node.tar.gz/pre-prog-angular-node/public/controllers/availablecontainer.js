angular.module('angularprjApp')

    .controller('availableContainerCtl', function( $scope, $http, $rootScope,$uibModal, $stateParams,$state, AppCommonConf, AppConf, Msg) {


    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_LIST = AppCommonConf().nodeBaseUrl + '/availablecont/get/_detail';
    // URL:削除
//    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/availablecont/delete';

    // フォーム初期化
    $scope.initForm = function() {
//        $scope.availableSeriesList = [];
        $scope.availableContainerData = [];

        //ページング処理
        $scope.limit = 10;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // コンテナ一覧情報表示設定
    $scope.setDispItem = function(data) {
        $scope.availableContainerData = [];
        $scope.groupName = data.groupShortCd + "：" + data.groupName;

        // JSONのデータを画面表示仕様に合わせて設定する
//        var containerTblDatas = [];
        for (var i=0; i<data.availableContainerData.length; i++) {
            var dispItem = new Object();
//            dispItem.groupCd = availableContainerData[i].acs.groupCd;
//            dispItem.envCd = availableContainerData[i].acs.envCd;
            dispItem.envName = data.availableContainerData[i].envs.envName;
//            dispItem.seriesCd = availableContainerData[i].acs.seriesCd;
            dispItem.seriesName = data.availableContainerData[i].ass.seriesName;
            dispItem.containertype = data.availableContainerData[i].acs.containerTypeCdName;
            dispItem.containername = data.availableContainerData[i].acs.containerTypeName;
            dispItem.ipaddress = data.availableContainerData[i].acs.ipAddress;
            $scope.availableContainerData.push(dispItem);

            // 登録・削除用
//            $scope.groupCd =  availableContainerData[i].acs.groupCd
//            $scope.orgCd =  availableContainerData[i].acs.orgCd

//            containerTblDatas[i] = availableContainerData[i].acs

        }
//        $scope.ContainerTableData = containerTblDatas
    };


     // 画面初期表示
    $scope.initDisp = function(funcOnSuccess) {
    $rootScope.myPromise = $http({
        method: 'POST',
        url : $scope.URL_GET_LIST
    }).success(function(data, status, headers, config) {
        setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.setDispItem(data);

        if (funcOnSuccess) {
                // 正常終了時に実行する関数の指定がある場合は実行する
                funcOnSuccess();
            }
    }).error(function(data, status, headers, config) {
        $state.go('error');
    });
   };

    // ページ数取得
    $scope.range = function() {
        $scope.maxPage = Math.ceil($scope.availableContainerData.length / $scope.itemsPerPage);
        var ret = [];
        for (var i=1; i<=$scope.maxPage; i++) {
            ret.push(i);
        }
        return ret;
    };

    // 対象ページのデータ取得設定
    $scope.page = function(page){
        $scope.begin = (page - 1) * $scope.limit;
    }

    // onload処理
    $scope.initForm();
    $scope.initDisp();

});
