angular.module('angularprjApp')

/* ユーザ一覧のコントローラー */
.controller('userCtrl', function($scope, $rootScope, $http, $location, $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg) {
    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_LIST = AppCommonConf().nodeBaseUrl + '/users/get/_list';
    // URL:パスワードリセット
    $scope.URL_PASS_RESET = AppCommonConf().nodeBaseUrl + '/users/password/reset';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/users/del';

    // 画面遷移パラメータ設定
    $scope.setParams = function() {
        $scope.repoId = $stateParams.repoId;
        $scope.reponame = $stateParams.repoName;
    };

    // フォーム初期化
    $scope.initForm = function() {
        $scope.users = [];

        //ページング処理
        $scope.limit = 10;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // ユーザ一覧情報表示設定
    $scope.setDispItem = function(users) {
        // JSONのデータを画面表示仕様に合わせて設定する
        for (var i=0; i<users.length; i++) {
            var roleCount = users[i].roleCount;
            users[i] = users[i].tblUser;
            users[i].roleCount = roleCount;
            users[i].selectflg = false;
        }
        $scope.users = users
    };

    // 画面初期表示
    $scope.initDisp = function(funcOnSuccess) {
        // 初期表示データ取得
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_LIST,
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }

            $scope.setDispItem(data);
            if (funcOnSuccess) {
                // 正常終了時に実行する関数の指定がある場合は実行する
                funcOnSuccess();
            }
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };

    // ページ数取得
    $scope.range = function() {
        $scope.maxPage = Math.ceil($scope.users.length / $scope.itemsPerPage);
        var ret = [];
        for (var i=1; i<=$scope.maxPage; i++) {
            ret.push(i);
        }
        return ret;
    };

    // 対象ページのデータ取得設定
    $scope.page = function(page){
        $scope.begin = (page - 1) * $scope.limit;
    };

    // 更新データ編集（パスワードリセット）
    $scope.editPasswordResetData = function() {
        var users = [];
        for (var i=0; i<$scope.users.length; i++) {
            if ($scope.users[i].selectflg) {
//                var user = {
//                    "updateCounter": $scope.users[i].updateCounter
//                    , "userId":$scope.users[i].userId
//                };
                users.push($scope.users[i]);
            }
        }
        return users;
    };

    // パスワードリセット
    $scope.resetPass = function() {
        $rootScope.isShowableMsgArea = true;

        var selectCnt = 0;
        for (var i=0; i<$scope.users.length; i++) {
            if ($scope.users[i].selectflg) {
                selectCnt = selectCnt + 1;
            }
        }

        if (selectCnt > 0) {
            // 実行確認
            var modalInstance = $uibModal.open({
                templateUrl: 'views/confirm.html',
                controller: 'ConfirmController',
                backdrop: true,
                scope: $scope,
                resolve: {
                    params:function(){
                        return {
                            title:'パスワードリセット確認',
                            message: Msg('MSG0015', 'パスワードのリセット['+ selectCnt.toString() + '件]')
                        };
                    }
                }
            });

            //レスポンスをモデルに設定
            modalInstance.result.then(
                // OK押下
                function(result){
                    $rootScope.myPromise = $http({
                        method: 'POST',
                        url : $scope.URL_PASS_RESET,
                        headers: { 'Content-Type': 'application/json' },
                        data: $scope.editPasswordResetData()
                    }).success(function(data, status, headers, config) {
                        setServerMsgs($rootScope, data);
                        if (hasServerAppError($rootScope)) {
                            // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                            $rootScope.isShowableMsgArea = true;
                            return;
                        }

                        // ユーザ一覧画面を再表示
                        $scope.initDisp($scope.showMsgUpdateSuccess);
                    }).error(function(data, status, headers, config) {
                        onServerError($state, data);
                    });
                },
                //キャンセル押下
                function(){
                }
            );
        }
    };

    // 更新完了メッセージ表示
    $scope.showMsgUpdateSuccess = function() {
        alert(Msg('MSG0019'));
    };

    // 追加ボタン押下時処理
    $scope.add = function() {
        // ユーザ登録画面
        $state.go('userregister');
    };

    // onload処理
    $scope.setParams();
    $scope.initForm();
    $scope.initDisp();
})

//明細用のコントローラー
.controller('userListCtrl', function($scope, $rootScope, $http, $uibModal, $state, AppCommonConf, AppConf, Msg) {
    //チェックボタン押下処理
    $scope.check = function() {
        $scope.user.selectflg = !$scope.user.selectflg;
    };

    // 詳細ボタン押下処理
    $scope.show = function() {
        // ユーザ登録画面
        $state.go('userregister', {
            userId: $scope.user.userId
        });
    };

    // ユーザ削除
    $scope.delete = function() {
        $rootScope.isShowableMsgArea = false;

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'ユーザ削除確認',
                        message: Msg('MSG0015', 'ユーザ[' + $scope.user.userId + ':' + $scope.user.userName + ']の削除')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_DEL,
                    headers: {'Content-Type': 'application/json'},
                    data: {"userId":$scope.user.userId, "updateCounter": $scope.user.updateCounter}
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    // ユーザ一覧画面を再表示
                    $scope.initDisp($scope.showMsgDeleteSuccess);
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },
            //キャンセル押下
            function(){
            }
        );
    };

    // 削除完了メッセージ表示
    $scope.showMsgDeleteSuccess = function() {
        alert(Msg('MSG0011'));
    };
});
