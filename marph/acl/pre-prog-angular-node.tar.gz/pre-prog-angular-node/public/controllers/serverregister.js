angular.module('angularprjApp')

/* サーバ登録のコントローラー */
.controller('serverRegisterCtrl', function($scope, $rootScope, $http, $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg) {
    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示（新規）
    $scope.URL_GET_NEW_EDIT = AppCommonConf().nodeBaseUrl + '/servers/get/_new';
    // URL:初期表示（編集）
    $scope.URL_GET_EDIT = AppCommonConf().nodeBaseUrl + '/servers/get/_edit';
    // URL:登録
    $scope.URL_ADD = AppCommonConf().nodeBaseUrl + '/servers/add';
    // URL:更新
    $scope.URL_UPD = AppCommonConf().nodeBaseUrl + '/servers/upd';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/servers/del';

    // 画面遷移パラメータ設定
    $scope.setParams = function() {
        $scope.orgCd = $stateParams.orgCd
        $scope.serverSeqNo = $stateParams.serverSeqNo
    };

    // フォーム初期化
    $scope.initForm = function() {
        $rootScope.isShowableMsgArea = false;

        // サーバ種別（初期値は空リスト)
        $scope.serverTypeCds= [];
        // 組織(初期値は空リスト)
        $scope.orgCds = [];
        // コンテナ一覧
        $scope.containers = [];
        $scope.showContainers = false;

        // コンテナ追加モード
        $scope.addContainerMode = !$scope.isNewEdit();

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // コンテナ追加モード設定
    $scope.hasContainers = function(containers) {
        $scope.showContainers = (Array.isArray(containers) && containers.length > 0);
        return $scope.showContainers;
    }

    // サーバ情報表示設定
    $scope.setServerDispItem = function(server) {
        $scope.updateCounter = server.updateCounter;
        $scope.serverSeqNo = server.serverSeqNo;
        $scope.serverName = server.serverName;
        $scope.ipAddress = server.ipAddress;
    };

    // 画面初期表示
    $scope.initDisp = function() {
        if ($scope.isNewEdit()) {
            //新規の場合はコンボボックスの値取得
            $rootScope.myPromise = $http({
                method: 'POST',
                url : $scope.URL_GET_NEW_EDIT,
                headers: {'Content-Type': 'application/json'},
            }).success(function(data, status, headers, config) {
                setServerMsgs($rootScope, data);
                if (hasServerAppError($rootScope)) {
                    // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                    $rootScope.isShowableMsgArea = true;
                    return;
                }

                $scope.setServerTypeCds(data.serverTypeCds);
                $scope.setOrgCds(data.orgCds);
                $scope.setContainerTypeCds(data.containerTypeCds);

                $scope.hasContainers(null);
            }).error(function(data, status, headers, config) {
               onServerError($state, data);
            });
        } else {
            $rootScope.myPromise = $http({
                method: 'POST',
                url : $scope.URL_GET_EDIT,
                headers: {'Content-Type': 'application/json'},
                data: {"orgCd": $scope.orgCd,"serverSeqNo": $scope.serverSeqNo}
            }).success(function(data, status, headers, config) {
                setServerMsgs($rootScope, data);
                if (hasServerAppError($rootScope)) {
                    // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                    $rootScope.isShowableMsgArea = true;
                    return;
                }

                $scope.setServerDispItem(data.tblServer);
                $scope.setServerTypeCds(data.serverTypeCds);
                $scope.setOrgCds(data.orgCds);
                $scope.setContainerTypeCds(data.containerTypeCds);

                $scope.containers = data.containers;
                $scope.hasContainers($scope.containers);

                // 選択リスト設定
                $scope.serverTypeCd = data.tblServer.serverTypeCd;
                $scope.orgCd = data.tblServer.orgCd;
            }).error(function(data, status, headers, config) {
               onServerError($state, data);
            });
        }
    };

    //サーバ種別を配列に詰める
    $scope.setServerTypeCds = function(serverTypeCds) {
        $scope.serverTypeCds = serverTypeCds;
    }

    //組織を配列に詰める
    $scope.setOrgCds = function(orgCds) {
        $scope.orgCds = orgCds;
    }

    // コンテナ種別を詰める
    $scope.setContainerTypeCds = function(containerTypeCds) {
        $scope.containerTypeCds = containerTypeCds;
    }

    // 初期表示モード判定
    $scope.isNewEdit = function() {
        return !$stateParams.serverSeqNo
    };

    // 登録データ編集
    $scope.editRegisterData = function() {
        var server = {
            "tblServer":{
                "updateCounter": $scope.updateCounter
                , "orgCd":$scope.orgCd
                , "serverSeqNo":$scope.serverSeqNo
                , "serverName":$scope.serverName
                , "serverTypeCd":$scope.serverTypeCd
                , "ipAddress":$scope.ipAddress
            }
        };

        var containers = [];
        for (var i=0; i<$scope.containers.length; i++) {
            var container = {
                "updateCounter": $scope.containers[i].updateCounter
                , "containerTypeCd": $scope.containers[i].containerTypeCd
                , "containerTypeName": $scope.containers[i].containerTypeName
                , "ipAddress": $scope.containers[i].containerIpAddress
            };
            containers.push(container);
        }
        server.tblContainers = containers;

        return server;
    };

    // 更新データ編集
    $scope.editUpdateData = function() {
        return $scope.editRegisterData();
    };

    // 登録
    $scope.register = function() {
        $scope.isShowableMsgArea = true;

        if ($scope.isInvalidForm()) {
            // 入力チェックエラーの場合、処理しない
            return;
        }

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'サーバ情報登録確認',
                        message: $scope.isNewEdit() ? Msg('MSG0015', 'サーバ情報の登録') : Msg('MSG0015', 'サーバ情報の更新')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.isNewEdit() ? $scope.URL_ADD : $scope.URL_UPD,
                    headers: { 'Content-Type': 'application/json' },
                    data: $scope.isNewEdit() ? $scope.editRegisterData() : $scope.editUpdateData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    if ($scope.isNewEdit()) {
                        alert(Msg('MSG0010'));
                    } else {
                        alert(Msg('MSG0019'));
                    }
                    // サーバ一覧画面
                    $state.go('server');
                }).error(function(data, status, headers, config) {
                   onServerError($state, data);
                });
            },
            //キャンセル押下
            function(){
            }
        );
    };


    // 削除データ編集
    $scope.editDeleteData = function() {
        var server = {
            "updateCounter": $scope.updateCounter
            , "orgCd":$scope.orgCd
            , "serverSeqNo":$scope.serverSeqNo
        };
        return server;
    };

    // 削除
    $scope.delete = function() {
        $scope.isShowableMsgArea = false;

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'サーバ情報削除確認',
                        message: Msg('MSG0015', 'サーバ情報の削除')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_DEL,
                    headers: {'Content-Type': 'application/json'},
                    data: $scope.editDeleteData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    alert(Msg('MSG0011'));
                    // サーバ一覧画面
                    $state.go('server');
                }).error(function(data, status, headers, config) {
                   onServerError($state, data);
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // 入力チェック結果を取得
    $scope.isInvalidForm = function() {
        var isInvalid = $scope.srvRegisterForm.$invalid;
        return isInvalid;
    };

    // onload処理
    $scope.setParams();
    $scope.initForm();
    $scope.initDisp();
})

/* コンテナ明細部用のコントローラー */
.controller('containerListCtrl', function($scope, $rootScope) {
    // 追加ボタン押下時
    $scope.addCntnr = function() {
        var container = {
            "containerTypeName": $scope.containerTypeName
            , "containerIpAddress": $scope.containerIpAddress
        };
        $scope.containers.push(container);
        $scope.hasContainers($scope.containers);
    };

    // 削除ボタン押下時
    $scope.delCntnr = function(i) {
        $scope.containers.splice(i, 1);
    };
})
