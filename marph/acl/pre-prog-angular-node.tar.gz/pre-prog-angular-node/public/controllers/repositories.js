angular.module('angularprjApp')

.controller('imageCtl', function($scope, $rootScope, $http, $stateParams, $state, AppCommonConf, AppConf, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_DETAIL = AppCommonConf().nodeBaseUrl + '/repositories/get/_detail';

    /* フォーム初期化 */
    $scope.initForm = function() {

        $scope.repoData = [];

        //ページング処理
        $scope.limit = 10;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // リポジトリ一覧情報表示設定
    $scope.setDispItem = function(data) {
        $scope.repoData = [];
        // JSONのデータを画面表示仕様に合わせて設定する
        for (var i=0; i<data.data.length; i++) {
            var wkgroup = new Object();
            wkgroup.orgCd = data.data[i].orgCd;
            wkgroup.groupCd = data.data[i].groupCd;
            wkgroup.repoid = data.data[i].repositorySeq;
            wkgroup.projectNo = data.data[i].projectNo;
            wkgroup.projectName = data.data[i].projectName;
            $scope.repoData.push(wkgroup);
        }

        $scope.groupName = data.groupShortCd + "：" + data.groupName;
        $scope.orgCd = data.orgCd;
        $scope.groupCd = data.groupCd;
    };

    // 画面初期表示
    $scope.initDisp = function() {
        // 初期表示データ取得
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_DETAIL,
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.setDispItem(data);
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
            return;
        });
    };

    // ページ数取得
    $scope.range = function() {
        $scope.maxPage = Math.ceil($scope.repoData.length/$scope.itemsPerPage);
        var ret = [];
        for (var i=1; i<=$scope.maxPage; i++) {
            ret.push(i);
        }
        return ret;
    };

    // 対象ページのデータ取得設定
    $scope.page = function(page){
        $scope.begin = (page - 1) * $scope.limit;
    }

    // onload処理
    $scope.initForm();
    $scope.initDisp();

})

.controller('imageListCtl', function($scope, $http, $location, $state) {
    $scope.edit = function() {
        $state.go('imagelist', {
            repositorySeq: $scope.data.repoid
        });
    }
})

