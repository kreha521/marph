angular.module('angularprjApp')

.controller('availableSeriesCtl', function($scope, $rootScope, $http, $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg) {
    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_LIST = AppCommonConf().nodeBaseUrl + '/availableseries/get/_detail';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/availableseries/delete';

    // 画面遷移パラメータ設定
    $scope.setParams = function() {
    };

    // フォーム初期化
    $scope.initForm = function() {
        $scope.availableSeriesList = [];

        //ページング処理
        $scope.limit = 10;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // ユーザ一覧情報表示設定
    $scope.setDispItem = function(data) {
        $scope.groupName = data.groupName

        var availableSeriesList = data.availableSeriesList;
        // JSONのデータを画面表示仕様に合わせて設定する
        var dispItems = [];
        for (var i=0; i<availableSeriesList.length; i++) {
            var dispItem = {};
            dispItem.updateCounter = availableSeriesList[i].updateCounter;
            dispItem.groupCd = availableSeriesList[i].groupCd;
            dispItem.envCd = availableSeriesList[i].envCd;
            dispItem.envName = availableSeriesList[i].envName;
            dispItem.seriesCd = availableSeriesList[i].seriesCd;
            dispItem.seriesName = availableSeriesList[i].seriesName;
            dispItem.statusCd = availableSeriesList[i].statusCd;
            dispItem.status = availableSeriesList[i].status;
            dispItems.push(dispItem);
        }
        $scope.availableSeriesList = dispItems
    };

    // 画面初期表示
    $scope.initDisp = function(funcOnSuccess) {
        // 初期表示データ取得
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_LIST,
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }

            $scope.setDispItem(data);
            if (funcOnSuccess) {
                // 正常終了時に実行する関数の指定がある場合は実行する
                funcOnSuccess();
            }
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };

    // ページ数取得
    $scope.range = function() {
        $scope.maxPage = Math.ceil($scope.availableSeriesList.length / $scope.itemsPerPage);
        var ret = [];
        for (var i=1; i<=$scope.maxPage; i++) {
            ret.push(i);
        }
        return ret;
    };

    // 対象ページのデータ取得設定
    $scope.page = function(page){
        $scope.begin = (page - 1) * $scope.limit;
    }

    // 追加ボタン押下時処理
    $scope.add = function() {
        // 利用可能系列情報登録画面表示要求
        $state.go('availableseriesregister');
    };

    // onload処理
    $scope.setParams();
    $scope.initForm();
    $scope.initDisp();
})

//明細用のコントローラー
.controller('availableSeriesListCtl', function($scope, $rootScope, $http, $state, $uibModal, AppCommonConf, AppConf, Msg) {
    // 詳細ボタン押下処理
    $scope.show = function() {
        // 利用可能系列情報登録表示要求
        $state.go('availableseriesregister', {
            envCd: $scope.availableSeries.envCd
            , seriesCd: $scope.availableSeries.seriesCd
        });
    };

    // 削除リクエストデータ編集
    $scope.editDeleteData = function() {
        var deleteKeys = {
            "envCd": $scope.availableSeries.envCd
            , "seriesCd": $scope.availableSeries.seriesCd
            , "updateCounter": $scope.availableSeries.updateCounter
        };
        return deleteKeys;
    };

    // 利用可能系列情報削除
    $scope.delete = function() {
        $rootScope.isShowableMsgArea = false;

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'利用可能系列情報削除確認',
                        message: Msg('MSG0015', '利用可能系列情報[' + $scope.availableSeries.envName + ':' + $scope.availableSeries.seriesName + ']の削除')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_DEL,
                    headers: {'Content-Type': 'application/json'},
                    data: $scope.editDeleteData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    // 一覧画面を再表示
                    $scope.initDisp($scope.showMsgDeleteSuccess);
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },
            //キャンセル押下
            function(){
            }
        );
    };

    // 削除完了メッセージ表示
    $scope.showMsgDeleteSuccess = function() {
        alert(Msg('MSG0011'));
    };
})

;
