angular.module('angularprjApp')

    .controller('imageselectCtl', function( $scope, $http, $state, $rootScope, params, $uibModalInstance, AppCommonConf, AppConf, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_LIST = AppCommonConf().nodeBaseUrl + '/imageselects/get/_list';

    // 引数取得
    $scope.setParam = function() {
        $scope.repositorySeq = params.repositorySeq;
    };

    // フォーム初期化
    $scope.initForm = function() {
        $scope.imageselectData = [];

        //ページング処理
        $scope.limit = 10;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // イメージ一覧データ取得
    $scope.initDisp = function() {
        // 初期表示データ取得
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_LIST,
            headers: {'Content-Type': 'application/json'},
            data: {"repositorySeq": $scope.repositorySeq}
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.setDispItem(data);
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
            return;
        });
    };

    // イメージ一覧情報表示設定
    $scope.setDispItem = function(images) {
        // JSONのデータを画面表示仕様に合わせて設定する
        for (var i = 0; i < images.tblImages.length; i++) {
            var wkgroup = new Object();
            wkgroup.orgCd = images.tblImages[i].orgCd;
            wkgroup.groupCd = images.tblImages[i].groupCd;
            wkgroup.repositorySeq = images.tblImages[i].repositorySeq;
            wkgroup.ankenNo = images.tblRepositoryInfo.projectNo;
            wkgroup.ankenName = images.tblRepositoryInfo.projectName;
            wkgroup.imageId= images.tblImages[i].imageId;
            wkgroup.imageTypeCd = images.tblImages[i].imageTypeCd;
            wkgroup.imageTypeName = images.tblImages[i].imageTypeName;
            $scope.imageselectData.push(wkgroup);
        }
    };

    // ページ数取得
    $scope.range = function() {
        $scope.maxPage = Math.ceil($scope.imageselectData.length/$scope.itemsPerPage);
        var ret = [];
        for (var i=1; i<=$scope.maxPage; i++) {
            ret.push(i);
        }
        return ret;
    };

    // 対象ページのデータ取得設定
    $scope.page = function(page){
        $scope.begin = (page - 1) * $scope.limit;
    }

    // 明細選択
    $scope.sel = function(index){
        $scope.ret_data = $scope.imageselectData[index];
        $uibModalInstance.close($scope);
    };

    // 戻る
    $scope.return = function(){
        $uibModalInstance.dismiss('done');
    };

    // onload処理
    $scope.setParam();
    $scope.initForm();
    $scope.initDisp();
});
