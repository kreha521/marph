angular.module('angularprjApp')

/* サーバ一覧のコントローラー */
    .controller('envMakeCtrl', function($scope, $rootScope, $http, $location, $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_DETAIL = AppCommonConf().nodeBaseUrl + '/envmakes/get/_detail';
    // URL:登録
    $scope.URL_CREATE = AppCommonConf().nodeBaseUrl + '/envmakes/create';

    // パラメータ引き渡し
    $scope.setParam = function() {
        $scope.envCd = $stateParams.envCd;
        $scope.seriesCd = $stateParams.seriesCd;
        $scope.repositorySeq = $stateParams.repositorySeq;
        $scope.imagesetSeq = $stateParams.imagesetSeq;
    };

    // フォーム初期化
    $scope.initForm = function() {
        $scope.repositorySeqs = [];

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // 画面初期表示
    $scope.initDisp = function() {
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_DETAIL,
            headers: {'Content-Type': 'application/json'},
            data: {
                "envCd": $scope.envCd,
                "seriesCd": $scope.seriesCd,
                "repositorySeq": $scope.repositorySeq,
                "imagesetSeq": $scope.imagesetSeq
            }
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.setRepositorySeqs(data.prdTypeCds);
            $scope.setEnvMakeDispItem(data);
            //案件リスト設定
            $scope.repositorySeqAfter= $scope.repositorySeq;
            //イメージセット名設定
            $scope.imagesetnameAfter= $scope.imagesetname;
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
            return;
        });
    };

    // 案件セレクトボックスを詰める
    $scope.setRepositorySeqs = function(data) {
        for (var i = 0; i < data.length; i++) {
            var wkgroup = new Object();
            wkgroup.cd = data[i].repositorySeq;
            wkgroup.name = data[i].projectNo + "：" + data[i].projectName;
            $scope.repositorySeqs.push(wkgroup);
        }
    }


    // 対象データ設定
    $scope.setEnvMakeDispItem = function(envMakeData) {
        $scope.groupname = envMakeData.groupShortCd + ":" + envMakeData.groupName;
        $scope.envcode = envMakeData.envCd;
        $scope.seriescode = envMakeData.seriesCd;
        $scope.seriesname = envMakeData.seriesName;
        $scope.projectno = envMakeData.availableSeries .repoInf.projectNo;
        $scope.projectname = envMakeData.availableSeries.repoInf.projectName;
        $scope.imagesetseq = envMakeData.availableSeries.imgSet.imagesetSeq;
        $scope.imagesetname = envMakeData.availableSeries.imgSet.imagesetName;
        $scope.repositorySeq = envMakeData.availableSeries.repoInf.repositorySeq;
    };

    // キャンセルボタン押下時処理
    $scope.return = function() {
        // イメージセット一覧画面
        $state.go('imageset');
    };

    // 登録
    $scope.register = function() {

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'環境作成確認',
                        message: Msg('MSG0015', '環境の作成')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_CREATE,
                    headers: { 'Content-Type': 'application/json' },
                    data: {
                        "envCd": $scope.envCd,
                        "seriesCd": $scope.seriesCd,
                        "repositorySeq": $scope.repositorySeq,
                        "imagesetSeq": $scope.imagesetSeq,
                        "repositorySeqAfter": $scope.repositorySeqAfter,
                        "imagesetnameAfter": $scope.imagesetnameAfter
                    }
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }
                    alert(Msg('MSG0010'));
                    $state.go('envlist',{
                        envCd:$scope.envCd,
                    });
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // onload処理
    $scope.setParam();
    $scope.initForm();
    $scope.initDisp();
});
