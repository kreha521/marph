angular.module('angularprjApp')

.controller('imageInfoCtrl', function($scope, $rootScope, $http, $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg) {
    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示（編集）
    $scope.URL_GET_EDIT = AppCommonConf().nodeBaseUrl + '/images/get/_edit';
    // URL:登録
    $scope.URL_ADD = AppCommonConf().nodeBaseUrl + '/images/add';
    // URL:更新
    $scope.URL_UPD = AppCommonConf().nodeBaseUrl + '/images/upd';

    // 画面遷移パラメータ設定
    $scope.setParams = function() {
        $scope.repositorySeq = Number($stateParams.repositorySeq);
        $scope.imageId = $stateParams.imageId;
    };

    // 追加/更新モード
    $scope.isNewEdit = function() {
        return !$scope.updateCounter;
    };

    // 画面初期表示
    $scope.initDisp = function(isNewEdit) {
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_EDIT,
            headers: {'Content-Type': 'application/json'},
            data: $scope.editDispImageData()
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }

            $scope.groupCd = data.groupCd;
            $scope.groupName = data.groupName;
            $scope.setRepositoryDispItem(data.tblRepositoryInfo);
            $scope.setImageDispItem(data.tblImages);
            $scope.setImageTypeCds(data.imageTypeCds);
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };

    // フォーム初期化
    $scope.initForm = function() {
        $scope.isShowableMsgArea = false;

        $scope.imageTypeCds = [];

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // 入力チェック結果を取得
    $scope.isInvalidForm = function() {
        return $scope.image.$invalid;
    };

    // イメージ取得条件データ編集
    $scope.editDispImageData = function() {
        return {
            "repositorySeq": $scope.repositorySeq
            , "imageId": $scope.imageId
        }
    };

    // リポジトリ表示設定
    $scope.setRepositoryDispItem = function(image) {
        $scope.projectNo = image.projectNo
        $scope.projectName = image.projectName;
    };

    // イメージ表示設定
    $scope.setImageDispItem = function(image) {
        $scope.updateCounter = image.updateCounter;
        $scope.imageTypeCd = image.imageTypeCd;
    };

    // イメージ種別リストを詰める
    $scope.setImageTypeCds = function(imageTypeCds) {
        $scope.imageTypeCds = imageTypeCds;
    };

    // 登録
    $scope.register = function() {
        $scope.isShowableMsgArea = true;

        if ($scope.isInvalidForm()) {
            // 入力チェックエラーの場合、処理しない
            return;
        }

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'イメージ登録確認',
                        message: $scope.isNewEdit() ? Msg('MSG0015', 'イメージの登録') : Msg('MSG0015', 'イメージの更新')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.isNewEdit() ? $scope.URL_ADD : $scope.URL_UPD,
                    headers: { 'Content-Type': 'application/json' },
                    data: $scope.isNewEdit() ? $scope.editRegisterData() : $scope.editUpdateData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    if ($scope.isNewEdit()) {
                        alert(Msg('MSG0010'));
                    } else {
                        alert(Msg('MSG0019'));
                    }
                    // イメージ一覧画面
                    $state.go('imagelist', {
                        repositorySeq: $scope.repositorySeq
                    });
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },
            //キャンセル押下
            function(){
            }
        );
    };

    // 登録データ編集
    $scope.editRegisterData = function() {
        return {
            "updateCounter": $scope.updateCounter
            , "repositorySeq": $scope.repositorySeq
            , "imageId": $scope.imageId
            , "imageTypeCd": $scope.imageTypeCd
        };
    };

    // 更新データ編集
    $scope.editUpdateData = function() {
        return $scope.editRegisterData();
    };

    // onload処理
    $scope.setParams();
    $scope.initForm();
    $scope.initDisp();
});
