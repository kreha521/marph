angular.module('angularprjApp')
    //実行確認用コントローラー
    .controller('ConfirmController',
       function($scope, $uibModalInstance, params){
           $scope.title = params.title;
           $scope.message = params.message;
           $scope.pressClose = function(){
               $uibModalInstance.close('done');
           };
           $scope.pressDismiss = function(){
               $uibModalInstance.dismiss('done');
           };
   });
