angular.module('angularprjApp')

.controller('imageCtrl', function($scope, $rootScope, $http, $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg) {
    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_LIST = AppCommonConf().nodeBaseUrl + '/images/get/_detail';

    // 画面遷移パラメータ設定
    $scope.setParams = function() {
        $scope.repositorySeq = Number($stateParams.repositorySeq);
    };

    // フォーム初期化
    $scope.initForm = function() {
        $scope.images = [];

        //ページング処理
        $scope.limit = 10;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // イメージ一覧情報表示設定
    $scope.setDispItem = function(data) {
        $scope.groupCd = data.groupCd
        $scope.groupName = data.groupName
        $scope.projectNo = data.repo.projectNo
        $scope.projectName = data.repo.projectName

        var images = data.images;
        if (!images) {
            return;
        }

        // 取得データを画面表示仕様に合わせて設定する
        for (var i=0; i<images.length; i++) {
            var image = {};
            image.updateCounter = images[i].updateCounter;
            image.imageId = images[i].imageId;
            image.imageTypeCd = images[i].imageTypeCd;

            $scope.images.push(image);
        }
    };

    // 一覧初期表示データ取得条件
    $scope.editDispImagesData = function() {
        return {
            "repositorySeq": $scope.repositorySeq
        };
    }

    // 画面初期表示
    $scope.initDisp = function() {
        // 初期表示データ取得
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_LIST,
            headers: {'Content-Type': 'application/json'},
            data: $scope.editDispImagesData()
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }

            $scope.setDispItem(data);
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };

    // ページ数取得
    $scope.range = function() {
        $scope.maxPage = Math.ceil($scope.images.length / $scope.itemsPerPage);
        var ret = [];
        for (var i=1; i<=$scope.maxPage; i++) {
            ret.push(i);
        }
        return ret;
    };

    // 対象ページのデータ取得設定
    $scope.page = function(page){
        $scope.begin = (page - 1) * $scope.limit;
    };

    // onload処理
    $scope.setParams();
    $scope.initForm();
    $scope.initDisp();
})

//明細用のコントローラー
.controller('imageListCtrl', function($scope, $rootScope, $http, $state, $uibModal, AppCommonConf, AppConf, Msg) {
    // 詳細ボタン押下処理
    $scope.show = function() {
        // イメージ情報登録画面
        $state.go('imageinfo', {
            projectNo: $scope.projectNo
            , repositorySeq: $scope.repositorySeq
            , imageId: $scope.image.imageId
        });
    };
})

;
