angular.module('angularprjApp')

    /* 環境稼働状況一覧のコントローラー */
    .controller('envListCtl', function( $scope, $rootScope, $http, $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:ヘッダー情報取得
    $scope.URL_GET_HEADER = AppCommonConf().nodeBaseUrl + '/envstats/get/_header';

    // URL:ヘッダー情報取得
    $scope.URL_GET_DETAIL = AppCommonConf().nodeBaseUrl + '/envstats/get/_detail';

    // 画面遷移パラメータ設定
    $scope.setParams = function() {
        $scope.envCd = $stateParams.envCd;
    };

    /* メニュー起動であるか判定 */
    $scope.isMenuRoute = function() {
        return !$scope.envCd;
    };

    //案件セレクトボックス変更時
    $scope.selectChange = function() {
//        $scope.setDummyData();
        //nodeの稼働状況取得をコールしデータを表示する。
        $scope.detailDisp();
    };

    //案件セレクトボックス変更時
    $scope.detailDisp = function() {
        //nodeの稼働状況取得をコールしデータを表示する。
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_DETAIL,
            headers: {'Content-Type': 'application/json'},
            data: {"envCd": $scope.selectEnvCd.cd}
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.setDispItem(data);
            if (funcOnSuccess) {
                // 正常終了時に実行する関数の指定がある場合は実行する
                funcOnSuccess();
            }

        }).error(function(data, status, headers, config) {
            onServerError($state, data);
            return;
        });
    };

    // 稼働状況一覧情報表示設定
    $scope.setDispItem = function(data) {
        $scope.imageSetData = data;
    };

    //　ダミーデータ設定
    $scope.setDummyData = function(index) {
        //ダミーデータ
        $scope.imageSetData = [
        {
             seriesCd:'A',
             seriesName:'A環境',
             imagesetName:'ニッセイ販売支援外貨商品追加対応・IT前',
             state:'稼働中',
             repositorySeq:3,
             imagesetSeq:1,
             containerData:[
                {
                    serverTypeCd:'1',
                    avilableFlg:true,
                    ipAddress:'192.168.0.11',
                    exeOrder:'2',
                },
                {
                    serverTypeCd:'2',
                    avilableFlg:true,
                    ipAddress:'192.168.0.21',
                    exeOrder:'1',
                },
                {
                    serverTypeCd:'3',
                    avilableFlg:true,
                    ipAddress:'192.168.0.31',
                    exeOrder:'3',
                },
                {
                    serverTypeCd:'4',
                    avilableFlg:false,
                    ipAddress:'192.168.0.31',
                    exeOrder:'4',
                }
            ],
             datechangeFlg:true,
             importFlg:true
        },
        {
             seriesCd:'B',
             seriesName:'B環境',
             imagesetName:'ニッセイ販売支援外貨商品追加対応・ST前',
             state:'未使用',
             repositorySeq:3,
             imagesetSeq:1,
             containerData:[
                {
                    serverTypeCd:'1',
                    avilableFlg:true,
                    ipAddress:'192.168.0.11',
                    exeOrder:'2',
                },
                {
                    serverTypeCd:'2',
                    serverTypeCd:2,
                    avilableFlg:true,
                    ipAddress:'192.168.0.21',
                    exeOrder:'1',
                },
                {
                    serverTypeCd:'3',
                    serverTypeCd:3,
                    avilableFlg:false,
                    ipAddress:'',
                    exeOrder:'3',
                },
                {
                    serverTypeCd:'4',
                    serverTypeCd:4,
                    avilableFlg:true,
                    ipAddress:'12.168.0.41',
                    exeOrder:'4',
                }
            ],
             datechangeFlg:false,
             importFlg:false
        },
        {
             seriesCd:'C',
             seriesName:'C環境',
             imagesetName:'ニッセイ販売支援外貨商品追加対応・IT前',
             state:'稼働中',
             repositorySeq:3,
             imagesetSeq:1,
             containerData:[
                {
                    serverTypeCd:'1',
                    avilableFlg:true,
                    ipAddress:'192.168.0.11',
                    exeOrder:'2',
                },
                {
                    serverTypeCd:'2',
                    avilableFlg:true,
                    ipAddress:'192.168.0.21',
                    exeOrder:'1',
                },
                {
                    serverTypeCd:'3',
                    avilableFlg:true,
                    ipAddress:'192.168.0.31',
                    exeOrder:'3',
                },
                {
                    serverTypeCd:'4',
                    avilableFlg:false,
                    ipAddress:'192.168.0.31',
                    exeOrder:'4',
                }
            ],
             datechangeFlg:true,
             importFlg:true
       }];
    };

    // フォーム初期化
    $scope.initForm = function() {
        $scope.tempImageSetId ='1234';
        $scope.groupName = "";
        $scope.serverTypeName= [];
        $scope.envCdSelectData = [];

        $scope.workstat ="panel-primary";

    };

    //初期表示処理
    $scope.initDisp = function() {

        $rootScope.myPromise = $http({
            method: 'POST',
            url: $scope.URL_GET_HEADER,
        }).success(function(data, status, headers, config) {
            //領域名称
            $scope.groupName = data.groupName;

            //環境のリストボックス
            $scope.envCdSelectData = data.envCds;

            if(!$scope.isMenuRoute()){
                //メニューから起動でない場合はパラメータの環境コードを選択
                for(var i=0;i<$scope.envCdSelectData.length;i++){
                    if($scope.envCdSelectData[i].cd == $scope.envCd){
                        $scope.selectEnvCd = $scope.envCdSelectData[i];
                        break;
                    }
                }
            }

            //表の列見出しの表示
            $scope.serverTypeName = data.serverTypeName;

            //選択処理実行
            $scope.selectChange();

        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    }


    // onload処理
    $scope.setParams();
    $scope.initForm();
    $scope.initDisp();
})


    /* 環境稼働状況一覧のコントローラー */
    .controller('envDetailCtl', function( $scope, $rootScope, $http, $uibModal, $state, AppCommonConf, AppConf, Msg) {

    $scope.make= function() {
        // 環境登録画面表示要求
        $state.go('imageset',{envCd:$scope.selectEnvCd.cd,
                              seriesCd:$scope.imdata.seriesCd,
                              repositorySeq:$scope.imdata.repositorySeq,
                              imagesetSeq:$scope.imdata.imagesetSeq
                             });
    };

    // 環境保存ボタン押下時処理
    $scope.save = function() {
        // 環境保存画面表示要求
        $state.go('envsave',{
                              processCategory:"0",
                              envCd:$scope.selectEnvCd.cd,
                              seriesCd:$scope.imdata.seriesCd,
                              repositorySeq:$scope.imdata.repositorySeq,
                             });
    };

    // 復元完了ボタン押下時処理
    $scope.restore = function() {
        // 環境保存画面表示要求
        $state.go('envsave',{
                              processCategory:"1",
                              envCd:$scope.selectEnvCd.cd,
                              seriesCd:$scope.imdata.seriesCd,
                              repositorySeq:$scope.imdata.repositorySeq,
                             });
    };

    // 案件完了ボタン押下時処理
    $scope.finish = function() {
        // 環境保存画面表示要求
        $state.go('envsave',{
                              processCategory:"1",
                              envCd:$scope.selectEnvCd.cd,
                              seriesCd:$scope.imdata.seriesCd,
                              repositorySeq:$scope.imdata.repositorySeq,
                             });
    };

    $scope.delete = function() {
        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'環境削除確認',
                        message: $scope.imdata.seriesName + "の環境の削除を実行します。よろしいですか？"
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                //                    $http.OKpost(
                //                        '/deletegroup',
                //                        fd,
                //                        {
                //                            transformRequest: null,
                //                            headers: {'Content-type':undefined}
                //                        }
                //                    )
                //                    .success(function (response) {
                //                    });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // 一時保存（変更前)押下時処理
    $scope.tempChange= function() {
        alert("tempChange");
    };

    // 保存復元（変更前)押下時処理
    $scope.restoreChange= function() {
        alert("tempChange");
    };

    // 一時保存（検証前)押下時処理
    $scope.tempVerify= function() {
        alert("tempVerify");
    };

    // 保存復元（変更前)押下時処理
    $scope.restoreVerify= function() {
        alert("restoreVerify");
    };


    // 業務日付変更ボタン押下時処理
    $scope.changeDate = function() {
        // 業務日付変更画面表示要求
        var modalInstance = $uibModal.open({
            templateUrl: 'views/opedatemodify.html',
            controller: 'opedateCtl',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'業務日付変更'
                    };
                }
            }
        });

        //チェックが１つでもあれば、POSTする。
        //レスポンスをモデルに設定
        modalInstance.result.then(

            // 受け取ったらリフレッシュする
            //                //登録押下
            //                function(result){
            //                    $http.post(
            //                        '/deleteimagedata',
            //                        fd,
            //                        {
            //                            transformRequest: null,
            //                            headers: {'Content-type':undefined}
            //                        }
            //                    )
            //                        .success(function (response) {
            //                        $scope.imageData = response;
            //                    });
            //                },
            //                //キャンセル押下
            //                function(){
            //                }
        );
    };

    // データインポートボタン押下時処理
    $scope.dataImport = function() {
        // データインポート画面表示要求
        //TODO 対象のコンテナがわかる情報をstateparamsで渡す必要がある
        $state.go('tableImport',{envCd:$scope.selectEnvCd.cd,
          seriesCd:$scope.imdata.seriesCd
         });
    };

});
