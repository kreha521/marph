angular.module('angularprjApp')

/* 領域登録のコントローラー */
    .controller('orgRegisterCtrl', function($scope, $rootScope, $http, $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示（編集）
    $scope.URL_GET_EDIT = AppCommonConf().nodeBaseUrl + '/organizations/get/_edit';
    // URL:登録
    $scope.URL_ADD = AppCommonConf().nodeBaseUrl + '/organizations/add';
    // URL:更新
    $scope.URL_UPD = AppCommonConf().nodeBaseUrl + '/organizations/upd';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/organizations/del';

    /* 画面遷移パラメータ設定 */
    $scope.setParam = function() {
        $scope.orgCd = $stateParams.orgCd;
    };

    // フォーム初期化
    $scope.initForm = function() {
        $scope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // 初期表示モード判定
    $scope.isNewEdit = function() {
        return !$scope.orgCd;
    };

    // 画面初期表示
    $scope.initDisp = function() {
        //一覧から詳細で遷移の場合のみデータを表示
        if (!$scope.isNewEdit()) {
            $rootScope.myPromise = $http({
                method: 'POST',
                url : $scope.URL_GET_EDIT,
                headers: {'Content-Type': 'application/json'},
                data: {"orgCd": $scope.orgCd}
            }).success(function(data, status, headers, config) {
                setServerMsgs($rootScope, data);
                if (hasServerAppError($rootScope)) {
                    // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                    $rootScope.isShowableMsgArea = true;
                    return;
                }

                // 組織情報表示設定
                $scope.setOrgDispItem(data);
            }).error(function(data, status, headers, config) {
                onServerError($state, data);
            });
        }
    };

    // 組織情報表示設定
    $scope.setOrgDispItem = function(org) {
        $scope.updateCounter = org.updateCounter;
        $scope.orgCd = org.orgCd;
        $scope.orgName = org.orgName;
    };

    // 登録データ編集
    $scope.editRegisterData = function() {
        var org = {
            "tblOrganization":{
                "updateCounter": $scope.updateCounter
                , "orgCd":$scope.orgCd
                , "orgName":$scope.orgName
            }
        };

        return org;
    };

    // 更新データ編集
    $scope.editUpdateData = function() {
        return $scope.editRegisterData();
    };

    // 入力チェック結果を取得
    $scope.isInvalidForm = function() {
        var isInvalid = $scope.orgRegisterForm.$invalid;
        return isInvalid;
    };

    // 組織登録
    $scope.register = function() {
        $scope.isShowableMsgArea = true;

        // 実行確認
        if ($scope.isInvalidForm()) {
            // 入力チェックエラーの場合、処理しない
            return;
        }

        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'組織登録確認',
                        message: $scope.isNewEdit() ? Msg('MSG0015', '組織情報の登録') : Msg('MSG0015', '組織情報の更新')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下(新規)
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.isNewEdit() ? $scope.URL_ADD : $scope.URL_UPD,
                    headers: { 'Content-Type': 'application/json' },
                    data: $scope.isNewEdit() ? $scope.editRegisterData() : $scope.editUpdateData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    if ($scope.isNewEdit()) {
                        alert(Msg('MSG0010'));
                    } else {
                        alert(Msg('MSG0019'));
                    }
                    // 組織一覧画面
                    $state.go('organizationList')
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },
            //キャンセル押下
            function(){
            }
        );
    };

    // 削除データ編集
    $scope.editDeleteData = function() {
        var org = {
            "updateCounter": $scope.updateCounter
            , "orgCd":$scope.orgCd
        };
        return org;
    };

    // 組織削除
    $scope.delete = function() {
        $scope.isShowableMsgArea = false;

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'組織情報削除確認',
                        message: "組織情報の削除を実行します。よろしいですか？"
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_DEL,
                    headers: {'Content-Type': 'application/json'},
                    data: $scope.editDeleteData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    alert(Msg('MSG0011'));
                    // 組織一覧画面
                    $state.go('organizationList');
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // 画面遷移パラメータ設定
    $scope.setParam();
    $scope.initForm();
    $scope.initDisp();
});
