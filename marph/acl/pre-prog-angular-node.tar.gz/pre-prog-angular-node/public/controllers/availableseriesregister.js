angular.module('angularprjApp')

/* 利用可能系列情報登録のコントローラー */
.controller('availableSeriesRegisterCtrl', function($scope, $rootScope, $http, $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg) {
    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示（新規）
    $scope.URL_GET_NEW_EDIT = AppCommonConf().nodeBaseUrl + '/availableseries/get/_new';
    // URL:初期表示（編集）
    $scope.URL_GET_EDIT = AppCommonConf().nodeBaseUrl + '/availableseries/get/_edit';
    // URL:登録
    $scope.URL_ADD = AppCommonConf().nodeBaseUrl + '/availableseries/add';
    // URL:更新
    $scope.URL_UPD = AppCommonConf().nodeBaseUrl + '/availableseries/upd';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/availableseries/delete';

    // 画面遷移パラメータ設定
    $scope.setParams = function() {
        $scope.envCd = $stateParams.envCd;
        $scope.seriesCd = $stateParams.seriesCd;
    };

    // フォーム初期化
    $scope.initForm = function() {
        $rootScope.isShowableMsgArea = false;

        // 選択リスト
        $scope.envCds = [];

        // 利用可能コンテナ一覧
        $scope.availableContainers = [];
        $scope.showAvailableContainers = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // 画面初期表示
    $scope.initDisp = function(isNewEdit) {
        if (!isNewEdit) {
            $scope.dispAvailableSeriesItem();
        } else {
            $scope.setItemsNewEdit()
        }
    };

    // 初期表示モード判定
    $scope.isNewEdit = function() {
        return !$stateParams.envCd || !$stateParams.seriesCd
    };

    // 入力チェック結果を取得
    $scope.isInvalidForm = function() {
        return $scope.availableSeries.$invalid;
    };

    // 利用可能系列情報表示設定
    $scope.setAvailableSeriesDispItem = function(availableseries, availableContainers) {
        $scope.updateCounter = availableseries.updateCounter;
        $scope.groupCd = availableseries.groupCd;
        $scope.envCd = availableseries.envCd;
        $scope.seriesCd = availableseries.seriesCd;
        $scope.seriesName = availableseries.seriesName;
        if (availableContainers && availableContainers.length > 0) {
            $scope.additionalParam = availableContainers[0].additionalParam;
        }
        $scope.statusCd = availableseries.statusCd;
    };

    // 利用可能コンテナ一覧情報表示設定
    $scope.setAvailableContainerDispItem = function(availableContainers) {
        for (var i=0; i<availableContainers.length; i++) {
            if (!availableContainers[i].portForwardInfo) {
                continue;
            }
            availableContainers[i].portForwardInfo = toStringPortForwardInfo(JSON.parse(availableContainers[i].portForwardInfo));
        }
        $scope.availableContainers = availableContainers
    };

    // 参照モード判定
    $scope.isReadOnlyMode = function() {
        return ($scope.statusCd == '1');
    };

    // 利用可能系列情報表示情報取得データ編集
    $scope.editDispAvailableSeriesData = function() {
        return {
            "envCd": $scope.envCd
            , "seriesCd": $scope.seriesCd
        }
    };

    // 新規登録時データ取得
    $scope.setItemsNewEdit = function() {
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_NEW_EDIT,
            headers: {'Content-Type': 'application/json'},
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }

            $scope.groupCd = data.groupCd;
            $scope.groupName = data.groupName;
            $scope.setEnvCds(data.envCds);
            $scope.setContainerTypeCds(data.containerTypeCds);

            $scope.hasAvailableContainers(null);
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };

    // 利用可能系列情報表示情報取得
    $scope.dispAvailableSeriesItem = function() {
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_EDIT,
            headers: {'Content-Type': 'application/json'},
            data: $scope.editDispAvailableSeriesData()
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }

            $scope.groupCd = data.groupCd;
            $scope.groupName = data.groupName;

            $scope.setAvailableSeriesDispItem(data.availableSeries, data.availableContainers);
            $scope.setAvailableContainerDispItem(data.availableContainers);
            $scope.setEnvCds(data.envCds);
            $scope.setContainerTypeCds(data.containerTypeCds);

            $scope.hasAvailableContainers(data.availableContainers);
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };

    // 環境リストを詰める
    $scope.setEnvCds = function(envCds) {
        $scope.envCds = envCds;
    }

    // コンテナ種別を詰める
    $scope.setContainerTypeCds = function(containerTypeCds) {
        $scope.containerTypeCds = containerTypeCds;
    }

    // 登録
    $scope.register = function() {
        $scope.isShowableMsgArea = true;

        if ($scope.isInvalidForm()) {
            // 入力チェックエラーの場合、処理しない
            return;
        }

        var isNewEdit = $scope.isNewEdit();

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'利用可能系列情報登録確認',
                        message: isNewEdit ? Msg('MSG0015', '利用可能系列情報の登録') : Msg('MSG0015', '利用可能系列情報の更新')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : isNewEdit ? $scope.URL_ADD : $scope.URL_UPD,
                    headers: { 'Content-Type': 'application/json' },
                    data: isNewEdit ? $scope.editRegisterData() : $scope.editUpdateData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    if (isNewEdit) {
                        alert(Msg('MSG0010'));
                    } else {
                        alert(Msg('MSG0019'));
                    }
                    // 利用可能系列情報一覧画面
                    $state.go('availableseries');
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },
            //キャンセル押下
            function(){
            }
        );
    };

    // 登録データ編集
    $scope.editRegisterData = function() {
        var availableSeries = {
            "availableSeries":{
                "updateCounter": $scope.updateCounter
                , "orgCd": $scope.orgCd
                , "groupCd": $scope.groupCd
                , "envCd": $scope.envCd
                , "seriesCd": $scope.seriesCd
                , "seriesName": $scope.seriesName
                , "statusCd": '0'
            }
        };

        var availableContainers = [];
        for (var i=0; i<$scope.availableContainers.length; i++) {
            var availableContainer = {
                "updateCounter": $scope.availableContainers[i].updateCounter
                , "containerTypeCd": $scope.availableContainers[i].containerTypeCd
                , "containerTypeName": $scope.availableContainers[i].containerTypeName
                , "ipAddress": $scope.availableContainers[i].ipAddress
                , "hostname": $scope.availableContainers[i].hostname
                , "additionalParam": $scope.additionalParam
                , "portForwardInfo": JSON.stringify(toPortForwardsFromString($scope.availableContainers[i].portForwardInfo))
            };
            availableContainers.push(availableContainer);
        }
        availableSeries.availableContainers = availableContainers;

        return availableSeries;
    };

    // 更新データ編集
    $scope.editUpdateData = function() {
        var data = $scope.editRegisterData();
        data.statusCd = $scope.statusCd;
        return data;
    };

    // 削除リクエストデータ編集
    $scope.editDeleteData = function() {
        return {
            "updateCounter": $scope.updateCounter
            , "envCd": $scope.envCd
            , "seriesCd": $scope.seriesCd
        };
    };

    // 削除
    $scope.delete = function() {
        $scope.isShowableMsgArea = false;

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'利用可能系列情報削除確認',
                        message: Msg('MSG0015', '利用可能系列情報の削除')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_DEL,
                    headers: {'Content-Type': 'application/json'},
                    data: $scope.editDeleteData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    alert(Msg('MSG0011'));
                    // 利用可能系列情報一覧画面
                    $state.go('availableseries');
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // 利用可能コンテナ追加モード設定
    $scope.hasAvailableContainers = function(availableContainers) {
        $scope.showAvailableContainers = (Array.isArray(availableContainers) && availableContainers.length > 0);
        return $scope.showAvailableContainers;
    }

    // onload処理
    $scope.setParams();
    $scope.initForm();
    var isNewEdit = $scope.isNewEdit();
    $scope.initDisp(isNewEdit);
})

/* コンテナ明細部用のコントローラー */
.controller('availableContainerListCtrl', function($scope, $rootScope, $uibModal) {
    // 追加ボタン押下時
    $scope.addAvailableContainer = function() {
        var availableContainer = {
            "containerTypeCd": $scope.containerTypeCd
            , "containerTypeName": $scope.containerTypeName
            , "hostname": $scope.hostname
            , "ipAddress": $scope.ipAddress
        };
        $scope.availableContainers.push(availableContainer);
        $scope.hasAvailableContainers($scope.availableContainers);
    };

    // 詳細ボタン押下処理
    $scope.showAvailableContainer = function(i) {
        var availableContainer = $scope.availableContainers[i];

        var modalInstance = $uibModal.open({
            templateUrl: 'views/containerinfoselect.html',
            controller: 'containerinfoCtrl',
            backdrop: true,
            scope: $scope,
            size: 'lg',
            resolve: {
                params:function(){
                    return {
                        "containerTypeCd": availableContainer.containerTypeCd
                        , "containerTypeName": availableContainer.containerTypeName
                        , "hostname": availableContainer.hostname
                        , "ipAddress": availableContainer.ipAddress
                        , "portForwardInfo": availableContainer.portForwardInfo
                    };
                }
            }
        });

        modalInstance.result.then(
            //OK押下
            function(result){
                availableContainer.portForwardInfo = result;
            }
        );
    };

    // 削除ボタン押下時
    $scope.delAvailableContainer = function(i) {
        $scope.availableContainers.splice(i, 1);
    };
})

// 稼働状況フィルター
.filter('status', function() {
    return function(statusCd, isNewEdit){
        if (statusCd == '1') {
            return "稼働中";
        }
        return isNewEdit ? "" : "未稼働";
    };
})

;
