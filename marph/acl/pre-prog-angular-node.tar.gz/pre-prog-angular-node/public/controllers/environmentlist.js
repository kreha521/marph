angular.module('angularprjApp')

    .controller('envCtl', function( $scope, $rootScope, $http,  $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_DETAIL = AppCommonConf().nodeBaseUrl + '/envs/get/_detail';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/envs/del';

    // 画面初期化処理
    $scope.initForm = function(funcOnSuccess) {
        $scope.envlistData = [];

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    }

    // 初期表示処理
    $scope.initDisp = function(funcOnSuccess) {
        // 初期表示データ取得
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_DETAIL,
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.setDispItem(data);
            if (funcOnSuccess) {
                // 正常終了時に実行する関数の指定がある場合は実行する
                funcOnSuccess();
            }

        }).error(function(data, status, headers, config) {
            onServerError($state, data);
            return;
        });
    };

    // 環境一覧情報表示設定
    $scope.setDispItem = function(envs) {
        $scope.envlistData = [];
        // JSONのデータを画面表示仕様に合わせて設定する
        for (var i=0; i<envs.envList.length; i++) {
            var wkgroup = new Object();
            wkgroup.orgCd = envs.envList[i].orgCd;
            wkgroup.groupCd = envs.envList[i].groupCd;
            wkgroup.envCd = envs.envList[i].envCd;
            wkgroup.envCdName = envs.envList[i].envCdName;
            wkgroup.envName = envs.envList[i].envName;
            wkgroup.updateCounter = envs.envList[i].updateCounter;
            $scope.envlistData.push(wkgroup);
        }

        $scope.orgCd = envs.orgCd;
        $scope.groupCd = envs.groupCd;
        $scope.groupName = envs.groupShortCd + "：" +envs.groupName
    };

    // 追加ボタン押下時処理
    $scope.add = function() {
        // ユーザー詳細登録画面表示要求
        $state.go('envregister', {
            groupCd: $scope.groupCd, orgCd: $scope.orgCd
        });
    };

    $scope.initForm();
    $scope.initDisp();

})

//明細用のコントローラー
    .controller('envDetailCtl', function($scope, $rootScope, $http, $state, $uibModal, AppCommonConf, AppConf, Msg) {

    // 詳細ボタン押下処理
    $scope.show = function() {
        $state.go('envregister', {
            orgCd: $scope.envdata.orgCd, groupCd: $scope.envdata.groupCd, envCd: $scope.envdata.envCd
        });
    };

    // 環境削除
    $scope.delete = function() {
        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'環境削除確認',
                        message: Msg('MSG0015', '環境[' + $scope.envdata.envCd + ':' + $scope.envdata.envName + ']の削除')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_DEL,
                    headers: { 'Content-Type': 'application/json' },
                    data: {"orgCd":$scope.envdata.orgCd, "groupCd":$scope.envdata.groupCd, "envCd":$scope.envdata.envCd,"updateCounter":$scope.envdata.updateCounter}
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }
                    $scope.initDisp($rootScope.showMsgDeleteSuccess);
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // 削除完了メッセージ表示
    $rootScope.showMsgDeleteSuccess = function() {
        alert(Msg('MSG0011'));
    };

});
