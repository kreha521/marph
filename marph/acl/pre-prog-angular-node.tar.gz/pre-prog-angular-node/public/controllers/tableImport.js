angular.module('angularprjApp')

    .controller('tableImportCtl', function($scope, $rootScope, $http, $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg , Upload) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET = AppCommonConf().nodeBaseUrl + '/tableimport/get';
    // URL:テーブルインポート実行
    $scope.URL_ADD = AppCommonConf().nodeBaseUrl + '/tableimport/add';

    // ファイル一覧削除
    $scope.delete = function(num) {
        $scope.filelist.splice(num, 1);
    };
    $scope.isErr = function(logdata) {
//        if(logdata.code=="SQL3260N") {
//            return "text-danger"
//        }
    };

// データインポート先コンテナ情報取得
    $scope.initDisp = function(funcOnSuccess) {
        // 初期表示データ取得
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET,
            headers: {'Content-Type': 'application/json'},
            data: $scope.editData()
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.setDispItem(data);
            if (funcOnSuccess) {
                // 正常終了時に実行する関数の指定がある場合は実行する
                funcOnSuccess();
            }
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };

     // リクエストデータ編集
    $scope.editData = function() {
        var Keys = {
            "envCd": $stateParams.envCd
            , "seriesCd": $stateParams.seriesCd
        };
        return Keys;
    };

    // コンテナ情報表示設定
    $scope.setDispItem = function(data) {
        $scope.containerData = data.containerData

        $scope.groupName = data.groupName
        $scope.envCode = data.containerData.envCd
        $scope.seriesName = data.containerData.seriesName
    };


    //ファイル選択
    $scope.onfileSelct = function(files) {
        for( var i = 0;i<files.length;i++) {
            filelist.push({fileName:$files});
            console.log(files[i]);
        }
    }

    // 実行確認
    $scope.exec = function() {
        var fd = new FormData();

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'テーブルインポート実行確認',
                        message: "テーブルインポートを実行します。よろしいですか？"
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $scope.uploadFile($scope.filelist);
            },
            //キャンセル押下
            function(){
            }
        );
    };

    // nodeにファイルアップロード
//    $scope.uploadFile = function(files) {
//        var fd = new FormData();
//        fd.append("file", files[0]);
//        fd.append("storage_type", 1);
//        console.log(fd);
//        $http.post($scope.URL_ADD, fd,
//            {   headers: {'Content-Type': undefined },
//                transformRequest: angular.identity
//            }).
//            success(function(data, status, headers, config) {
//                console.log(data);
//                console.log(status);
//                console.log(headers());
//            }).
//            error(function(data, status, headers, config) {
//                console.log("いったけど落ちた");
//            });
//    };

      // angular-fileuploadを使う場合
      $scope.uploadFile = function(files) {
        Upload.upload({
          url: $scope.URL_ADD,
          file: files[0]
        });
      };

    // onload処理
    $scope.initDisp();
});

app.directive('ngFileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var model = $parse(attrs.ngFileModel);
            var isMultiple = attrs.multiple;
            var modelSetter = model.assign;
            element.bind('change', function () {
                var values = [];
                angular.forEach(element[0].files, function (item) {
                    var value = {
                        // File Name
                        fileName: item.name
                    };
                    values.push(value);
                });
                scope.$apply(function () {
                    if (isMultiple) {
                        modelSetter(scope, values);
                    } else {
                        modelSetter(scope, values[0]);
                    }
                });
            });
        }
    };
}]);
