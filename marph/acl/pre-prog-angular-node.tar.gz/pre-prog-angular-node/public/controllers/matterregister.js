angular.module('angularprjApp')

    .controller('matterregCtl', function( $scope, $rootScope, $http, $location, $uibModal, $state, $stateParams, Msg, AppCommonConf) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示（新規）
    $scope.URL_GET_NEW_EDIT = AppCommonConf().nodeBaseUrl + '/projects/get/_new';
    // URL:初期表示（編集）
    $scope.URL_GET_EDIT = AppCommonConf().nodeBaseUrl + '/projects/get/_edit';
    // URL:登録
    $scope.URL_ADD = AppCommonConf().nodeBaseUrl + '/projects/add';
    // URL:更新
    $scope.URL_UPD = AppCommonConf().nodeBaseUrl + '/projects/upd';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/projects/delete';

      // フォーム初期化
    $scope.initForm = function() {
        $scope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };



    // 画面初期表示
    $scope.initDisp = function(isNewEdit) {
        if (!isNewEdit) {
            $scope.dispProjectItem();
        } else {
            $scope.dispProjectNewItem();
        }
    };

    // 初期表示モード判定
    $scope.isNewEdit = function() {

        var isNewEdit = false
        if (!$stateParams.repositorySeq) {
            isNewEdit = true
        }
        return isNewEdit
    };

    // 入力チェック結果を取得
    $scope.isInvalidForm = function() {
        return $scope.matters.$invalid;
    };

     // 初期表示データ取得＜新規＞
    $scope.dispProjectNewItem = function() {
        $scope.getProject = $http({
            method: 'POST',
            url : $scope.URL_GET_NEW_EDIT
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }

            $scope.setItems(data)

        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };


     // 初期表示データ取得＜編集＞
    $scope.dispProjectItem = function() {
        $scope.getProject = $http({
            method: 'POST',
            url : $scope.URL_GET_EDIT,
            headers: { 'Content-Type': 'application/json' },
            data: $scope.editParamData()
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }

            $scope.setItems(data)

        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };

    // リクエストデータ編集
    $scope.editParamData = function() {
        var projectParam = {
            "orgCd":$stateParams.orgCd,
            "groupCd":$stateParams.groupCd,
            "repositorySeq":$stateParams.repositorySeq
        };
        return projectParam;
    };



    // 初期表示設定
    $scope.setItems = function(data) {
        $scope.projectdata = data;

        $scope.groupCd =  data.groupCd;
        $scope.groupName =  data.groupName;
        $scope.projectNo = data.projectNo;
        $scope.projectName = data.projectName;

        // 案件完了日
        if(!data.completionDate){
            $scope.enddate = new Date();
        }else{
            var date = data.completionDate
            var year = date.substr(0,4).toString();
                // 月を修正(-1月する)
            var month = (Number(date.substr(4,2)) - 1).toString();
            var day = date.substr(6).toString();
            $scope.enddate = new Date(year,month,day);
            }


        $scope.datePickerOpen = false;
        $scope.toggleDatePicker = function($event) {
            $event.stopPropagation();
            $scope.datePickerOpen = !$scope.datePickerOpen;
        };
        // 案件完了表示
        $scope.exitflag = data.completeFlgData;

        // 新規追加の場合は連番0を指定しているので、非表示にする
        if(data.repositorySeq != 0){
             $scope.reponum = data.repositorySeq;
        };
    };


    // 登録
    // JSONに入力データをまとめて、引数に持たせる
    $scope.register = function() {

         $scope.isShowableMsgArea = true;

        if ($scope.isInvalidForm()) {
            // 入力チェックエラーの場合、処理しない
            return;
        }

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'案件情報登録確認',
                        message: Msg('MSG0015', '案件情報の登録')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                if (!isNewEdit){
                    // 入力案件データ更新
                        $rootScope.myPromise = $http({
                            method: 'POST',
                            url : $scope.URL_UPD,
                            headers: { 'Content-Type': 'application/json' },
                            data: $scope.editRegisterData($scope.projectdata)
                        }).success(function(data, status, headers, config) {
                            setServerMsgs($rootScope, data);
                            if (hasServerAppError($rootScope)) {
                                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                                $rootScope.isShowableMsgArea = true;
                                return;
                            }
                            //案件更新完了メッセージ(MSG0010)を表示
                            alert(Msg('MSG0010'));
                            // 案件一覧画面へ遷移
                            $state.go('matter');
                        }).error(function(data, status, headers, config) {
                            onServerError($state, data);
                        });

                }else{
                    // 入力案件データ登録
                        $rootScope.myPromise = $http({
                            method: 'POST',
                            url : $scope.URL_ADD,
                            headers: { 'Content-Type': 'application/json' },
                            data: $scope.editRegisterData($scope.projectdata)
                        }).success(function(data, status, headers, config) {
                            setServerMsgs($rootScope, data);
                            if (hasServerAppError($rootScope)) {
                                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                                $rootScope.isShowableMsgArea = true;
                                return;
                            }
                            //案件更新完了メッセージ(MSG0010)を表示
                            alert(Msg('MSG0010'));
                            // 案件一覧画面へ遷移
                            $state.go('matter');
                        }).error(function(data, status, headers, config) {
                            onServerError($state, data);
                        });
                }
            },
            //キャンセル押下
            function(){
            }
        );
    };

    // 登録データ編集
    $scope.editRegisterData = function(data) {
        data.projectNo = $scope.projectNo,
        data.projectName = $scope.projectName,

        //完了日を編集
        date = $scope.enddate;

        var dateString
        if(!date){
            dateString = ""
        }else{
            var month = (date.getMonth() + 1).toString();
            month = month.length == 1 ? '0'+month : month;
            var day = date.getDate().toString();
            day = day.length == 1 ? '0' + day : day;
            dateString = date.getFullYear().toString() + month + day;
        }

        data.completionDate = dateString;

        return data;
    };



    // 削除
    $scope.datadel = function() {

         $scope.isShowableMsgArea = false;

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'案件情報削除確認',
                        message: "案件情報の削除を実行します。よろしいですか？"
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
              $rootScope.myPromise = $http({
                        method: 'POST',
                        url : $scope.URL_DEL,
                        headers: { 'Content-Type': 'application/json' },
                        data: $scope.editRegisterData($scope.projectdata)
                    }).success(function(data, status, headers, config) {
                        //案件削除完了メッセージ(MSG0011)を表示
                        alert(Msg('MSG0011'));
                        // 案件一覧画面へ遷移
                        $location.path('/matter')
                    }).error(function(data, status, headers, config) {
                        onServerError($state, data);
                    });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // onload処理
    $scope.initForm();
    var isNewEdit = $scope.isNewEdit();
    $scope.initDisp(isNewEdit);
})
