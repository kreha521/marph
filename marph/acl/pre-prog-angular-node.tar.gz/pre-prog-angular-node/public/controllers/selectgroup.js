angular.module('angularprjApp')

/* 領域選択のコントローラー */
.controller('SelectGroupCtrl', function($scope, $rootScope, $http, $location, $state, $uibModal) {
    // TODO nodeのurlは他のソースに習い$Scope.URL_XXXXX の定数を設定。合わせてSSも修正する。

    //TODO APIがSUCCESS時にサーバエラーがあるかをチェックし、あったら画面に表示する。

    // 初期表示データ取得
    $rootScope.myPromise = $http({
        method: 'POST',
        url : '/group/get/_list',
    }).success(function(data, status, headers, config) {
        console.log(data);
        //sessionStorageから特権フラグを取得する
        var flg = JSON.parse(sessionStorage.getItem('USERINFO')).priviledgeFlg;
        $scope.privilegeFlg = (flg == 1);
        $scope.groups =data;

    }).error(function(data, status, headers, config) {
        console.log("err");
        onServerError($state, data);
        return;
    });

    $scope.select = function(selectedGroup) {
        //TODO 入力チェックエラー時は遷移させない無理やりな暫定ロジック。
        if ($scope.group.$invalid) {
            return;
        }
       $rootScope.myPromise = $http({
            method: 'POST',
            url : '/group/select',
            data : selectedGroup
       }).success(function(data, status, headers, config) {
        // ログイン後初期表示画面
        $location.path('/init')

        }).error(function(data, status, headers, config) {
            console.log("err");
            onServerError($state, data);
            return;
        });
    };
});
