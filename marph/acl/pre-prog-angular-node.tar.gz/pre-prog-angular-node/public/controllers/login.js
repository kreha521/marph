angular.module('angularprjApp')

/* 認証処理 */
.factory('AuthService', function($q, $timeout, $http, $rootScope){
    var _user = null;
    return {
        isLogged: function(){ return !!_user; },
        getUser: function(){ return _user; },
        login: function(userid, password){
            var deferred = $q.defer();
            $timeout(function(){
                if (userid != null && password != null) {
                    $rootScope.myPromise = $http({
                        method: 'POST',
                        url : '/login',
                        headers: {'Content-Type': 'application/json'},
                        data: {"userid": userid, "password": password}
                    }).success(function(data, status, headers, config) {
                        _user = {userid: data.userId};
                        sessionStorage.setItem('USERINFO', JSON.stringify(data));
                        deferred.resolve();
                    }).error(function(data, status, headers, config) {
                        deferred.reject();
                    });
                } else {
                    deferred.reject();
                }
            }, 500);
            return deferred.promise;
        },
        logout: function(){
            _user = null;
            return $q.all();
        }
    };
})

/* ログインのコントローラー */
.controller('LoginCtrl', function($http, $scope, $state, AuthService){
    /*▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ ダミーデータ設定 ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ */
    //TODO PG完了後削除する
    $scope.userid = "fugafuga";
    $scope.password = "Password01";
    /*▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲ ダミーデータ設定 ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲ */
$scope.longText="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaabbbbbbbbbbbbb";

    $scope.login = function(){
        $scope.disabled = true;
        AuthService.login($scope.userid, $scope.password)
            .then(function(){
            //仮パスワードフラグを取得
            var pwTempFlg = JSON.parse(sessionStorage.getItem('USERINFO')).pwTempFlg;
            if (pwTempFlg == '1') {//仮パスワードの場合、ユーザ登録画面へ遷移
                $state.go('userregister', {userId: $scope.userid});
            } else {//それ以外の場合
                $state.go('selectgroup');
            }
        }).catch(function(){
            $scope.alert = {msg: "Login failed"};
        }).finally(function(){
//            $scope.userid = null;
//            $scope.password = null;
            $scope.disabled = false;
        })
        ;
    };

    // onLoad処理
    loadAppConfig($http, $state);
    loadMsgConfig($http, $state);
})

// TODO この線でいきたいんだけど、F５更新した際に、AuthService.isLogged()で見てるサービス内のフラグが初期化されちゃって、未ログイン扱いとなり、
// ログイン画面に戻されてしまう。解決策はまだわからないので、いったんコメントアウトしつつ、残しておく

//// 未認証状態で他画面へアクセスしようとした場合、ログイン画面へ強制遷移させる
//.run(function ($rootScope, $state, AuthService) {
//    $rootScope.$on('$stateChangeStart', function(e, toState, toParams, fromState, fromParams) {
//        if (!AuthService.isLogged() && toState.name != 'root') {
//            $state.go('root');
//            e.preventDefault();
//        }
//    });
//})

;
