angular.module('angularprjApp')

    /* 系列情報登録画面のコントローラー */
    .controller('envsaveCtrl', function( $scope, $rootScope, $http, $state, $stateParams, $uibModal, AppCommonConf, AppConf, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_NEW = AppCommonConf().nodeBaseUrl + '/envsave/get/_new';

    // 画面遷移パラメータ設定
    $scope.setParam = function() {
        $scope.processCategory = $stateParams.processCategory ;
        $scope.envCe = $stateParams.envCd;
        $scope.seriesCd = $stateParams.seriesCd;
        $scope.repositorySeq = $stateParams.repositorySeq;
    };
    /* 案件完了であるか判定 */
    $scope.isFinish = function() {
        return ($stateParams.processCategory == "2")
    };

    /* フォーム初期化 */
    $scope.initForm = function() {
        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // 画面初期表示
    $scope.initDisp = function() {
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_NEW,
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.groupName = data.groupShortCd + "：" + data.groupName
            $scope.setRepositorySeqs(data.prdTypeCds);
            if($scope.repositorySeq){
                $scope.repositorySeq = $scope.repositorySeqs[0].cd
            }
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };

    // 案件セレクトボックスを詰める
    $scope.setRepositorySeqs = function(data) {
        for (var i = 0; i < data.length; i++) {
            var wkgroup = new Object();
            wkgroup.cd = data[i].repositorySeq;
            wkgroup.name = data[i].projectNo + "：" + data[i].projectName;
            $scope.repositorySeqs.push(wkgroup);
        }
    }

    // 系列登録
    $scope.envsave = function() {
        var fd = new FormData();

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'環境保存確認',
                        message: " 環境保存を実行します。よろしいですか？"
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
//                $http.post(
//                    '/seriesregister',
//                    fd,
//                    {
//                        transformRequest: null,
//                        headers: {'Content-type':undefined}
//                    }
//                )
//                .success(function (response) {
//                    // 系列一覧画面
                    $location.path('/envlist')
//                });
            },
            //キャンセル押下
            function(){
            }
        );
    };
});
