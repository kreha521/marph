angular.module('angularprjApp')

// 領域一覧のコントローラー
    .controller('groupCtrl', function($scope, $http, $rootScope, $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_DETAIL = AppCommonConf().nodeBaseUrl + '/groups/get/_detail';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/groups/del';

    /* フォーム初期化 */
    $scope.initForm = function() {


        // ページング処理
        $scope.limit = 10;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // フォーム初期化
    $scope.initDisp = function(funcOnSuccess) {
        // 初期表示データ取得
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_DETAIL,
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.setDispItem(data);
            if (funcOnSuccess) {
                // 正常終了時に実行する関数の指定がある場合は実行する
                funcOnSuccess();
            }
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
            return;
        });

    };

    // 領域一覧情報表示設定
    $scope.setDispItem = function(data) {
        $scope.groups= [];
        // JSONのデータを画面表示仕様に合わせて設定する
        for (var i=0; i<data.length; i++) {
            var wkgroup = new Object();
            wkgroup.updateCounter = data[i].grps.updateCounter;
            wkgroup.orgCd = data[i].orgs.orgCd;
            wkgroup.orgName = data[i].orgs.orgName;
            wkgroup.groupCd = data[i].grps.groupCd;
            wkgroup.groupName = data[i].grps.groupName;
            wkgroup.groupShortCd = data[i].grps.groupShortCd;
            wkgroup.logicalDelFlg = data[i].grps.logicalDelFlg;
            wkgroup.logicalDelFlgName = data[i].grps.logicalDelFlgName;
            $scope.groups.push(wkgroup);
        }
    };

    // 追加ボタン押下時処理
    $scope.add = function() {
        // 領域登録画面
        $state.go('groupregister');
    };

    // ページ数取得
    $scope.range = function() {
        $scope.maxPage = Math.ceil($scope.groups.length / $scope.itemsPerPage);
        var ret = [];
        for (var i=1; i<=$scope.maxPage; i++) {
            ret.push(i);
        }
        return ret;
    };

    // 対象ページのデータ取得設定
    $scope.page = function(page){
        $scope.begin = (page - 1) * $scope.limit;
    };

    // onload処理
    $scope.initForm();
    $scope.initDisp();
})

/* 領域一覧 明細部用のコントローラー */
.controller('groupListCtrl', function($scope, $state, $rootScope, $http, $uibModal, AppCommonConf, AppConf, Msg) {

    // 詳細ボタン押下処理
    $scope.show = function() {
        // 領域登録画面
        $state.go('groupregister', {
            orgCd: $scope.group.orgCd, groupCd: $scope.group.groupCd
        });
    };

    // 削除ボタン押下時処理
    $scope.delete = function() {
        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'領域削除確認',
                        message: "領域[" + $scope.group.groupShortCd + ":" + $scope.group.groupName + "]の削除を実行します。よろしいですか？"
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_DEL,
                    headers: { 'Content-Type': 'application/json' },
                    data: {"orgCd":$scope.group.orgCd, "groupCd":$scope.group.groupCd, "updateCounter":$scope.group.updateCounter }
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    $scope.initDisp($rootScope.showMsgDeleteSuccess);

                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // 削除完了メッセージ表示
    $rootScope.showMsgDeleteSuccess = function() {
        alert(Msg('MSG0011'));
    };
});
