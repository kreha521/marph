angular.module('angularprjApp')

    .controller('imagesetCtlList', function($scope, $rootScope, $http, $location, $state, $stateParams, $uibModal, AppCommonConf, AppConf, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_DETAIL = AppCommonConf().nodeBaseUrl + '/imagesets/get/_detail';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/imagesets/del';

    // 画面遷移パラメータ設定
    $scope.setParam = function() {
        $scope.envCd = $stateParams.envCd;
        $scope.seriesCd = $stateParams.seriesCd;
        $scope.repositorySeq = $stateParams.repositorySeq;
        $scope.imagesetSeq = $stateParams.imagesetSeq;
    };

    /* メニュー起動であるか判定 */
    $scope.isMenuRoute = function() {
        return !$scope.envCd || !$scope.seriesCd;
    };

    /* フォーム初期化 */
    $scope.initForm = function() {
        $scope.imagesetData = [];

        //ページング処理
        $scope.limit = 10;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // イメージセット一覧情報表示設定
    $scope.setDispItem = function(data) {
        $scope.imagesetData = [];
        // JSONのデータを画面表示仕様に合わせて設定する
        for (var i = 0; i < data.imagesets.length; i++) {
            var wkgroup = new Object();
            wkgroup.repositorySeq = data.imagesets[i].imgSet.repositorySeq;
            wkgroup.imagesetid = data.imagesets[i].imgSet.imagesetSeq;
            wkgroup.imagesetname = data.imagesets[i].imgSet.imagesetName;
            wkgroup.ankenno = data.imagesets[i].repoInf.projectNo;
            wkgroup.ankenname = data.imagesets[i].repoInf.projectName;
            wkgroup.updateCounter = data.imagesets[i].imgSet.updateCounter;
            $scope.imagesetData.push(wkgroup);
        }

        $scope.groupName = data.groupShortCd + "：" + data.groupName;
    };

    // イメージセット一覧データ取得
    $scope.initDisp = function(funcOnSuccess) {
        // 初期表示データ取得
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_DETAIL,
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.setDispItem(data);
            if (funcOnSuccess) {
                // 正常終了時に実行する関数の指定がある場合は実行する
                funcOnSuccess();
            }
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
            return;
        });
    };

    // ページ数取得
    $scope.range = function() {
        $scope.maxPage = Math.ceil($scope.imagesetData.length/$scope.itemsPerPage);
        var ret = [];
        for (var i=1; i<=$scope.maxPage; i++) {
            ret.push(i);
        }
        return ret;
    };

    // 対象ページのデータ取得設定
    $scope.page = function(page){
        $scope.begin = (page - 1) * $scope.limit;
    }

    // 追加ボタン押下
    $scope.add = function() {
        $state.go('imagesetregister', {
             envCd: $scope.envCd,
             seriesCd: $scope.seriesCd
        });
    }

    // onload処理
    $scope.setParam();
    $scope.initForm();
    $scope.initDisp();

})

.controller('imagesetDetailList', function($scope, $rootScope, $http, $state, $location, $uibModal, AppCommonConf, AppConf, Msg) {

    // 詳細ボタン押下
    $scope.edit = function() {
        $state.go('imagesetregister', {
             envCd: $scope.envCd,
             seriesCd: $scope.seriesCd,
             repositorySeq: $scope.data.repositorySeq, imagesetSeq: $scope.data.imagesetid
        });
    }

    // 環境作成ボタン押下
    $scope.env = function() {
        $state.go('envmake', {
             envCd: $scope.envCd,
             seriesCd: $scope.seriesCd,
             repositorySeq: $scope.data.repositorySeq, imagesetSeq: $scope.data.imagesetid
        });
    }

    // 削除ボタン押下時処理
    $scope.delete = function() {
        $rootScope.isShowableMsgArea = false;

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'イメージセット削除確認',
                        message: Msg('MSG0015', 'イメージセット[' + $scope.data.imagesetid+ ':' + $scope.data.imagesetname + ']の削除')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_DEL,
                    headers: { 'Content-Type': 'application/json' },
                    data: {"repositorySeq":$scope.data.repositorySeq, "imagesetSeq": $scope.data.imagesetid, "updateCounter":$scope.data.updateCounter}
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }
                    // イメージセット一覧を再表示
                    $scope.initDisp($scope.showMsgDeleteSuccess);
                    if (funcOnSuccess) {
                        // 正常終了時に実行する関数の指定がある場合は実行する
                        funcOnSuccess();
                    }
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // 削除完了メッセージ表示
    $rootScope.showMsgDeleteSuccess = function() {
        alert(Msg('MSG0011'));
    };

});

