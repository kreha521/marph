angular.module('angularprjApp')

    .controller('imagesetregisterCtl', function( $scope, $rootScope, $http, $state, $stateParams, $uibModal, AppCommonConf, AppConf, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_NEW = AppCommonConf().nodeBaseUrl + '/imagesets/get/_new';
    // URL:初期表示（編集）
    $scope.URL_GET_EDIT = AppCommonConf().nodeBaseUrl + '/imagesets/get/_edit';
    // URL:登録
    $scope.URL_ADD = AppCommonConf().nodeBaseUrl + '/imagesets/add';
    // URL:更新
    $scope.URL_UPD = AppCommonConf().nodeBaseUrl + '/imagesets/upd';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/imagesets/del';

    // 画面遷移パラメータ設定
    $scope.setParam = function() {
        $scope.envCe = $stateParams.envCd;
        $scope.seriesCd = $stateParams.seriesCd;
        $scope.repositorySeq = $stateParams.repositorySeq;
        $scope.imagesetSeq = $stateParams.imagesetSeq;
    };

    /* 新規登録であるか判定 */
    $scope.isNewEdit = function() {
        return !$stateParams.repositorySeq || !$stateParams.imagesetSeq;
    };

    /* メニュー起動であるか判定 */
    $scope.isMenuRoute = function() {
        return !$scope.envCd || !$scope.seriesCd;
    };

    /* フォーム初期化 */
    $scope.initForm = function() {
        $scope.repositorySeqs = [];
        $scope.exeOrders = [];

        //ページング処理
        $scope.limit = 6;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // 画面初期表示
    $scope.initDisp = function() {
        if ($scope.isNewEdit()) {
            $scope.dispImagesetNew();
        } else {
            $scope.dispImagesetItem();
        }
    };

    // イメージセット情報表示設定
    $scope.setImagesetDispItem = function(data) {
        $scope.imagesetSeq = data.imgSet.imagesetSeq;
        $scope.imagesetName = data.imgSet.imagesetName;
        $scope.repositorySeq = data.imgSet.repositorySeq;
        for (var i = 0; i < data.rowData.length; i++) {
            var wkgroup = new Object();
            wkgroup.ankenNo = data.rowData[i].repoInf.projectNo;
            wkgroup.ankenName = data.rowData[i].repoInf.projectName;
            wkgroup.imageId = data.rowData[i].imgOrder.imageId;
            wkgroup.imageTypeName = data.rowData[i].image.imageTypeName;
            $scope.exeOrders.push(wkgroup);
        }
    };

    //イメージセット情報登録初期表示
    $scope.dispImagesetNew = function() {
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_NEW,
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.groupName = data.groupShortCd + "：" + data.groupName
            $scope.setRepositorySeqs(data.prdTypeCds);
            $scope.repositorySeq = $scope.repositorySeqs[0].cd
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };

    // イメージセット情報表示情報取得
    $scope.dispImagesetItem = function() {
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_EDIT,
            headers: {'Content-Type': 'application/json'},
            data: {"repositorySeq": $scope.repositorySeq, "imagesetSeq": $scope.imagesetSeq}
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.groupName = data.groupShortCd + "：" + data.groupName
            $scope.setImagesetDispItem(data.imageSet);
            $scope.setRepositorySeqs(data.prdTypeCds);
            //選択リスト設定
            $scope.repositorySeq = data.imageSet.imgSet.repositorySeq;
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    };

    // 案件セレクトボックスを詰める
    $scope.setRepositorySeqs = function(data) {
        for (var i = 0; i < data.length; i++) {
            var wkgroup = new Object();
            wkgroup.cd = data[i].repositorySeq;
            wkgroup.name = data[i].projectNo + "：" + data[i].projectName;
            $scope.repositorySeqs.push(wkgroup);
        }
    }

    // 追加ボタン押下処理
    $scope.imgadd = function() {
        var modalInstance = $uibModal.open({
            templateUrl: 'views/imageselect.html',
            controller: 'imageselectCtl',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        repositorySeq:$scope.repositorySeq
                    };
                }
            }
        });
        modalInstance.result.then(
            //OK押下
            function(result){
                var wkgroup = new Object();
                wkgroup.ankenNo = result.ret_data.ankenNo;
                wkgroup.ankenName = result.ret_data.ankenName;
                wkgroup.imageId = result.ret_data.imageId;
                wkgroup.imageTypeName = result.ret_data.imageTypeName;
                $scope.exeOrders.push(wkgroup);
            }
        );
    };

    //案件セレクトボックス変更時
    $scope.selectChange= function(index) {
        // リストの初期化
        $scope.exeOrders = [];
    };

    //上ボタン押下
    $scope.moveup = function(index) {
        if ( index > 0) {
            move(index, index - 1);
        };
    };

    //下ボタン押下
    $scope.movedown = function(index) {
        if (index < $scope.exeOrders.length - 1) {
            move(index, index + 1);
        };
    };

    //行移動処理
    var move = function(origin, destination) {
        var temp = $scope.exeOrders[destination];
        $scope.exeOrders[destination] = $scope.exeOrders[origin];
        $scope.exeOrders[origin] = temp;
    };

    //行削除処理
    $scope.delete = function(num) {
        $scope.exeOrders.splice(num, 1);
    };

    // ページ数取得
    $scope.range = function() {
        $scope.maxPage = Math.ceil($scope.exeOrders.length/$scope.itemsPerPage);
        var ret = [];
        for (var i=1; i<=$scope.maxPage; i++) {
            ret.push(i);
        }
        return ret;
    };

    // 対象ページのデータ取得設定
    $scope.page = function(page){
        $scope.begin = (page - 1) * $scope.limit;
    };

    // 登録用データ編集
    $scope.editRegisterData = function() {
        var imageset = {
            "imgSet":{
                  "updateCounter": $scope.updateCounter
                , "repositorySeq":$scope.repositorySeq
                , "imagesetSeq": $scope.imagesetSeq
                , "imagesetName": $scope.imagesetName
            }
        };
        var imageExeOrders = [];
        for (var i=0; i<$scope.exeOrders.length; i++) {
            var wkData = new Object;
            wkData = {
                  "repositorySeq":$scope.repositorySeq
                , "imagesetSeq": $scope.imagesetSeq
                , "exeOrder": i + 1
                , "imageId": $scope.exeOrders[i].imageId
            };
            imageExeOrders.push(wkData);
        }
        imageset.imgOrder = imageExeOrders;
        return imageset;
    };

    // 更新用データ編集
    $scope.editUpdateData = function() {
        return $scope.editRegisterData();
    };

    // 登録
    $scope.register = function() {
        $rootScope.isShowableMsgArea = true;

        if ($scope.isInvalidForm()) {
            // 入力チェックエラーの場合、処理しない
            return;
        }

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'イメージ実行順登録確認',
                        message: $scope.isNewEdit() ? Msg('MSG0015', 'イメージ実行順の登録') : Msg('MSG0015', 'イメージ実行順の更新')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.isNewEdit() ? $scope.URL_ADD : $scope.URL_UPD,
                    headers: { 'Content-Type': 'application/json' },
                    data: $scope.isNewEdit() ? $scope.editRegisterData() : $scope.editUpdateData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }

                    if ($scope.isNewEdit()) {
                        alert(Msg('MSG0010'));
                    } else {
                        alert(Msg('MSG0019'));
                    }
                    $state.go('imageset');
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // 削除
    $scope.datadel = function() {
        $rootScope.isShowableMsgArea = false;
        var fd = new FormData();

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'イメージ実行順削除確認',
                        message: "イメージ実行順の削除を実行します。よろしいですか？"
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_DEL,
                    headers: { 'Content-Type': 'application/json' },
                    data: {"repositorySeq":$scope.repositorySeq, "imagesetSeq": $scope.imagesetSeq}
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }
                    // イメージセット一覧画面
                    alert(Msg('MSG0011'));
                    $state.go('imageset');
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // 入力チェック結果を取得
    $scope.isInvalidForm = function() {
        var isInvalid = $scope.imgSetForm.imagesetName.$invalid;

        // バリデーターじゃなく、普通のfunctionでチェックしてる箇所の処理結果を考慮
        isInvalid = isInvalid || $scope.imageCnt_validator();

        return isInvalid;
    };

    // 権限明細の０件チェック（エラー時にtrueを返却）
    $scope.imageCnt_validator = function() {
        return ($scope.exeOrders.length <= 0);
    };


    // onload処理
    $scope.setParam();
    $scope.initForm();
    $scope.initDisp();
})

//明細用のコントローラー
    .controller('imagesetregisterListCtl', function($scope,  $http, $location, sharedObject) {

});
