angular.module('angularprjApp')

/* 環境情報登録のコントローラー */
    .controller('envRegisterCtrl', function($scope, $rootScope, $http,  $stateParams, $uibModal, $state, AppCommonConf, AppConf, Msg) {

    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_NEW = AppCommonConf().nodeBaseUrl + '/envs/get/_new';
    // URL:初期表示（編集）
    $scope.URL_GET_EDIT = AppCommonConf().nodeBaseUrl + '/envs/get/_edit';
    // URL:登録
    $scope.URL_ADD = AppCommonConf().nodeBaseUrl + '/envs/add';
    // URL:更新
    $scope.URL_UPD = AppCommonConf().nodeBaseUrl + '/envs/upd';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/envs/del';

    // パラメータ引き渡し
    $scope.setParam = function() {
        $scope.groupCd = $stateParams.groupCd;
        $scope.orgCd = $stateParams.orgCd;
        $scope.envCd = $stateParams.envCd;
    };

    /* フォーム初期化 */
    $scope.initForm = function() {
        $scope.envTypelist = [];

        $rootScope.isShowableMsgArea = false;

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    }


    // セレクトボックスセット
    $scope.setEnvCds = function(envCds) {
        for (i in envCds) {
            var envCd = {cd: envCds[i].cd, name: envCds[i].name};
            $scope.envTypelist.push(envCd);
        }
    }

    /* 新規登録であるか判定 */
    $scope.isNewEdit = function() {
        return !$stateParams.orgCd || !$stateParams.groupCd || !$stateParams.envCd;
    };

    // 画面初期表示
    $scope.initDisp = function() {
        if ($scope.isNewEdit()) {
            $scope.dispEnvNew();
        } else {
            $scope.dispEnvEdit();
        }
    };

    //環境情報登録初期表示
    $scope.dispEnvNew = function() {
        // 新規作成
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_NEW,
        }).success(function(data, status, headers, config) {
            $scope.groupName = data.groupShortCd + "：" + data.groupName
            $scope.groupCd = data.groupCd;
            $scope.setEnvCds(data.envCds);
            $scope.envTypeCd = $scope.envTypelist[0].cd;
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
        });
    }

    // 環境情報表示情報取得
    $scope.dispEnvEdit = function() {
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_EDIT,
            headers: {'Content-Type': 'application/json'},
            data: {"groupCd": $scope.groupCd, "orgCd": $scope.orgCd, "envCd": $scope.envCd}
        }).success(function(data, status, headers, config) {
            setServerMsgs($rootScope, data);
            if (hasServerAppError($rootScope)) {
                // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                $rootScope.isShowableMsgArea = true;
                return;
            }
            $scope.setEnvDispItem(data);
        }).error(function(data, status, headers, config) {
            onServerError($state, data);
            return;
        });
    }

    // 環境情報表示設定
    $scope.setEnvDispItem = function(data) {
        $scope.groupName = data.groupShortCd + "：" + data.groupName
        $scope.setEnvCds(data.envCds);

        $scope.updateCounter = data.updateCounter;
        $scope.orgCd = data.orgCd;
        $scope.groupCd = data.groupCd;
        $scope.envCd = data.envCd;
        $scope.envTypeCd = data.envCd;
        $scope.envName = data.envName;
    };

    // 環境登録
    $scope.register = function() {

        $rootScope.isShowableMsgArea = true;

        if ($scope.envForm.$invalid) {
            return;
        }

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'環境情報登録確認',
                        message: $scope.isNewEdit() ? Msg('MSG0015', '環境情報の登録') : Msg('MSG0015', '環境情報の更新')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.isNewEdit() ? $scope.URL_ADD : $scope.URL_UPD,
                    headers: { 'Content-Type': 'application/json' },
                    data: $scope.isNewEdit() ? $scope.editRegisterData() : $scope.editUpdateData()
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }
                    if ($scope.isNewEdit()) {
                        alert(Msg('MSG0010'));
                    } else {
                        alert(Msg('MSG0019'));
                    }
                    $state.go('environmentlist');
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // 登録データ編集
    $scope.editRegisterData = function() {
        data = {
            "updateCounter":$scope.updateCounter
            ,"orgCd":Number($scope.orgCd)
            , "groupCd":Number($scope.groupCd)
            , "envCd":$scope.envTypeCd
            , "envName":$scope.envName
        };
        return data;
    }

    // 更新データ編集
    $scope.editUpdateData = function() {
        return $scope.editRegisterData();
    }

    // 環境削除
    $scope.delete = function() {

        // 実行確認
        var modalInstance = $uibModal.open({
            templateUrl: 'views/confirm.html',
            controller: 'ConfirmController',
            backdrop: true,
            scope: $scope,
            resolve: {
                params:function(){
                    return {
                        title:'環境削除確認',
                        message: Msg('MSG0015', '環境情報の削除')
                    };
                }
            }
        });

        //レスポンスをモデルに設定
        modalInstance.result.then(
            //OK押下
            function(result){
                $rootScope.myPromise = $http({
                    method: 'POST',
                    url : $scope.URL_DEL,
                    headers: { 'Content-Type': 'application/json' },
                    data: {"orgCd":$scope.orgCd, "groupCd":$scope.groupCd, "envCd":$scope.envCd,"updateCounter":$scope.updateCounter}
                }).success(function(data, status, headers, config) {
                    setServerMsgs($rootScope, data);
                    if (hasServerAppError($rootScope)) {
                        // サーバ側で業務エラーがあった場合は、メッセージを表示し、以降の処理をしない
                        $rootScope.isShowableMsgArea = true;
                        return;
                    }
                    // 環境一覧画面
                    alert(Msg('MSG0011'));
                    $state.go('environmentlist');
                }).error(function(data, status, headers, config) {
                    onServerError($state, data);
                    return;
                });
            },

            //キャンセル押下
            function(){
            }
        );
    };

    // onload処理
    $scope.setParam();
    // フォーム初期化
    $scope.initForm();
    // 編集時データ取得
    $scope.initDisp();
});
