angular.module('angularprjApp')

/* コンテナ基本情報一覧のコントローラー */
    .controller('ContainerCtrl', function($scope, $rootScope, $http, $uibModal, $state, $stateParams, AppCommonConf, AppConf, Msg) {
    // メッセージ定義情報
    $scope.Msg = Msg;

    // URL:初期表示
    $scope.URL_GET_LIST = AppCommonConf().nodeBaseUrl + '/containers/get/_detail';
    // URL:削除
    $scope.URL_DEL = AppCommonConf().nodeBaseUrl + '/containers/delete';

    // フォーム初期化
    $scope.initForm = function() {
        //ページング処理
        $scope.limit = 10;   // 1ページ当たりの件数
        $scope.begin = 0;    // 現在のページの最初のindex
        $scope.itemsPerPage = $scope.limit;

        $rootScope.isShowableMsgArea = false;

        $scope.containers = [];

        // サーバ側処理結果メッセージ初期化
        initServerMsgs($rootScope);
    };

    // コンテナ一覧情報表示設定
    $scope.setDispItem = function(data) {

        //        console.log(ContainerList);
        // JSONのデータを画面表示仕様に合わせて設定する
        $scope.BCsContainerList = [];
        for (var i=0; i<data.length; i++) {
            var dispItem = new Object();
            var bCsContainerData = new Object();

            dispItem.orgName = data[i].orgs.orgName;
            dispItem.serverSeqNo = data[i].BCs.serverSeqNo;
            dispItem.serverName = data[i].svr.serverName;
            dispItem.containerTypeCdName = data[i].BCs.containerTypeCdName;
            dispItem.containerTypeName = data[i].BCs.containerTypeName;
            dispItem.ipAddress = data[i].BCs.ipAddress;
            $scope.containers.push(dispItem);
            //削除処理用の連番
            $scope.seqNo = data[i].BCs.seqNo;
            //更新処理用の組織コード
            $scope.orgCd = data[i].orgs.orgCd;
            ///削除・登録用 基本コンテナ情報テーブル
            bCsContainerData = data[i].BCs
            $scope.BCsContainerList = bCsContainerData;
        }
    };

    // 画面初期表示
    $scope.initDisp = function(funcOnSuccess) {
        // 初期表示データ取得
        $rootScope.myPromise = $http({
            method: 'POST',
            url : $scope.URL_GET_LIST,
        }).success(function(data, status, headers, config) {
            $scope.setDispItem(data);
            if (funcOnSuccess) {
                // 正常終了時に実行する関数の指定がある場合は実行する
                funcOnSuccess();
            }
        }).error(function(data, status, headers, config) {
            //        console.log("err");
            return;
        });
    };

    // ページ数取得
    $scope.range = function() {
        $scope.maxPage = Math.ceil($scope.containers.length / $scope.itemsPerPage);
        var ret = [];
        for (var i=1; i<=$scope.maxPage; i++) {
            ret.push(i);
        }
        return ret;
    };

    // 対象ページのデータ取得設定
    $scope.page = function(page){
        $scope.begin = (page - 1) * $scope.limit;
    };

    // onload処理
    $scope.initForm();
    $scope.initDisp();
});
