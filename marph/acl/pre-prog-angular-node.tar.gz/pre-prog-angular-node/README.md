# angular/node の開発プロジェクト

* Angular のソース及びその他の静的コンテンツもこちらに含むものとする。
* Node.js のnpm パッケージは含まないこと



## リポジトリの展開方法

任意ディレクトリ配下で `git clone` を実行する：

git clone ssh://git@42.127.235.217:10022/root/pre-prog-angular-node.git

※カレントに　pre-prog-angular-node フォルダができる。

### ライブラリインストール

上記で作成した pre-prog-angular-node フォルダに移動しコンソールで下記コマンドを実行

※ xxxxxxをインストールすると同時に、pakage.jsonの定義情報へ登録
npm install xxxxxxx --save

※ 同フォルダの　package.json　で指定されたライブラリをインストールする。
npm install


### 実行方法

* 上記で作成した pre-prog-angular-node フォルダに移動しコンソールで下記コマンドを実行
npm start

* ブラウザを起動し次のURLでシステムが起動する。
http://localhost:3000/
